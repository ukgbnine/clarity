-- Drop and recreate the tasks table to ensure clean state
DROP TABLE IF EXISTS tasks CASCADE;

CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  goal_id uuid REFERENCES goals(id) ON DELETE SET NULL,
  name text NOT NULL,
  type text CHECK (type IN ('fixed', 'flexible', 'habit')) NOT NULL,
  frequency text CHECK (frequency IN ('daily', 'weekly', 'monthly')),
  dates date[] NOT NULL DEFAULT '{}',
  timeframe text,
  selected_monthly_weekdays text[] DEFAULT '{}',
  "order" integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX idx_tasks_dates ON tasks USING GIN(dates);
CREATE INDEX idx_tasks_monthly_weekdays ON tasks USING GIN(selected_monthly_weekdays);

-- Enable RLS
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Tasks are viewable by owner"
  ON tasks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tasks"
  ON tasks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  USING (auth.uid() = user_id);

-- Grant permissions
GRANT ALL ON TABLE tasks TO authenticated;
GRANT ALL ON TABLE tasks TO service_role;

-- Create validation function
CREATE OR REPLACE FUNCTION validate_weekday_format(weekday text)
RETURNS boolean AS $$
BEGIN
  RETURN weekday ~ '^(first|second|third|fourth|last)-(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create validation trigger function
CREATE OR REPLACE FUNCTION validate_monthly_weekdays()
RETURNS trigger AS $$
BEGIN
  IF NEW.selected_monthly_weekdays IS NOT NULL AND array_length(NEW.selected_monthly_weekdays, 1) > 0 THEN
    FOR i IN 1..array_length(NEW.selected_monthly_weekdays, 1) LOOP
      IF NOT validate_weekday_format(NEW.selected_monthly_weekdays[i]) THEN
        RAISE EXCEPTION 'Invalid weekday format at index %: %', i, NEW.selected_monthly_weekdays[i];
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();

-- Force schema cache refresh
NOTIFY pgrst, 'reload schema';