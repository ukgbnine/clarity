/*
  # Fix Group Policies

  1. Changes
    - Drop existing policies
    - Create new policies for groups and group members
    - Add indexes for performance

  2. Security
    - Groups are viewable by everyone (filtering done in app)
    - Group members are viewable by everyone (filtering done in app)
    - Users can only join groups once
    - Users can leave groups
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Groups are viewable by members" ON groups;
DROP POLICY IF EXISTS "Group members are viewable by other members" ON group_members;
DROP POLICY IF EXISTS "Users can join groups" ON group_members;
DROP POLICY IF EXISTS "Users can leave groups" ON group_members;
DROP POLICY IF EXISTS "Group members are viewable by everyone" ON group_members;
DROP POLICY IF EXISTS "Users can only view their own group memberships" ON group_members;
DROP POLICY IF EXISTS "Groups are viewable by everyone" ON groups;

-- Create new policies with fixed logic

-- Groups policies
CREATE POLICY "Anyone can view groups"
  ON groups FOR SELECT
  USING (true);

-- Group Members policies
CREATE POLICY "Anyone can view group members"
  ON group_members FOR SELECT
  USING (true);

CREATE POLICY "Members can manage their own membership"
  ON group_members FOR DELETE
  USING (user_id = auth.uid());

CREATE POLICY "Users can join new groups"
  ON group_members FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    NOT EXISTS (
      SELECT 1 FROM group_members
      WHERE group_id = group_members.group_id
      AND user_id = auth.uid()
    )
  );

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_group_members_user_id ON group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_group_members_group_id ON group_members(group_id);