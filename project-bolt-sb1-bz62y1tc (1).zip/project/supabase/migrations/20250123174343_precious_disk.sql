/*
  # Add missing policies and trigger
  
  1. Changes
    - Add missing INSERT policy for profiles table
    - Recreate user trigger with proper error handling
*/

-- Add missing INSERT policy for profiles
CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Recreate function with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, username, full_name)
  VALUES (
    NEW.id,
    COALESCE(LOWER(NEW.raw_user_meta_data->>'username'), 'user_' || substr(NEW.id::text, 1, 8)),
    NEW.raw_user_meta_data->>'full_name'
  );
  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    -- Handle username conflict by appending random suffix
    INSERT INTO public.profiles (id, username, full_name)
    VALUES (
      NEW.id,
      COALESCE(LOWER(NEW.raw_user_meta_data->>'username'), 'user_') || '_' || substr(md5(random()::text), 1, 6),
      NEW.raw_user_meta_data->>'full_name'
    );
    RETURN NEW;
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Error in handle_new_user: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();