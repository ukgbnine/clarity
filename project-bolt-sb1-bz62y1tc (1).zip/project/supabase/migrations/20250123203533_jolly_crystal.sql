-- Drop existing triggers and functions
DROP TRIGGER IF EXISTS validate_monthly_weekdays_trigger ON tasks;
DROP FUNCTION IF EXISTS validate_monthly_weekdays();
DROP FUNCTION IF EXISTS validate_weekday_format();

-- Recreate the tasks table with the correct schema
CREATE TABLE IF NOT EXISTS new_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  goal_id uuid REFERENCES goals(id) ON DELETE SET NULL,
  name text NOT NULL,
  type text CHECK (type IN ('fixed', 'flexible', 'habit')) NOT NULL,
  frequency text CHECK (frequency IN ('daily', 'weekly', 'monthly')),
  dates date[] NOT NULL DEFAULT '{}',
  timeframe text,
  selected_monthly_weekdays text[] DEFAULT '{}',
  "order" integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Copy data from old table if it exists
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'tasks') THEN
    INSERT INTO new_tasks (
      id, user_id, goal_id, name, type, frequency, dates, timeframe, "order", created_at, updated_at
    )
    SELECT 
      id, user_id, goal_id, name, type, frequency, dates, timeframe, "order", created_at, updated_at
    FROM tasks;
  END IF;
END $$;

-- Drop old table and rename new one
DROP TABLE IF EXISTS tasks CASCADE;
ALTER TABLE new_tasks RENAME TO tasks;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX IF NOT EXISTS idx_tasks_dates ON tasks USING GIN(dates);
CREATE INDEX IF NOT EXISTS idx_tasks_monthly_weekdays ON tasks USING GIN(selected_monthly_weekdays);

-- Enable RLS
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Tasks are viewable by owner"
  ON tasks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tasks"
  ON tasks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  USING (auth.uid() = user_id);

-- Create function to validate weekday format
CREATE OR REPLACE FUNCTION validate_weekday_format(weekday text)
RETURNS boolean AS $$
BEGIN
  RETURN weekday ~ '^(first|second|third|fourth|last)-(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add validation trigger function
CREATE OR REPLACE FUNCTION validate_monthly_weekdays()
RETURNS trigger AS $$
BEGIN
  IF NEW.selected_monthly_weekdays IS NOT NULL AND array_length(NEW.selected_monthly_weekdays, 1) > 0 THEN
    FOR i IN 1..array_length(NEW.selected_monthly_weekdays, 1) LOOP
      IF NOT validate_weekday_format(NEW.selected_monthly_weekdays[i]) THEN
        RAISE EXCEPTION 'Invalid weekday format at index %: %', i, NEW.selected_monthly_weekdays[i];
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();