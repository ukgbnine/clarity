/*
# Fix Tasks Schema

1. Changes
  - Add selected_monthly_weekdays column to tasks table
  - Add validation for weekday format
  - Add appropriate indexes

2. Details
  - Ensures column exists with proper type and default value
  - Adds validation trigger for weekday format
  - Adds performance optimization indexes
*/

-- Create function to validate weekday format
CREATE OR REPLACE FUNCTION validate_weekday_format(weekday text)
RETURNS boolean AS $$
BEGIN
  RETURN weekday ~ '^(first|second|third|fourth|last)-(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add validation trigger function
CREATE OR REPLACE FUNCTION validate_monthly_weekdays()
RETURNS trigger AS $$
BEGIN
  IF NEW.selected_monthly_weekdays IS NOT NULL AND array_length(NEW.selected_monthly_weekdays, 1) > 0 THEN
    FOR i IN 1..array_length(NEW.selected_monthly_weekdays, 1) LOOP
      IF NOT validate_weekday_format(NEW.selected_monthly_weekdays[i]) THEN
        RAISE EXCEPTION 'Invalid weekday format at index %: %', i, NEW.selected_monthly_weekdays[i];
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Safe schema update using DO block
DO $$ 
BEGIN
  -- Add column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public'
    AND table_name = 'tasks' 
    AND column_name = 'selected_monthly_weekdays'
  ) THEN
    ALTER TABLE tasks 
    ADD COLUMN selected_monthly_weekdays text[] DEFAULT '{}'::text[];
  END IF;
END $$;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS validate_monthly_weekdays_trigger ON tasks;

-- Create trigger
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_tasks_monthly_weekdays 
ON tasks USING GIN(selected_monthly_weekdays);