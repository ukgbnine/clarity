-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Ensure profiles table exists with correct schema
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create improved handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
DECLARE
  username_attempt text;
  counter int := 0;
  max_attempts int := 5;
BEGIN
  -- Start with base username
  username_attempt := COALESCE(
    LOWER(NEW.raw_user_meta_data->>'username'),
    'user_' || substr(NEW.id::text, 1, 8)
  );

  -- Try to insert with increasingly complex usernames
  LOOP
    BEGIN
      INSERT INTO public.profiles (
        id,
        username,
        full_name,
        avatar_url
      ) VALUES (
        NEW.id,
        username_attempt,
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'avatar_url'
      );
      
      -- If we get here, insert succeeded
      RETURN NEW;
    EXCEPTION 
      WHEN unique_violation THEN
        -- Only retry if we haven't hit max attempts
        IF counter < max_attempts THEN
          counter := counter + 1;
          -- Add random suffix
          username_attempt := username_attempt || '_' || substr(md5(random()::text), 1, 6);
          CONTINUE;
        END IF;
        RAISE EXCEPTION 'Could not generate unique username after % attempts', max_attempts;
      WHEN OTHERS THEN
        RAISE EXCEPTION 'Error in handle_new_user: %', SQLERRM;
    END;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON TABLE public.profiles TO anon, authenticated;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username);

-- Notify PostgREST to reload schema cache
NOTIFY pgrst, 'reload schema';