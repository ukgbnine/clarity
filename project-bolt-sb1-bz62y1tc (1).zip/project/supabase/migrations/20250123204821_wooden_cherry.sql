-- Drop everything related to tasks and start fresh
DROP TABLE IF EXISTS task_logs CASCADE;
DROP TABLE IF EXISTS tasks CASCADE;
DROP FUNCTION IF EXISTS validate_weekday_format() CASCADE;
DROP FUNCTION IF EXISTS validate_monthly_weekdays() CASCADE;

-- Recreate the tasks table
CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  goal_id uuid REFERENCES goals(id) ON DELETE SET NULL,
  name text NOT NULL,
  type text NOT NULL,
  frequency text,
  dates date[] NOT NULL DEFAULT '{}',
  timeframe text,
  selected_monthly_weekdays text[] NOT NULL DEFAULT '{}',
  "order" integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT tasks_type_check CHECK (type IN ('fixed', 'flexible', 'habit')),
  CONSTRAINT tasks_frequency_check CHECK (frequency IN ('daily', 'weekly', 'monthly'))
);

-- Create task_logs table that depends on tasks
CREATE TABLE task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  status text NOT NULL CHECK (status IN ('completed', 'uncompleted')),
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(task_id, date)
);

-- Create indexes
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX idx_tasks_dates ON tasks USING GIN(dates);
CREATE INDEX idx_tasks_monthly_weekdays ON tasks USING GIN(selected_monthly_weekdays);
CREATE INDEX idx_task_logs_task_id ON task_logs(task_id);
CREATE INDEX idx_task_logs_user_id ON task_logs(user_id);
CREATE INDEX idx_task_logs_date ON task_logs(date);

-- Enable RLS
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for tasks
CREATE POLICY "Tasks are viewable by owner"
  ON tasks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tasks"
  ON tasks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  USING (auth.uid() = user_id);

-- Create RLS policies for task_logs
CREATE POLICY "Users can view own task logs"
  ON task_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create task logs"
  ON task_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own task logs"
  ON task_logs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own task logs"
  ON task_logs FOR DELETE
  USING (auth.uid() = user_id);

-- Create validation function
CREATE OR REPLACE FUNCTION validate_weekday_format(weekday text)
RETURNS boolean AS $$
BEGIN
  RETURN weekday ~ '^(first|second|third|fourth|last)-(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create validation trigger function
CREATE OR REPLACE FUNCTION validate_monthly_weekdays()
RETURNS trigger AS $$
BEGIN
  IF NEW.selected_monthly_weekdays IS NOT NULL AND array_length(NEW.selected_monthly_weekdays, 1) > 0 THEN
    FOR i IN 1..array_length(NEW.selected_monthly_weekdays, 1) LOOP
      IF NOT validate_weekday_format(NEW.selected_monthly_weekdays[i]) THEN
        RAISE EXCEPTION 'Invalid weekday format at index %: %', i, NEW.selected_monthly_weekdays[i];
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();

-- Grant permissions
GRANT ALL ON TABLE tasks TO authenticated;
GRANT ALL ON TABLE tasks TO service_role;
GRANT ALL ON TABLE task_logs TO authenticated;
GRANT ALL ON TABLE task_logs TO service_role;

-- Force schema cache refresh
DO $$ 
BEGIN
  -- Force PostgREST to reload its schema cache
  NOTIFY pgrst, 'reload schema';
  -- Wait a moment to ensure the notification is processed
  PERFORM pg_sleep(1);
END $$;