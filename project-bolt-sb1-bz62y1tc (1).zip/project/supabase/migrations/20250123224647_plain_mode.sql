-- Drop existing RLS policies for goals
DROP POLICY IF EXISTS "Goals are viewable by owner" ON goals;
DROP POLICY IF EXISTS "Users can create goals" ON goals;
DROP POLICY IF EXISTS "Users can update own goals" ON goals;
DROP POLICY IF EXISTS "Users can delete own goals" ON goals;

-- Create improved RLS policies for goals with better auth checks
CREATE POLICY "Goals are viewable by owner"
  ON goals FOR SELECT
  USING (
    auth.uid() IS NOT NULL AND
    auth.uid() = user_id
  );

CREATE POLICY "Users can create goals"
  ON goals FOR INSERT
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can update own goals"
  ON goals FOR UPDATE
  USING (
    auth.uid() IS NOT NULL AND
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can delete own goals"
  ON goals FOR DELETE
  USING (
    auth.uid() IS NOT NULL AND
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

-- Ensure proper grants
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON TABLE goals TO authenticated;
GRANT ALL ON TABLE goals TO service_role;

-- Force schema cache refresh
NOTIFY pgrst, 'reload schema';