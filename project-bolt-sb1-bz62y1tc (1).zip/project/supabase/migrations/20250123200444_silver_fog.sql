-- Fix tasks table
DO $$ 
BEGIN
  -- Add goal_id column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public'
    AND table_name = 'tasks' 
    AND column_name = 'goal_id'
  ) THEN
    ALTER TABLE tasks 
    ADD COLUMN goal_id uuid REFERENCES goals(id) ON DELETE SET NULL;
  END IF;

  -- Add index for goal_id
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tasks' 
    AND indexname = 'idx_tasks_goal_id'
  ) THEN
    CREATE INDEX idx_tasks_goal_id ON tasks(goal_id);
  END IF;
END $$;

-- Add NOT NULL constraint to task_id in task_logs
ALTER TABLE task_logs 
ALTER COLUMN task_id SET NOT NULL;

-- Add validation trigger function for task logs
CREATE OR REPLACE FUNCTION validate_task_log()
RETURNS trigger AS $$
BEGIN
  IF NEW.task_id IS NULL THEN
    RAISE EXCEPTION 'task_id cannot be null';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS validate_task_log_trigger ON task_logs;
CREATE TRIGGER validate_task_log_trigger
BEFORE INSERT OR UPDATE ON task_logs
FOR EACH ROW
EXECUTE FUNCTION validate_task_log();