-- Refresh schema cache by altering and restoring a column
DO $$ 
BEGIN
  -- Temporarily rename the column to force a schema cache refresh
  ALTER TABLE tasks RENAME COLUMN selected_monthly_weekdays TO _selected_monthly_weekdays;
  
  -- Rename it back
  ALTER TABLE tasks RENAME COLUMN _selected_monthly_weekdays TO selected_monthly_weekdays;
END $$;

-- Re-create the index to ensure it's properly registered
DROP INDEX IF EXISTS idx_tasks_monthly_weekdays;
CREATE INDEX idx_tasks_monthly_weekdays ON tasks USING GIN(selected_monthly_weekdays);

-- Re-create the trigger to ensure it's properly registered
DROP TRIGGER IF EXISTS validate_monthly_weekdays_trigger ON tasks;
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();

-- Grant necessary permissions
GRANT ALL ON TABLE tasks TO authenticated;
GRANT ALL ON TABLE tasks TO service_role;

-- Notify PostgREST to reload its schema cache
NOTIFY pgrst, 'reload schema';