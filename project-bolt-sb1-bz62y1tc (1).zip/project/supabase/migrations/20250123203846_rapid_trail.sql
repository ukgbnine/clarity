-- Drop existing triggers and functions
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  username text UNIQUE,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add missing columns to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email text UNIQUE,
ADD COLUMN IF NOT EXISTS username text UNIQUE,
ADD COLUMN IF NOT EXISTS full_name text,
ADD COLUMN IF NOT EXISTS avatar_url text;

-- Create goals table if it doesn't exist
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  target_date text,
  achievement_date text,
  achieved boolean DEFAULT false,
  "order" integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add missing columns to goals table
ALTER TABLE goals 
ADD COLUMN IF NOT EXISTS target_date text,
ADD COLUMN IF NOT EXISTS achievement_date text,
ADD COLUMN IF NOT EXISTS achieved boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS "order" integer DEFAULT 0;

-- Create tasks table if it doesn't exist
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  goal_id uuid REFERENCES goals(id) ON DELETE SET NULL,
  name text NOT NULL,
  type text CHECK (type IN ('fixed', 'flexible', 'habit')) NOT NULL,
  frequency text CHECK (frequency IN ('daily', 'weekly', 'monthly')),
  dates date[] NOT NULL DEFAULT '{}',
  timeframe text,
  selected_monthly_weekdays text[] DEFAULT '{}',
  "order" integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add missing columns to tasks table
ALTER TABLE tasks 
ADD COLUMN IF NOT EXISTS selected_monthly_weekdays text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS "order" integer DEFAULT 0;

-- Create task_logs table if it doesn't exist
CREATE TABLE IF NOT EXISTS task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  date date NOT NULL,
  status text CHECK (status IN ('completed', 'uncompleted')) NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  UNIQUE(task_id, date)
);

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_logs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own profile" ON users;
DROP POLICY IF EXISTS "Users can update own profile" ON users;
DROP POLICY IF EXISTS "Users can view own goals" ON goals;
DROP POLICY IF EXISTS "Users can create goals" ON goals;
DROP POLICY IF EXISTS "Users can update own goals" ON goals;
DROP POLICY IF EXISTS "Users can delete own goals" ON goals;
DROP POLICY IF EXISTS "Users can view own tasks" ON tasks;
DROP POLICY IF EXISTS "Users can create tasks" ON tasks;
DROP POLICY IF EXISTS "Users can update own tasks" ON tasks;
DROP POLICY IF EXISTS "Users can delete own tasks" ON tasks;
DROP POLICY IF EXISTS "Users can view own task logs" ON task_logs;
DROP POLICY IF EXISTS "Users can create task logs" ON task_logs;
DROP POLICY IF EXISTS "Users can update own task logs" ON task_logs;
DROP POLICY IF EXISTS "Users can delete own task logs" ON task_logs;

-- Create RLS policies
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can view own goals"
  ON goals FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create goals"
  ON goals FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own goals"
  ON goals FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own goals"
  ON goals FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own tasks"
  ON tasks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tasks"
  ON tasks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own task logs"
  ON task_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create task logs"
  ON task_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own task logs"
  ON task_logs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own task logs"
  ON task_logs FOR DELETE
  USING (auth.uid() = user_id);

-- Drop existing indexes
DROP INDEX IF EXISTS idx_goals_user_id;
DROP INDEX IF EXISTS idx_goals_target_date;
DROP INDEX IF EXISTS idx_tasks_user_id;
DROP INDEX IF EXISTS idx_tasks_goal_id;
DROP INDEX IF EXISTS idx_tasks_dates;
DROP INDEX IF EXISTS idx_tasks_monthly_weekdays;
DROP INDEX IF EXISTS idx_task_logs_task_id;
DROP INDEX IF EXISTS idx_task_logs_user_id;
DROP INDEX IF EXISTS idx_task_logs_date;

-- Create indexes
CREATE INDEX idx_goals_user_id ON goals(user_id);
CREATE INDEX idx_goals_target_date ON goals(target_date);
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX idx_tasks_dates ON tasks USING GIN(dates);
CREATE INDEX idx_tasks_monthly_weekdays ON tasks USING GIN(selected_monthly_weekdays);
CREATE INDEX idx_task_logs_task_id ON task_logs(task_id);
CREATE INDEX idx_task_logs_user_id ON task_logs(user_id);
CREATE INDEX idx_task_logs_date ON task_logs(date);

-- Create handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO users (id, email, username, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(LOWER(NEW.raw_user_meta_data->>'username'), 'user_' || substr(NEW.id::text, 1, 8)),
    NEW.raw_user_meta_data->>'full_name'
  );
  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    -- Handle username conflict by appending random suffix
    INSERT INTO users (id, email, username, full_name)
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(LOWER(NEW.raw_user_meta_data->>'username'), 'user_') || '_' || substr(md5(random()::text), 1, 6),
      NEW.raw_user_meta_data->>'full_name'
    );
    RETURN NEW;
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Error in handle_new_user: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();