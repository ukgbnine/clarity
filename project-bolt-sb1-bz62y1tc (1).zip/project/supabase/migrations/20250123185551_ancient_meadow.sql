/*
  # Add selected_monthly_weekdays column with validation

  1. Changes
    - Add selected_monthly_weekdays column to tasks table
    - Add validation function for weekday format
    - Drop existing trigger if it exists
    - Add validation trigger

  2. Details
    - Column type: text[] (array of strings)
    - Default value: empty array
    - Valid format: 'first-monday', 'second-tuesday', etc.
*/

-- Drop existing trigger and function if they exist
DROP TRIGGER IF EXISTS validate_monthly_weekdays_trigger ON tasks;
DROP FUNCTION IF EXISTS validate_monthly_weekdays();
DROP FUNCTION IF EXISTS validate_weekday_format();

-- Create function to validate weekday format
CREATE OR REPLACE FUNCTION validate_weekday_format(weekday text)
RETURNS boolean AS $$
BEGIN
  RETURN weekday ~ '^(first|second|third|fourth|last)-(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$';
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add column with validation
ALTER TABLE tasks
ADD COLUMN IF NOT EXISTS selected_monthly_weekdays text[] DEFAULT '{}'::text[];

-- Add validation trigger function
CREATE OR REPLACE FUNCTION validate_monthly_weekdays()
RETURNS trigger AS $$
BEGIN
  IF NEW.selected_monthly_weekdays IS NOT NULL AND array_length(NEW.selected_monthly_weekdays, 1) > 0 THEN
    FOR i IN 1..array_length(NEW.selected_monthly_weekdays, 1) LOOP
      IF NOT validate_weekday_format(NEW.selected_monthly_weekdays[i]) THEN
        RAISE EXCEPTION 'Invalid weekday format at index %: %', i, NEW.selected_monthly_weekdays[i];
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER validate_monthly_weekdays_trigger
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW
EXECUTE FUNCTION validate_monthly_weekdays();