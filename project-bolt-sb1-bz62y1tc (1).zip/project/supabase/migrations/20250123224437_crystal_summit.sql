-- Drop existing RLS policies for goals
DROP POLICY IF EXISTS "Goals are viewable by owner" ON goals;
DROP POLICY IF EXISTS "Users can create goals" ON goals;
DROP POLICY IF EXISTS "Users can update own goals" ON goals;
DROP POLICY IF EXISTS "Users can delete own goals" ON goals;

-- Create improved RLS policies for goals
CREATE POLICY "Goals are viewable by owner"
  ON goals FOR SELECT
  USING (
    auth.uid() = user_id
  );

CREATE POLICY "Users can create goals"
  ON goals FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can update own goals"
  ON goals FOR UPDATE
  USING (
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can delete own goals"
  ON goals FOR DELETE
  USING (
    auth.uid() = user_id AND
    auth.role() = 'authenticated'
  );

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_goals_updated_at
  BEFORE UPDATE ON goals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Ensure proper grants
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON TABLE goals TO authenticated;
GRANT ALL ON TABLE goals TO service_role;

-- Force schema cache refresh
NOTIFY pgrst, 'reload schema';