/*
  # Fix Schema Issues

  1. Changes
    - Add missing columns to tasks and goals tables
    - Ensure all columns use snake_case naming
    - Add proper indexes for performance

  2. Security
    - Maintain existing RLS policies
*/

-- Safe schema updates using DO blocks
DO $$ 
BEGIN
  -- Add target_date to goals if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public'
    AND table_name = 'goals' 
    AND column_name = 'target_date'
  ) THEN
    ALTER TABLE goals 
    ADD COLUMN target_date text;
  END IF;

  -- Add selected_monthly_weekdays to tasks if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public'
    AND table_name = 'tasks' 
    AND column_name = 'selected_monthly_weekdays'
  ) THEN
    ALTER TABLE tasks 
    ADD COLUMN selected_monthly_weekdays text[] DEFAULT '{}'::text[];
  END IF;
END $$;

-- Add indexes for performance if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'goals' 
    AND indexname = 'idx_goals_target_date'
  ) THEN
    CREATE INDEX idx_goals_target_date ON goals(target_date);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tasks' 
    AND indexname = 'idx_tasks_dates'
  ) THEN
    CREATE INDEX idx_tasks_dates ON tasks USING GIN(dates);
  END IF;
END $$;