/*
  # Fix task_logs table structure

  1. Changes
    - Drop and recreate task_logs table with correct column names
    - Add proper foreign key constraints
    - Add indexes for performance
    - Update RLS policies

  2. Security
    - Enable RLS
    - Add policies for proper access control
*/

-- Drop existing table and policies
DROP TABLE IF EXISTS task_logs CASCADE;

-- Recreate task_logs table
CREATE TABLE task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  status text CHECK (status IN ('completed', 'uncompleted')) NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  UNIQUE(task_id, date)
);

-- Enable RLS
ALTER TABLE task_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own task logs"
  ON task_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own task logs"
  ON task_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own task logs"
  ON task_logs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own task logs"
  ON task_logs FOR DELETE
  USING (auth.uid() = user_id);

-- Add indexes for performance
CREATE INDEX idx_task_logs_task_id ON task_logs(task_id);
CREATE INDEX idx_task_logs_user_id ON task_logs(user_id);
CREATE INDEX idx_task_logs_date ON task_logs(date);
CREATE INDEX idx_task_logs_status ON task_logs(status);