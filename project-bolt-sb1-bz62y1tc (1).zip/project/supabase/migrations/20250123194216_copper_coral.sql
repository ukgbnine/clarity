/*
# Fix Tasks Dates Column

1. Changes
  - Modify dates column to properly handle date arrays
  - Add validation for date format
  - Add appropriate indexes

2. Details
  - Ensures dates are stored in ISO format
  - Adds performance optimization indexes
*/

-- Safe schema update using DO block
DO $$ 
BEGIN
  -- First convert dates to text array if needed
  ALTER TABLE tasks 
  ALTER COLUMN dates TYPE text[] USING dates::text[];

  -- Then convert text array to date array with simple USING clause
  ALTER TABLE tasks 
  ALTER COLUMN dates TYPE date[] USING dates::date[];

  -- Set default value
  ALTER TABLE tasks 
  ALTER COLUMN dates SET DEFAULT '{}'::date[];
END $$;

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_tasks_dates_gin 
ON tasks USING GIN(dates);