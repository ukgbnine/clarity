import React from 'react';
import { HomePage } from './pages/HomePage';
import { PlanningPage } from './pages/PlanningPage';
import { SocialPage } from './pages/SocialPage';
import { SettingsPage } from './pages/SettingsPage';
import { ProfilePage } from './pages/ProfilePage';
import { LandingPage } from './pages/LandingPage';
import { Sidebar } from './components/navigation/Sidebar';
import { TasksProvider } from './contexts/TasksContext';
import { GoalsProvider } from './contexts/GoalsContext';
import { TaskLogProvider } from './features/task-logging/contexts/TaskLogContext';
import { AuthProvider } from './contexts/AuthContext';
import { useAuth } from './contexts/AuthContext';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = React.useState<'home' | 'planning' | 'social' | 'settings' | 'profile'>('home');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LandingPage />;
  }

  return (
    <TaskLogProvider>
      <GoalsProvider>
        <TasksProvider>
          <div className="min-h-screen bg-[#f5f5f5]">
            <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
            <main className="pl-44">
              <div className="p-8">
                {currentPage === 'home' && <HomePage />}
                {currentPage === 'planning' && <PlanningPage />}
                {currentPage === 'social' && <SocialPage />}
                {currentPage === 'profile' && <ProfilePage />}
                {currentPage === 'settings' && <SettingsPage />}
              </div>
            </main>
          </div>
        </TasksProvider>
      </GoalsProvider>
    </TaskLogProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}