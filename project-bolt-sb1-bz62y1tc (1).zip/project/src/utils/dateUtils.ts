export function getWeekDays(date: Date): Date[] {
  const current = new Date(date);
  const days: Date[] = [];
  
  // Get Monday of the week
  current.setDate(current.getDate() - current.getDay() + (current.getDay() === 0 ? -6 : 1));
  
  // Get all days of the week
  for (let i = 0; i < 7; i++) {
    days.push(new Date(current));
    current.setDate(current.getDate() + 1);
  }
  
  return days;
}

export function formatDayName(date: Date): string {
  return date.toLocaleDateString('en-US', { weekday: 'short' });
}

export function formatDayNumber(date: Date): string {
  return date.getDate().toString();
}

export function formatFullDate(date: Date): string {
  return `${date.toLocaleDateString('en-US', { weekday: 'long' })} ${date.getDate()} ${date.toLocaleDateString('en-US', { month: 'long' })}`;
}

export function formatDateRange(startDate: Date, endDate: Date): string {
  const start = startDate.toLocaleDateString('en-US', { 
    month: 'short',
    day: 'numeric',
  });
  
  const end = endDate.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
  
  return `${start} - ${end}`;
}