import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Task = Database['public']['Tables']['tasks']['Row'];

interface TasksContextType {
  tasks: Task[];
  loading: boolean;
  error: string | null;
  addTask: (task: Omit<Task, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'order'>) => Promise<string>;
  updateTask: (id: string, task: Partial<Task>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  reorderTasks: (tasks: Task[]) => Promise<void>;
  fetchTasks: () => Promise<void>;
}

const TasksContext = createContext<TasksContextType | undefined>(undefined);

export function TasksProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setTasks([]);
        return;
      }

      const { data, error: fetchError } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', user.id)
        .order('order', { ascending: true });

      if (fetchError) throw fetchError;

      // Parse dates array from strings to Date objects
      const parsedTasks = data?.map(task => ({
        ...task,
        dates: task.dates.map((date: string) => new Date(date)),
      })) || [];

      setTasks(parsedTasks);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      setTasks([]); // Ensure we have a clean state
    } finally {
      setLoading(false);
    }
  };

  // Fetch tasks when mounted and when auth state changes
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') {
        fetchTasks();
      } else if (event === 'SIGNED_OUT') {
        setTasks([]);
      }
    });

    fetchTasks();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const addTask = async (task: Omit<Task, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'order'>) => {
    try {
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Format dates for database
      const formattedDates = task.dates.map(date => 
        date instanceof Date 
          ? date.toISOString().split('T')[0] 
          : new Date(date).toISOString().split('T')[0]
      );

      // Get max order
      const maxOrder = Math.max(...tasks.map(t => t.order ?? 0), -1);

      // Create task data
      const taskData = {
        name: task.name,
        type: task.type,
        frequency: task.frequency,
        dates: formattedDates,
        timeframe: task.timeframe,
        goal_id: task.goal_id,
        user_id: user.id,
        order: maxOrder + 1,
      };

      const { data, error: insertError } = await supabase
        .from('tasks')
        .insert(taskData)
        .select()
        .single();

      if (insertError) throw insertError;

      // Parse dates back to Date objects
      const parsedTask = {
        ...data,
        dates: data.dates.map((date: string) => new Date(date)),
      };

      setTasks(prev => [...prev, parsedTask]);
      return parsedTask.id;
    } catch (error) {
      console.error('Error adding task:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    try {
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Format dates for database if they exist in updates
      const formattedUpdates = {
        ...updates,
        dates: updates.dates?.map(date => 
          date instanceof Date 
            ? date.toISOString().split('T')[0]
            : new Date(date).toISOString().split('T')[0]
        ),
        updated_at: new Date().toISOString(),
      };

      const { error: updateError } = await supabase
        .from('tasks')
        .update(formattedUpdates)
        .eq('id', id)
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      setTasks(prev => prev.map(task =>
        task.id === id
          ? {
              ...task,
              ...updates,
              dates: updates.dates || task.dates,
            }
          : task
      ));
    } catch (error) {
      console.error('Error updating task:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const deleteTask = async (id: string) => {
    try {
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      setTasks(prev => prev.filter(task => task.id !== id));
    } catch (error) {
      console.error('Error deleting task:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const reorderTasks = async (reorderedTasks: Task[]) => {
    try {
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Update local state immediately for better UX
      setTasks(reorderedTasks);

      // Prepare batch updates
      const updates = reorderedTasks.map((task, index) => ({
        id: task.id,
        order: index,
      }));

      // Update each task's order in the database
      await Promise.all(
        updates.map(update =>
          supabase
            .from('tasks')
            .update({ order: update.order })
            .eq('id', update.id)
            .eq('user_id', user.id)
        )
      );
    } catch (error) {
      console.error('Error reordering tasks:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      // Revert local state on error
      await fetchTasks();
      throw error;
    }
  };

  return (
    <TasksContext.Provider value={{
      tasks,
      loading,
      error,
      addTask,
      updateTask,
      deleteTask,
      reorderTasks,
      fetchTasks,
    }}>
      {children}
    </TasksContext.Provider>
  );
}

export function useTasks() {
  const context = useContext(TasksContext);
  if (context === undefined) {
    throw new Error('useTasks must be used within a TasksProvider');
  }
  return context;
}