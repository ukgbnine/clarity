import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Goal = Database['public']['Tables']['goals']['Row'];

interface GoalsContextType {
  goals: Goal[];
  loading: boolean;
  error: string | null;
  addGoal: (goal: { name: string; target_date?: string }) => Promise<string>;
  updateGoal: (id: string, goal: Partial<Omit<Goal, 'id' | 'user_id' | 'created_at' | 'updated_at'>>) => Promise<void>;
  deleteGoal: (id: string) => Promise<void>;
  reorderGoals: (goals: Goal[]) => Promise<void>;
  markGoalAchieved: (id: string, achievementDate: string) => Promise<void>;
  fetchGoals: () => Promise<void>;
}

const GoalsContext = createContext<GoalsContextType | undefined>(undefined);

export function GoalsProvider({ children }: { children: React.ReactNode }) {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchGoals = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        setGoals([]);
        return;
      }

      const { data, error: fetchError } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', session.user.id)
        .order('order', { ascending: true });

      if (fetchError) throw fetchError;

      setGoals(data || []);
    } catch (error) {
      console.error('Error fetching goals:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        await fetchGoals();
      } else if (event === 'SIGNED_OUT') {
        setGoals([]);
      }
    });

    fetchGoals();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const addGoal = async ({ name, target_date }: { name: string; target_date?: string }): Promise<string> => {
    try {
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No authenticated user');

      // Get max order
      const maxOrder = Math.max(...goals.map(g => g.order ?? 0), -1);

      // Create the goal
      const { data, error: insertError } = await supabase
        .from('goals')
        .insert([{
          name: name.trim(),
          target_date: target_date?.trim(),
          user_id: session.user.id,
          order: maxOrder + 1,
          achieved: false
        }])
        .select()
        .single();

      if (insertError) throw insertError;
      if (!data) throw new Error('No data returned from insert');

      // Update local state
      setGoals(prev => [...prev, data]);

      // Return the new goal ID
      return data.id;
    } catch (error) {
      console.error('Error adding goal:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const updateGoal = async (id: string, updates: Partial<Omit<Goal, 'id' | 'user_id' | 'created_at' | 'updated_at'>>) => {
    try {
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No authenticated user');

      const { error: updateError } = await supabase
        .from('goals')
        .update(updates)
        .eq('id', id)
        .eq('user_id', session.user.id);

      if (updateError) throw updateError;

      setGoals(prev => prev.map(goal =>
        goal.id === id ? { ...goal, ...updates } : goal
      ));
    } catch (error) {
      console.error('Error updating goal:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const deleteGoal = async (id: string) => {
    try {
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No authenticated user');

      const { error: deleteError } = await supabase
        .from('goals')
        .delete()
        .eq('id', id)
        .eq('user_id', session.user.id);

      if (deleteError) throw deleteError;

      setGoals(prev => prev.filter(goal => goal.id !== id));
    } catch (error) {
      console.error('Error deleting goal:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  const reorderGoals = async (reorderedGoals: Goal[]) => {
    try {
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No authenticated user');

      // Update local state immediately for better UX
      setGoals(reorderedGoals);

      // Prepare batch updates
      const updates = reorderedGoals.map((goal, index) => ({
        id: goal.id,
        order: index,
      }));

      // Update each goal's order in the database
      await Promise.all(
        updates.map(update =>
          supabase
            .from('goals')
            .update({ order: update.order })
            .eq('id', update.id)
            .eq('user_id', session.user.id)
        )
      );
    } catch (error) {
      console.error('Error reordering goals:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      // Revert local state on error
      await fetchGoals();
      throw error;
    }
  };

  const markGoalAchieved = async (id: string, achievementDate: string) => {
    try {
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No authenticated user');

      const { error: updateError } = await supabase
        .from('goals')
        .update({
          achieved: true,
          achievement_date: achievementDate
        })
        .eq('id', id)
        .eq('user_id', session.user.id);

      if (updateError) throw updateError;

      setGoals(prev => prev.map(goal =>
        goal.id === id
          ? { ...goal, achieved: true, achievement_date: achievementDate }
          : goal
      ));
    } catch (error) {
      console.error('Error marking goal as achieved:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
      throw error;
    }
  };

  return (
    <GoalsContext.Provider value={{
      goals,
      loading,
      error,
      addGoal,
      updateGoal,
      deleteGoal,
      reorderGoals,
      markGoalAchieved,
      fetchGoals,
    }}>
      {children}
    </GoalsContext.Provider>
  );
}

export function useGoals() {
  const context = useContext(GoalsContext);
  if (context === undefined) {
    throw new Error('useGoals must be used within a GoalsProvider');
  }
  return context;
}