import React, { useState } from 'react';
import { OverviewGoalsSection } from '../components/planning/OverviewGoalsSection';
import { TasksAndHabitsSection } from '../components/planning/tasks-and-habits/TasksAndHabitsSection';

interface CreateGoalModalState {
  isOpen: boolean;
  onGoalCreated?: (goalId: string) => void;
}

export function PlanningPage() {
  const [createGoalModal, setCreateGoalModal] = useState<CreateGoalModalState>({
    isOpen: false,
  });

  return (
    <div className="flex flex-col gap-8">
      <OverviewGoalsSection
        createGoalModal={createGoalModal}
        onCreateGoalModalClose={() => setCreateGoalModal({ isOpen: false })}
      />
      <TasksAndHabitsSection
        setCreateGoalModal={setCreateGoalModal}
      />
    </div>
  );
}

// Export the state type for use in other components
export type { CreateGoalModalState };