import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { HomeGoalsSection } from '../components/planning/HomeGoalsSection';
import { DailyView } from '../components/planning/tasks-and-habits/DailyView';
import { HomeFlexibleTasksSection } from '../components/planning/tasks-and-habits/HomeFlexibleTasksSection';
import { EditTaskModal } from '../components/planning/tasks-and-habits/EditTaskModal';
import { CreateTaskHabitModal } from '../components/planning/tasks-and-habits/CreateTaskHabitModal';
import { DailyMantras } from '../features/daily-mantras/components/DailyMantras';
import { ConsistencyScore } from '../features/consistency/components/ConsistencyScore';
import { SharedJourney } from '../features/shared-journey/components/SharedJourney';

export function HomePage() {
  const [createGoalModal, setCreateGoalModal] = useState({
    isOpen: false,
  });
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  return (
    <div className="flex gap-8">
      {/* Left Column (2/3) */}
      <div className="flex-[2] space-y-8">
        <HomeGoalsSection
          createGoalModal={createGoalModal}
          onCreateGoalModalClose={() => setCreateGoalModal({ isOpen: false })}
        />
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl">
              <span className="font-medium text-gray-900">Tasks & Habits</span>
              <span className="font-light text-gray-500 italic ml-2 tracking-wide">- how you're going to do it</span>
            </h2>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
              aria-label="Create new task or habit"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          <DailyView onTaskClick={setEditingTaskId} />
          <HomeFlexibleTasksSection onTaskClick={setEditingTaskId} />
          <DailyMantras />
        </div>
      </div>

      {/* Right Column (1/3) */}
      <div className="flex-1 space-y-8">
        <ConsistencyScore />
        <SharedJourney />
      </div>

      <CreateTaskHabitModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        setCreateGoalModal={setCreateGoalModal}
      />

      {editingTaskId && (
        <EditTaskModal
          isOpen={true}
          onClose={() => setEditingTaskId(null)}
          taskId={editingTaskId}
          setCreateGoalModal={setCreateGoalModal}
        />
      )}
    </div>
  );
}