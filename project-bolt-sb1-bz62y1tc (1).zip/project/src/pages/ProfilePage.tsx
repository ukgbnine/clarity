import React, { useState, useEffect } from 'react';
import { Medal, Trophy, Loader2, Settings } from 'lucide-react';
import { useTaskLogStore } from '../features/task-logging/stores/taskLogStore';
import { useTasks } from '../contexts/TasksContext';
import { SocialFeed } from '../features/social-feed/components/SocialFeed';
import { ProfileAccolades } from '../features/profile/components/ProfileAccolades';
import { MyJourney } from '../features/profile/components/MyJourney';
import { useProfileAccoladesStore } from '../features/profile/stores/profileAccoladesStore';
import { TimelinePage } from './TimelinePage';
import { ProfileManagementModal } from '../features/profile/components/ProfileManagementModal';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

export function ProfilePage() {
  const [showTimeline, setShowTimeline] = useState(false);
  const [isManagementModalOpen, setIsManagementModalOpen] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { tasks } = useTasks();
  const logs = useTaskLogStore(state => state.logs);
  const { checkWeeklyAccolade } = useProfileAccoladesStore();

  useEffect(() => {
    async function getProfile() {
      try {
        if (!user) return;

        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
          return;
        }

        setProfile(data);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    }

    getProfile();
  }, [user]);

  // Calculate the user's consistency score
  const calculateScore = () => {
    // Calculate the date range (past 7 days)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);

    // Get all fixed tasks/habits scheduled in the past 7 days
    const scheduledTasks = tasks
      .filter(task => task.type !== 'flexible')
      .flatMap(task => {
        return task.dates
          .filter(date => {
            const taskDate = new Date(date);
            taskDate.setHours(0, 0, 0, 0);
            return taskDate >= sevenDaysAgo && taskDate <= today;
          })
          .map(date => ({
            taskId: task.id,
            date: new Date(date).toISOString().split('T')[0],
          }));
      });

    if (scheduledTasks.length === 0) {
      return 0;
    }

    // Count completed tasks
    const completedCount = scheduledTasks.reduce((count, { taskId, date }) => {
      const isCompleted = logs.some(
        log => log.taskId === taskId && log.date === date && log.status === 'completed'
      );
      return isCompleted ? count + 1 : count;
    }, 0);

    // Calculate percentage
    return Math.round((completedCount / scheduledTasks.length) * 100);
  };

  const score = calculateScore();

  // Check for weekly accolade whenever the score changes
  useEffect(() => {
    checkWeeklyAccolade(score);
  }, [score, checkWeeklyAccolade]);

  // Get consistency icon based on score
  const getConsistencyIcon = () => {
    if (score < 25) {
      return <Loader2 className="w-10 h-10 text-gray-400" />;
    } else if (score < 55) {
      return <Medal className="w-10 h-10 text-gray-400" />;
    } else if (score < 100) {
      return <Medal className="w-10 h-10 text-orange-500" />;
    } else {
      return <Trophy className="w-10 h-10 text-orange-500" />;
    }
  };

  if (showTimeline) {
    return <TimelinePage onBack={() => setShowTimeline(false)} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div>
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8 group">
        <div className="p-6 flex items-center gap-6">
          {/* Profile Picture */}
          <div className="w-24 h-24 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-2xl font-medium">
                {profile?.full_name?.[0]?.toUpperCase() || profile?.username?.[0]?.toUpperCase() || '?'}
              </div>
            )}
          </div>

          {/* User Info with Settings Button */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-medium text-gray-900">
                {profile?.full_name || profile?.username || 'Anonymous User'}
              </h1>
              <button
                onClick={() => setIsManagementModalOpen(true)}
                className="p-2 text-gray-400 hover:text-gray-900 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                aria-label="Manage profile"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
            {profile?.username && (
              <p className="text-sm text-gray-500 mt-1">@{profile.username}</p>
            )}
          </div>

          {/* Consistency Icon */}
          {getConsistencyIcon()}
        </div>
      </div>

      {/* Profile Content */}
      <div className="grid grid-cols-2 gap-8">
        {/* Left Column - Posts Feed */}
        <div>
          <SocialFeed userId={user?.id} />
        </div>

        {/* Right Column - Additional Content */}
        <div className="space-y-8">
          <ProfileAccolades />
          <MyJourney onTimelineClick={() => setShowTimeline(true)} />
        </div>
      </div>

      {/* Profile Management Modal */}
      <ProfileManagementModal
        isOpen={isManagementModalOpen}
        onClose={() => setIsManagementModalOpen(false)}
      />
    </div>
  );
}