import React, { useState } from 'react';
import { AuthModal } from '../components/auth/AuthModal';

export function LandingPage() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-orange-50 to-white">
      <div className="text-center space-y-6">
        <h1 className="text-6xl font-medium text-gray-900">
          Clarity_MVP
        </h1>
        <p className="text-xl text-gray-600">
          Your life's journey
        </p>
        <div>
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-6 py-2.5 text-base font-medium text-white bg-orange-500 rounded-lg hover:bg-orange-600 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-lg"
          >
            Gain Clarity
          </button>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}