import React, { useState } from 'react';
import { SharedJourney } from '../features/shared-journey/components/SharedJourney';
import { Groups } from '../features/groups/components/Groups';
import { ClubsAndChallenges } from '../features/challenges/components/Challenges';
import { SocialFeed } from '../features/social-feed/components/SocialFeed';
import { GroupPage } from '../features/groups/components/GroupPage';

export function SocialPage() {
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);

  if (selectedGroupId) {
    return (
      <GroupPage 
        groupId={selectedGroupId} 
        onBack={() => setSelectedGroupId(null)} 
      />
    );
  }

  return (
    <div className="grid grid-cols-2 gap-8">
      {/* Left Column */}
      <div className="space-y-8">
        <SocialFeed />
      </div>

      {/* Right Column */}
      <div className="space-y-8">
        <SharedJourney />
        <Groups onGroupSelect={setSelectedGroupId} />
        <ClubsAndChallenges />
      </div>
    </div>
  );
}