import React, { useState } from 'react';
import { Trash2, Umbrella, LogOut } from 'lucide-react';
import { Modal } from '../components/ui/Modal';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

export function SettingsPage() {
  const [isConfirmResetOpen, setIsConfirmResetOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const { signOut } = useAuth();

  const handleDataReset = async () => {
    try {
      setIsResetting(true);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        throw new Error('No authenticated user');
      }

      // Delete all tasks and logs
      await supabase
        .from('task_logs')
        .delete()
        .eq('user_id', session.user.id);

      await supabase
        .from('tasks')
        .delete()
        .eq('user_id', session.user.id);

      // Delete all goals
      await supabase
        .from('goals')
        .delete()
        .eq('user_id', session.user.id);

      // Delete all milestones
      await supabase
        .from('milestones')
        .delete()
        .eq('user_id', session.user.id);

      // Delete all posts
      await supabase
        .from('posts')
        .delete()
        .eq('user_id', session.user.id);

      // Clear local storage except for auth and friend data
      const authData = localStorage.getItem('sb-vpkmnelcatjketdisaii-auth-token');
      const friendsData = localStorage.getItem('friends-data');
      localStorage.clear();
      if (authData) localStorage.setItem('sb-vpkmnelcatjketdisaii-auth-token', authData);
      if (friendsData) localStorage.setItem('friends-data', friendsData);

      // Reload the page to reset all stores
      window.location.reload();
    } catch (error) {
      console.error('Error resetting data:', error);
      alert('Failed to reset data. Please try again.');
    } finally {
      setIsResetting(false);
      setIsConfirmResetOpen(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-medium text-gray-900 mb-8">Settings</h1>

      <section className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-6">
        <div className="px-6 py-5 space-y-6">
          {/* Away Mode */}
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-900">
                Away Mode <span className="text-sm font-normal text-gray-500">(functionality coming soon)</span>
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                Pause your tasks and habits while you're away
              </p>
            </div>
            <button
              disabled
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-white border border-blue-300 rounded-md hover:bg-blue-50 cursor-not-allowed opacity-60"
            >
              <Umbrella className="w-4 h-4" />
              Away
            </button>
          </div>

          {/* Reset Data */}
          <div className="flex items-center justify-between pt-6 border-t">
            <div>
              <h3 className="text-sm font-medium text-gray-900">Reset All Data</h3>
              <p className="mt-1 text-sm text-gray-500">
                Delete all your tasks, habits, goals, and posts. Your friends and groups will be preserved.
              </p>
            </div>
            <button
              onClick={() => setIsConfirmResetOpen(true)}
              disabled={isResetting}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Trash2 className="w-4 h-4" />
              {isResetting ? 'Resetting...' : 'Reset Data'}
            </button>
          </div>

          {/* Logout */}
          <div className="flex items-center justify-between pt-6 border-t">
            <div>
              <h3 className="text-sm font-medium text-gray-900">Logout</h3>
              <p className="mt-1 text-sm text-gray-500">
                Sign out of your account
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </section>

      <Modal
        isOpen={isConfirmResetOpen}
        onClose={() => setIsConfirmResetOpen(false)}
        title="Reset All Data"
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            Are you sure you want to reset all data? This will:
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Delete all your tasks and habits</li>
            <li>Delete all your goals</li>
            <li>Delete all your posts</li>
            <li>Reset all settings to default</li>
          </ul>
          <p className="text-sm text-gray-600">
            Your friends and groups will be preserved.
          </p>
          <p className="text-sm text-red-600 font-medium">
            This action cannot be undone.
          </p>
          <div className="flex justify-end gap-3 pt-4">
            <button
              onClick={() => setIsConfirmResetOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleDataReset}
              disabled={isResetting}
              className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isResetting ? 'Resetting...' : 'Reset All Data'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}