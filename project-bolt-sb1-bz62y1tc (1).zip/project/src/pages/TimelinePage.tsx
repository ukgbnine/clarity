import React, { useState, useEffect } from 'react';
import { ArrowLeft, Plus, Calendar, Pencil, Trash2, Trophy } from 'lucide-react';
import { useGoals } from '../contexts/GoalsContext';
import { Modal } from '../components/ui/Modal';
import { GoalCard } from '../components/planning/GoalCard';
import { useMilestonesStore } from '../features/profile/stores/milestonesStore';
import { ConfirmationModal } from '../components/ui/ConfirmationModal';

interface TimelinePageProps {
  onBack: () => void;
}

export function TimelinePage({ onBack }: TimelinePageProps) {
  const { goals, updateGoal, deleteGoal } = useGoals();
  const { milestones, addMilestone, updateMilestone, deleteMilestone } = useMilestonesStore();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<{
    type: 'goal' | 'milestone';
    id: string;
    name: string;
    date: string;
  } | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{
    type: 'goal' | 'milestone';
    id: string;
    name: string;
  } | null>(null);
  const [newMilestone, setNewMilestone] = useState({
    name: '',
    date: '',
  });
  const [activeFilter, setActiveFilter] = useState<'all' | 'goals' | 'milestones'>('all');

  // Load milestones on mount
  useEffect(() => {
    const { fetchMilestones } = useMilestonesStore.getState();
    fetchMilestones();
  }, []);

  // Get achieved goals
  const achievedGoals = goals.filter(goal => goal.achieved);

  // Combine goals and milestones and sort by date
  const timelineItems = [
    ...achievedGoals.map(goal => ({
      type: 'goal' as const,
      id: goal.id,
      name: goal.name,
      date: goal.achievementDate || goal.targetDate || '',
      achieved: true,
      goal: goal,
    })),
    ...milestones.map(milestone => ({
      type: 'milestone' as const,
      id: milestone.id,
      name: milestone.name,
      date: milestone.date,
    })),
  ]
  .filter(item => {
    if (activeFilter === 'goals') return item.type === 'goal';
    if (activeFilter === 'milestones') return item.type === 'milestone';
    return true;
  })
  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleCreateMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestone.name.trim() || !newMilestone.date.trim()) return;

    addMilestone({
      name: newMilestone.name.trim(),
      date: newMilestone.date.trim(),
    });

    setNewMilestone({ name: '', date: '' });
    setIsCreateModalOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !editingItem.name.trim() || !editingItem.date.trim()) return;

    if (editingItem.type === 'goal') {
      updateGoal(editingItem.id, {
        name: editingItem.name.trim(),
        targetDate: editingItem.date.trim(),
      });
    } else {
      updateMilestone(editingItem.id, {
        name: editingItem.name.trim(),
        date: editingItem.date.trim(),
      });
    }

    setEditingItem(null);
  };

  const handleDelete = () => {
    if (!itemToDelete) return;

    if (itemToDelete.type === 'goal') {
      deleteGoal(itemToDelete.id);
    } else {
      deleteMilestone(itemToDelete.id);
    }

    setItemToDelete(null);
    setIsDeleteModalOpen(false);
  };

  return (
    <div>
      {/* Back Button */}
      <button
        onClick={onBack}
        className="mb-6 inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="text-sm font-medium">Back to Profile</span>
      </button>

      {/* Section Titles */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <button
          onClick={() => setActiveFilter(activeFilter === 'goals' ? 'all' : 'goals')}
          className={`text-xl font-medium text-center py-2 px-4 rounded-lg transition-colors ${
            activeFilter === 'goals'
              ? 'text-orange-600 bg-orange-50'
              : 'text-gray-900 hover:text-orange-600 hover:bg-orange-50'
          }`}
        >
          Achieved Goals
        </button>
        <div className="flex items-center justify-between w-full">
          <div className="flex-1 flex items-center justify-center">
            <button
              onClick={() => setActiveFilter(activeFilter === 'milestones' ? 'all' : 'milestones')}
              className={`text-xl font-medium py-2 px-4 rounded-lg transition-colors ${
                activeFilter === 'milestones'
                  ? 'text-orange-600 bg-orange-50'
                  : 'text-gray-900 hover:text-orange-600 hover:bg-orange-50'
              }`}
            >
              Milestones
            </button>
          </div>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
            aria-label="Add milestone"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gray-200" />

        {/* Timeline Items */}
        <div className="space-y-8">
          {timelineItems.map((item, index) => (
            <div key={item.id} className="relative">
              {/* Date Circle */}
              <div className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center">
                <div className="w-3 h-3 rounded-full bg-gray-300" />
                {index < timelineItems.length - 1 && (
                  <div className="h-[calc(100%+2rem)] w-px bg-gray-200" />
                )}
                <div className="absolute top-0 -translate-y-6 text-sm font-medium text-gray-500 whitespace-nowrap">
                  {item.date}
                </div>
              </div>

              {/* Content */}
              <div className="grid grid-cols-2 gap-8">
                {/* Left Side - Goals */}
                <div className={`relative ${item.type === 'milestone' ? 'opacity-0 pointer-events-none' : ''}`}>
                  {item.type === 'goal' && (
                    <div className="pr-12 relative group">
                      {/* Edit/Delete Buttons */}
                      <div className="absolute top-2 right-16 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2 z-10">
                        <button
                          onClick={() => setEditingItem({
                            type: 'goal',
                            id: item.id,
                            name: item.name,
                            date: item.date,
                          })}
                          className="p-1.5 text-gray-400 hover:text-gray-600 bg-white rounded-full hover:bg-gray-100 transition-colors border border-gray-200"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setItemToDelete({
                              type: 'goal',
                              id: item.id,
                              name: item.name,
                            });
                            setIsDeleteModalOpen(true);
                          }}
                          className="p-1.5 text-red-400 hover:text-red-600 bg-white rounded-full hover:bg-red-50 transition-colors border border-red-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="relative">
                        <GoalCard 
                          goal={item.goal}
                          onClick={() => {}}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Side - Milestones */}
                <div className={`relative ${item.type === 'goal' ? 'opacity-0 pointer-events-none' : ''}`}>
                  {item.type === 'milestone' && (
                    <div className="pl-12 relative group">
                      {/* Edit/Delete Buttons */}
                      <div className="absolute top-2 left-16 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2 z-10">
                        <button
                          onClick={() => setEditingItem({
                            type: 'milestone',
                            id: item.id,
                            name: item.name,
                            date: item.date,
                          })}
                          className="p-1.5 text-gray-400 hover:text-gray-600 bg-white rounded-full hover:bg-gray-100 transition-colors border border-gray-200"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setItemToDelete({
                              type: 'milestone',
                              id: item.id,
                              name: item.name,
                            });
                            setIsDeleteModalOpen(true);
                          }}
                          className="p-1.5 text-red-400 hover:text-red-600 bg-white rounded-full hover:bg-red-50 transition-colors border border-red-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg shadow-md border border-amber-300 p-4 flex items-center min-h-[88px] relative">
                        <Trophy className="w-6 h-6 text-white/90 absolute left-4" />
                        <h3 className="text-lg font-medium text-white text-center w-full">{item.name}</h3>
                        <Trophy className="w-6 h-6 text-white/90 absolute right-4" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Milestone Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Add Milestone"
      >
        <form onSubmit={handleCreateMilestone} className="space-y-6">
          {/* Milestone Name */}
          <div>
            <label htmlFor="milestoneName" className="block text-sm font-medium text-gray-700 mb-1">
              Milestone Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="milestoneName"
              value={newMilestone.name}
              onChange={(e) => setNewMilestone(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Enter milestone name"
              required
            />
          </div>

          {/* Milestone Date */}
          <div>
            <label htmlFor="milestoneDate" className="block text-sm font-medium text-gray-700 mb-1">
              Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                id="milestoneDate"
                value={newMilestone.date}
                onChange={(e) => setNewMilestone(prev => ({ ...prev, date: e.target.value }))}
                placeholder="e.g., March 15, 2024"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                required
              />
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!newMilestone.name.trim() || !newMilestone.date.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add Milestone
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Modal */}
      <Modal
        isOpen={!!editingItem}
        onClose={() => setEditingItem(null)}
        title={`Edit ${editingItem?.type === 'goal' ? 'Goal' : 'Milestone'}`}
      >
        <form onSubmit={handleEditSubmit} className="space-y-6">
          {/* Name Input */}
          <div>
            <label htmlFor="editName" className="block text-sm font-medium text-gray-700 mb-1">
              Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="editName"
              value={editingItem?.name || ''}
              onChange={(e) => setEditingItem(prev => prev ? { ...prev, name: e.target.value } : null)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              placeholder={`Enter ${editingItem?.type} name`}
              required
            />
          </div>

          {/* Date Input */}
          <div>
            <label htmlFor="editDate" className="block text-sm font-medium text-gray-700 mb-1">
              Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                id="editDate"
                value={editingItem?.date || ''}
                onChange={(e) => setEditingItem(prev => prev ? { ...prev, date: e.target.value } : null)}
                placeholder="e.g., March 15, 2024"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                required
              />
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => setEditingItem(null)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!editingItem?.name.trim() || !editingItem?.date.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setItemToDelete(null);
        }}
        onConfirm={handleDelete}
        title={`Delete ${itemToDelete?.type === 'goal' ? 'Goal' : 'Milestone'}`}
        message={`Are you sure you want to delete "${itemToDelete?.name}"? This action cannot be undone.`}
      />
    </div>
  );
}