import React, { useState, useRef, useEffect } from 'react';
import { Search, UserPlus, Image as ImageIcon } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';
import { useGroupsStore } from '../stores/groupsStore';

interface CreateGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreateGroupModal({ isOpen, onClose }: CreateGroupModalProps) {
  const [activeTab, setActiveTab] = useState<'create' | 'find'>('find');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<ReturnType<typeof useGroupsStore>['groups']>([]);
  const [searching, setSearching] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [groupImage, setGroupImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { createGroup, findGroups, joinGroup, isMember } = useGroupsStore();

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (searchQuery.trim()) {
        setSearching(true);
        try {
          const results = await findGroups(searchQuery);
          setSearchResults(results);
        } catch (error) {
          console.error('Error searching groups:', error);
        } finally {
          setSearching(false);
        }
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, findGroups]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image size should be less than 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setGroupImage(event.target?.result as string);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) return;

    try {
      setError(null);
      await createGroup(groupName, groupDescription, groupImage);
      setGroupName('');
      setGroupDescription('');
      setGroupImage(null);
      onClose();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
    }
  };

  const handleJoinGroup = async (groupId: string) => {
    try {
      setError(null);
      await joinGroup(groupId);
      onClose();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Join or Create Group">
      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-6">
        <button
          onClick={() => setActiveTab('find')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'find'
              ? 'text-orange-600 border-b-2 border-orange-500'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Find Group
        </button>
        <button
          onClick={() => setActiveTab('create')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'create'
              ? 'text-orange-600 border-b-2 border-orange-500'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Create Group
        </button>
      </div>

      {error && (
        <div className="mb-6 p-3 text-sm text-red-600 bg-red-50 rounded-md">
          {error}
        </div>
      )}

      {activeTab === 'find' ? (
        <div className="space-y-6">
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search groups..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          </div>

          {/* Search Results */}
          <div className="space-y-4">
            {searching ? (
              <div className="text-center py-8">
                <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-solid border-orange-400 border-r-transparent" />
              </div>
            ) : searchResults.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {searchQuery 
                  ? "No groups found matching your search"
                  : "Search for groups to join"}
              </div>
            ) : (
              searchResults.map(group => {
                const isGroupMember = isMember(group.id);

                return (
                  <div 
                    key={group.id}
                    className="p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-gray-900">{group.name}</h3>
                      <button
                        onClick={() => handleJoinGroup(group.id)}
                        disabled={isGroupMember}
                        className={`p-2 rounded-md transition-colors ${
                          isGroupMember
                            ? 'bg-gray-100 text-gray-400 cursor-default'
                            : 'bg-orange-50 text-orange-600 hover:bg-orange-100'
                        }`}
                      >
                        <UserPlus className="w-5 h-5" />
                      </button>
                    </div>
                    {group.description && (
                      <p className="text-sm text-gray-500">{group.description}</p>
                    )}
                    <div className="mt-2 text-xs text-gray-400">
                      {group.members.length} member{group.members.length !== 1 ? 's' : ''}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Group Image */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Group Photo
            </label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`relative aspect-[3/2] w-full rounded-lg cursor-pointer overflow-hidden ${
                groupImage ? 'bg-gray-100' : 'border-2 border-dashed border-gray-300 hover:border-gray-400'
              }`}
            >
              {groupImage ? (
                <>
                  <img 
                    src={groupImage} 
                    alt="Group preview" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <div className="text-white text-sm font-medium">Change Photo</div>
                  </div>
                </>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-gray-400" />
                  <div className="mt-2 text-sm font-medium text-gray-900">Choose Photo</div>
                  <div className="mt-1 text-xs text-gray-500">Click to upload</div>
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <p className="mt-2 text-xs text-gray-500">
              Recommended size: 1200x800px. Maximum file size: 5MB
            </p>
          </div>

          {/* Group Name */}
          <div>
            <label htmlFor="groupName" className="block text-sm font-medium text-gray-700 mb-1">
              Group Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="groupName"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Enter group name"
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              required
            />
          </div>

          {/* Group Description */}
          <div>
            <label htmlFor="groupDescription" className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              id="groupDescription"
              value={groupDescription}
              onChange={(e) => setGroupDescription(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              placeholder="What's this group about?"
            />
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!groupName.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Group
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
}