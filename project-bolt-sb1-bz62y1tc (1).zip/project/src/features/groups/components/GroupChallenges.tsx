import React, { useState } from 'react';
import { Plus, Target } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';
import { useGroupChallengesStore } from '../stores/groupChallengesStore';
import { GroupChallengeModal } from './GroupChallengeModal';

interface GroupChallengesProps {
  groupId: string;
  groupName: string;
}

export function GroupChallenges({ groupId, groupName }: GroupChallengesProps) {
  const { challenges, addChallenge } = useGroupChallengesStore();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedChallengeId, setSelectedChallengeId] = useState<string | null>(null);
  const [newChallenge, setNewChallenge] = useState({
    name: '',
    description: '',
    goal: {
      name: '',
      targetDate: '',
    },
    task: {
      name: '',
      type: 'habit' as const,
    },
  });

  // Filter challenges for this group
  const groupChallenges = challenges.filter(challenge => challenge.groupId === groupId);

  const handleCreateChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChallenge.name.trim() || !newChallenge.goal.name.trim() || !newChallenge.task.name.trim()) return;

    addChallenge({
      name: newChallenge.name.trim(),
      description: newChallenge.description.trim(),
      groupId,
      goal: {
        name: newChallenge.goal.name.trim(),
        targetDate: newChallenge.goal.targetDate.trim() || undefined,
      },
      task: {
        name: newChallenge.task.name.trim(),
        type: newChallenge.task.type,
      },
    });

    setIsCreateModalOpen(false);
    setNewChallenge({
      name: '',
      description: '',
      goal: {
        name: '',
        targetDate: '',
      },
      task: {
        name: '',
        type: 'habit',
      },
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">{groupName} Challenges</span>
        </h2>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="p-2.5 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
          aria-label="Create new challenge"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Challenges Grid */}
      <div className="grid grid-cols-2 gap-4">
        {groupChallenges.map(challenge => (
          <button
            key={challenge.id}
            onClick={() => setSelectedChallengeId(challenge.id)}
            className="aspect-[4/3] w-full bg-white rounded-lg shadow-sm border border-gray-200 hover:border-gray-300 transition-all hover:shadow-md relative group overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
              <Target className="w-8 h-8 text-white mb-2" />
              <h3 className="text-xl font-medium text-white">
                {challenge.name}
              </h3>
            </div>
          </button>
        ))}
      </div>

      {/* Create Challenge Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create Group Challenge"
      >
        <form onSubmit={handleCreateChallenge} className="space-y-6">
          {/* Challenge Name */}
          <div>
            <label htmlFor="challengeName" className="block text-sm font-medium text-gray-700 mb-1">
              Challenge Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="challengeName"
              value={newChallenge.name}
              onChange={(e) => setNewChallenge(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Enter challenge name"
              required
            />
          </div>

          {/* Challenge Description */}
          <div>
            <label htmlFor="challengeDescription" className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              id="challengeDescription"
              value={newChallenge.description}
              onChange={(e) => setNewChallenge(prev => ({ ...prev, description: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500 min-h-[100px] resize-none"
              placeholder="Describe what this challenge is about..."
            />
          </div>

          {/* Goal Section */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Challenge Goal</h3>
            
            {/* Goal Name */}
            <div>
              <label htmlFor="goalName" className="block text-sm font-medium text-gray-700 mb-1">
                Goal Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="goalName"
                value={newChallenge.goal.name}
                onChange={(e) => setNewChallenge(prev => ({ 
                  ...prev, 
                  goal: { ...prev.goal, name: e.target.value }
                }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                placeholder="What's the goal of this challenge?"
                required
              />
            </div>

            {/* Target Date */}
            <div>
              <label htmlFor="targetDate" className="block text-sm font-medium text-gray-700 mb-1">
                Target Date
              </label>
              <input
                type="text"
                id="targetDate"
                value={newChallenge.goal.targetDate}
                onChange={(e) => setNewChallenge(prev => ({ 
                  ...prev, 
                  goal: { ...prev.goal, targetDate: e.target.value }
                }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                placeholder="e.g., End of 2024, Next month..."
              />
            </div>
          </div>

          {/* Task Section */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Challenge Task/Habit</h3>
            
            {/* Task Name */}
            <div>
              <label htmlFor="taskName" className="block text-sm font-medium text-gray-700 mb-1">
                Task Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="taskName"
                value={newChallenge.task.name}
                onChange={(e) => setNewChallenge(prev => ({ 
                  ...prev, 
                  task: { ...prev.task, name: e.target.value }
                }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                placeholder="What should participants do?"
                required
              />
            </div>

            {/* Task Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Task Type
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setNewChallenge(prev => ({ 
                    ...prev, 
                    task: { ...prev.task, type: 'task' }
                  }))}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    newChallenge.task.type === 'task'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Task</div>
                  <div className="text-sm text-gray-500">One-time or specific dates</div>
                </button>
                <button
                  type="button"
                  onClick={() => setNewChallenge(prev => ({ 
                    ...prev, 
                    task: { ...prev.task, type: 'habit' }
                  }))}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    newChallenge.task.type === 'habit'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Habit</div>
                  <div className="text-sm text-gray-500">Recurring schedule</div>
                </button>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!newChallenge.name.trim() || !newChallenge.goal.name.trim() || !newChallenge.task.name.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Challenge
            </button>
          </div>
        </form>
      </Modal>

      {/* View/Join Challenge Modal */}
      {selectedChallengeId && (
        <GroupChallengeModal
          isOpen={true}
          onClose={() => setSelectedChallengeId(null)}
          challenge={challenges.find(c => c.id === selectedChallengeId)!}
        />
      )}
    </div>
  );
}