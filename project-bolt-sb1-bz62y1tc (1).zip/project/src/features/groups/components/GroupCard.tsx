import React, { useState, useEffect } from 'react';
import { useGroupsStore } from '../stores/groupsStore';

interface GroupCardProps {
  group: {
    id: string;
    name: string;
    members: string[];
    image?: string;
  };
}

export function GroupCard({ group }: GroupCardProps) {
  const { getGroupConsistencyScore } = useGroupsStore();
  const [consistencyScore, setConsistencyScore] = useState<number>(0);

  useEffect(() => {
    async function fetchScore() {
      const score = await getGroupConsistencyScore(group.id);
      setConsistencyScore(score);
    }
    fetchScore();
  }, [group.id, getGroupConsistencyScore]);

  return (
    <button
      className="aspect-[4/3] w-full bg-white rounded-lg shadow-sm border border-gray-200 hover:border-gray-300 transition-all hover:shadow-md relative group overflow-hidden"
    >
      {group.image && (
        <>
          <img
            src={group.image}
            alt={group.name}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
        </>
      )}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
        <h3 className="text-xl font-medium text-white mb-2">
          {group.name}
        </h3>
        <div className="text-xl font-medium text-orange-400">
          {consistencyScore}%
        </div>
      </div>
    </button>
  );
}