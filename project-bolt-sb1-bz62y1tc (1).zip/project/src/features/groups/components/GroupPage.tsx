import React, { useState } from 'react';
import { useGroupsStore } from '../stores/groupsStore';
import { SharedJourney } from '../../shared-journey/components/SharedJourney';
import { GroupFeed } from './GroupFeed';
import { GroupAccolades } from './GroupAccolades';
import { GroupChallenges } from './GroupChallenges';
import { GroupManagementModal } from './GroupManagementModal';
import { ArrowLeft, Users, Medal, Trophy, Loader2, Settings } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';

interface GroupPageProps {
  groupId: string;
  onBack: () => void;
}

export function GroupPage({ groupId, onBack }: GroupPageProps) {
  const { groups, getGroupConsistencyScore } = useGroupsStore();
  const [isMembersModalOpen, setIsMembersModalOpen] = useState(false);
  const [isManagementModalOpen, setIsManagementModalOpen] = useState(false);
  const group = groups.find(g => g.id === groupId);

  if (!group) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Get consistency icon based on score
  const getConsistencyIcon = (score: number) => {
    if (score < 25) {
      return <Loader2 className="w-5 h-5 text-gray-400" />;
    } else if (score < 55) {
      return <Medal className="w-5 h-5 text-gray-400" />;
    } else if (score < 100) {
      return <Medal className="w-5 h-5 text-orange-500" />;
    } else {
      return <Trophy className="w-5 h-5 text-orange-500" />;
    }
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="mb-6 inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors flex-shrink-0"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="text-sm font-medium">Back to Social</span>
      </button>

      {/* Main Content - Scrollable */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        <div className="grid grid-cols-[2fr_1fr] gap-8 h-full">
          {/* Left Column */}
          <div className="space-y-4">
            {/* Group Header */}
            <div className="relative h-48 rounded-lg overflow-hidden">
              {group.image && (
                <>
                  <img
                    src={group.image}
                    alt={group.name}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
                </>
              )}
              {/* Management Button */}
              <div className="absolute top-4 right-4 flex items-center gap-2">
                <button
                  onClick={() => setIsManagementModalOpen(true)}
                  className="p-2.5 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
                  aria-label="Manage group"
                >
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Group Stats Bar */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              {/* Group Info */}
              <div className="mb-6">
                <h1 className="text-2xl font-medium text-gray-900">{group.name}</h1>
                {group.description && (
                  <p className="mt-2 text-gray-600">{group.description}</p>
                )}
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between">
                {/* Consistency Score */}
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-50 rounded-lg">
                    {getConsistencyIcon(0)}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-600">Group Average</div>
                    <div className="text-2xl font-bold text-gray-900">
                      0%
                    </div>
                  </div>
                </div>

                {/* Members Button */}
                <button
                  onClick={() => setIsMembersModalOpen(true)}
                  className="flex items-center gap-3 px-4 py-2 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors"
                >
                  <div className="p-2 bg-white rounded-lg">
                    <Users className="w-5 h-5 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-600">Members</div>
                    <div className="text-xl font-bold text-gray-900">
                      {group.members?.length || 0}
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Group Feed */}
            <GroupFeed groupId={groupId} />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <SharedJourney groupId={groupId} />
            <GroupAccolades groupId={groupId} />
            <GroupChallenges groupId={groupId} groupName={group.name} />
          </div>
        </div>
      </div>

      {/* Members Modal */}
      <Modal
        isOpen={isMembersModalOpen}
        onClose={() => setIsMembersModalOpen(false)}
        title="Group Members"
      >
        <div className="space-y-4">
          {(group.members || []).map((memberId) => {
            // In a real app, you would fetch member details from a users store
            // For now, we'll use mock data
            const memberData = {
              id: memberId,
              name: memberId === '2' ? 'Michael Park' :
                    memberId === '3' ? 'Emma Wilson' :
                    memberId === '4' ? 'James Rodriguez' :
                    memberId === '5' ? 'Olivia Taylor' : 'Unknown Member',
              avatar: memberId === '2' ? 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop' :
                      memberId === '3' ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop' :
                      memberId === '4' ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop' :
                      memberId === '5' ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop' :
                      undefined
            };

            return (
              <div 
                key={memberId}
                className="flex items-center gap-4 p-4 bg-white rounded-lg border border-gray-200"
              >
                <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                  {memberData.avatar ? (
                    <img
                      src={memberData.avatar}
                      alt={memberData.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-xl font-medium">
                      {memberData.name[0]?.toUpperCase() || '?'}
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{memberData.name}</h3>
                </div>
              </div>
            );
          })}
        </div>
      </Modal>

      {/* Group Management Modal */}
      <GroupManagementModal
        isOpen={isManagementModalOpen}
        onClose={() => setIsManagementModalOpen(false)}
        groupId={groupId}
      />
    </div>
  );
}