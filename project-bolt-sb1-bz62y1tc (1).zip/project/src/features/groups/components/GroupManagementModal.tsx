import React, { useState, useRef } from 'react';
import { Modal } from '../../../components/ui/Modal';
import { ConfirmationModal } from '../../../components/ui/ConfirmationModal';
import { useGroupsStore } from '../stores/groupsStore';
import { Image as ImageIcon, Inbox, Trash2 } from 'lucide-react';

interface GroupManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  groupId: string;
}

export function GroupManagementModal({ isOpen, onClose, groupId }: GroupManagementModalProps) {
  const { groups, updateGroup, deleteGroup } = useGroupsStore();
  const group = groups.find(g => g.id === groupId);
  const [activeTab, setActiveTab] = useState<'settings' | 'inbox'>('settings');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [groupName, setGroupName] = useState(group?.name || '');
  const [groupDescription, setGroupDescription] = useState(group?.description || '');
  const [groupImage, setGroupImage] = useState<string | null>(group?.image || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!group) return null;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Image size should be less than 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setGroupImage(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) return;

    updateGroup(groupId, {
      name: groupName.trim(),
      description: groupDescription.trim() || undefined,
      image: groupImage,
    });

    onClose();
  };

  const handleDelete = () => {
    deleteGroup(groupId);
    setIsDeleteModalOpen(false);
    onClose();
  };

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} title="Group Management">
        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-6">
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'settings'
                ? 'text-orange-600 border-b-2 border-orange-500'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Settings
          </button>
          <button
            onClick={() => setActiveTab('inbox')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'inbox'
                ? 'text-orange-600 border-b-2 border-orange-500'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Join Requests
          </button>
        </div>

        {activeTab === 'settings' ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Group Image */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Group Photo
              </label>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`relative aspect-[3/2] w-full rounded-lg cursor-pointer overflow-hidden ${
                  groupImage ? 'bg-gray-100' : 'border-2 border-dashed border-gray-300 hover:border-gray-400'
                }`}
              >
                {groupImage ? (
                  <>
                    <img 
                      src={groupImage} 
                      alt="Group preview" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <div className="text-white text-sm font-medium">Change Photo</div>
                    </div>
                  </>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <ImageIcon className="w-8 h-8 text-gray-400" />
                    <div className="mt-2 text-sm font-medium text-gray-900">Choose Photo</div>
                    <div className="mt-1 text-xs text-gray-500">Click to upload</div>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              <p className="mt-2 text-xs text-gray-500">
                Recommended size: 1200x800px. Maximum file size: 5MB
              </p>
            </div>

            {/* Group Name */}
            <div>
              <label htmlFor="groupName" className="block text-sm font-medium text-gray-700 mb-1">
                Group Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="groupName"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                placeholder="Enter group name"
                required
              />
            </div>

            {/* Group Description */}
            <div>
              <label htmlFor="groupDescription" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="groupDescription"
                value={groupDescription}
                onChange={(e) => setGroupDescription(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                placeholder="What's this group about?"
              />
            </div>

            {/* Form Actions */}
            <div className="flex justify-between pt-4 border-t">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
                Delete Group
              </button>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!groupName.trim()}
                  className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </form>
        ) : (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-4">
              <Inbox className="w-6 h-6 text-gray-400" />
            </div>
            <p className="text-gray-500">No pending join requests</p>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Delete Group"
        message="Are you sure you want to delete this group? This action cannot be undone and will remove the group for all members."
      />
    </>
  );
}