import React, { useState, useEffect, useRef } from 'react';
import { Trophy, Target, Award } from 'lucide-react';
import { useGoals } from '../../../contexts/GoalsContext';
import { useChallengesStore } from '../../../features/challenges/stores/challengesStore';
import { GoalCard } from '../../../components/planning/GoalCard';
import { useGroupFeedStore } from '../stores/groupFeedStore';
import { Post } from '../../social-feed/components/Post';

type PostType = 'goal' | 'challenge' | 'accolade' | null;

interface GroupFeedProps {
  groupId: string;
}

export function GroupFeed({ groupId }: GroupFeedProps) {
  const [activePostType, setActivePostType] = useState<PostType>(null);
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [postDescription, setPostDescription] = useState('');
  const { goals } = useGoals();
  const { joinedChallenges } = useChallengesStore();
  const { posts, addPost, loadMorePosts, hasMore, isLoading, page } = useGroupFeedStore(groupId);
  const feedRef = useRef<HTMLDivElement>(null);
  const loadingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first.isIntersecting && hasMore && !isLoading) {
          loadMorePosts();
        }
      },
      { threshold: 0.1 }
    );

    if (loadingRef.current) {
      observer.observe(loadingRef.current);
    }

    return () => observer.disconnect();
  }, [hasMore, isLoading, loadMorePosts]);

  // Get the appropriate goals based on the active post type
  const getGoalsForPostType = () => {
    if (activePostType === 'challenge') {
      // For challenges, only show goals that are part of challenges
      return goals.filter(goal => {
        // Check if the goal is from a challenge
        const isChallengeGoal = 
          goal.name.toLowerCase().includes('club') ||
          goal.name.toLowerCase().includes('challenge') ||
          goal.name.toLowerCase().includes('runners') ||
          goal.name.toLowerCase().includes('gym') ||
          goal.name.toLowerCase().includes('cv upgrade') ||
          goal.name.toLowerCase().includes('side hustle');

        return isChallengeGoal;
      });
    } else if (activePostType === 'goal') {
      // For regular goals, exclude challenge goals
      return goals.filter(goal => {
        // Check if the goal is NOT from a challenge
        const isChallengeGoal = 
          goal.name.toLowerCase().includes('club') ||
          goal.name.toLowerCase().includes('challenge') ||
          goal.name.toLowerCase().includes('runners') ||
          goal.name.toLowerCase().includes('gym') ||
          goal.name.toLowerCase().includes('cv upgrade') ||
          goal.name.toLowerCase().includes('side hustle');

        return !isChallengeGoal;
      });
    }
    return [];
  };

  // Sort goals by achieved status and date
  const getFilteredGoals = (goalsToFilter: typeof goals) => {
    const upcoming = goalsToFilter
      .filter(goal => !goal.achieved)
      .sort((a, b) => (b.order ?? 0) - (a.order ?? 0))
      .slice(0, 8);

    const achieved = goalsToFilter
      .filter(goal => goal.achieved)
      .sort((a, b) => (b.order ?? 0) - (a.order ?? 0))
      .slice(0, 8);

    return { upcoming, achieved };
  };

  const { upcoming: upcomingGoals, achieved: achievedGoals } = getFilteredGoals(
    getGoalsForPostType()
  );

  const handlePostTypeClick = (type: PostType) => {
    if (activePostType === type) {
      setActivePostType(null);
      setSelectedGoalId(null);
      setPostDescription('');
    } else {
      setActivePostType(type);
      setSelectedGoalId(null);
      setPostDescription('');
    }
  };

  const handleGoalSelect = (goalId: string) => {
    setSelectedGoalId(goalId);
  };

  const handlePost = () => {
    if (!activePostType) return;

    addPost({
      type: activePostType,
      goalId: selectedGoalId || undefined,
      description: postDescription.trim(),
      userId: 'current-user',
      groupId,
    });

    // Reset state
    setActivePostType(null);
    setSelectedGoalId(null);
    setPostDescription('');
  };

  // Calculate if we should show the loading indicator
  const visiblePosts = posts.slice(0, page * 10);
  const shouldShowLoading = hasMore && isLoading && visiblePosts.length > 0;

  return (
    <div className="h-full flex flex-col">
      {/* Create Post Section */}
      <div className="flex-shrink-0 mb-8 space-y-6">
        {/* Create Post Buttons */}
        <div className="flex w-full">
          <button
            onClick={() => handlePostTypeClick('goal')}
            className={`flex-1 flex flex-col items-center gap-2 p-4 bg-white shadow-sm border transition-colors group rounded-l-lg border-r-0 ${
              activePostType === 'goal'
                ? 'border-orange-500 bg-orange-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <Trophy className={`w-6 h-6 transition-colors ${
              activePostType === 'goal'
                ? 'text-orange-500'
                : 'text-gray-600 group-hover:text-orange-500'
            }`} />
            <span className="text-sm font-medium text-gray-900">Share Goal</span>
          </button>

          <button
            onClick={() => handlePostTypeClick('challenge')}
            className={`flex-1 flex flex-col items-center gap-2 p-4 bg-white shadow-sm border transition-colors group border-x-0 ${
              activePostType === 'challenge'
                ? 'border-orange-500 bg-orange-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <Target className={`w-6 h-6 transition-colors ${
              activePostType === 'challenge'
                ? 'text-orange-500'
                : 'text-gray-600 group-hover:text-orange-500'
            }`} />
            <span className="text-sm font-medium text-gray-900">Share Challenge</span>
          </button>

          <button
            onClick={() => handlePostTypeClick('accolade')}
            className={`flex-1 flex flex-col items-center gap-2 p-4 bg-white shadow-sm border transition-colors group rounded-r-lg border-l-0 ${
              activePostType === 'accolade'
                ? 'border-orange-500 bg-orange-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <Award className={`w-6 h-6 transition-colors ${
              activePostType === 'accolade'
                ? 'text-orange-500'
                : 'text-gray-600 group-hover:text-orange-500'
            }`} />
            <span className="text-sm font-medium text-gray-900">Share Accolade</span>
          </button>
        </div>

        {/* Post Creation Container */}
        {(activePostType === 'goal' || activePostType === 'challenge') && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            {/* Goal Selection */}
            {!selectedGoalId && (
              <div className="divide-y divide-gray-200">
                {/* Upcoming Goals Section */}
                {upcomingGoals.length > 0 && (
                  <div>
                    <div className="px-4 py-2 bg-gray-50">
                      <span className="text-sm font-medium text-gray-700">
                        {activePostType === 'challenge' ? 'Upcoming Challenges' : 'Upcoming Goals'}
                      </span>
                    </div>
                    <div className="p-4 grid grid-cols-2 gap-4">
                      {upcomingGoals.map(goal => (
                        <button
                          key={goal.id}
                          onClick={() => handleGoalSelect(goal.id)}
                          className="w-full text-left"
                        >
                          <GoalCard 
                            goal={goal} 
                            onClick={() => {}} 
                            icon={activePostType === 'challenge' ? Target : Trophy} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Achieved Goals Section */}
                {achievedGoals.length > 0 && (
                  <div>
                    <div className="px-4 py-2 bg-gray-50">
                      <span className="text-sm font-medium text-gray-700">
                        {activePostType === 'challenge' ? 'Achieved Challenges' : 'Achieved Goals'}
                      </span>
                    </div>
                    <div className="p-4 grid grid-cols-2 gap-4">
                      {achievedGoals.map(goal => (
                        <button
                          key={goal.id}
                          onClick={() => handleGoalSelect(goal.id)}
                          className="w-full text-left"
                        >
                          <GoalCard 
                            goal={goal} 
                            onClick={() => {}} 
                            icon={activePostType === 'challenge' ? Target : Trophy} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Empty State */}
                {upcomingGoals.length === 0 && achievedGoals.length === 0 && (
                  <div className="px-4 py-6 text-center text-gray-500">
                    <p>
                      {activePostType === 'challenge' 
                        ? 'No challenges to share yet' 
                        : 'No goals to share yet'}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Post Preview */}
            {selectedGoalId && (
              <div className="p-4 space-y-4">
                {/* Selected Goal Card */}
                <div>
                  <GoalCard 
                    goal={goals.find(g => g.id === selectedGoalId)!} 
                    onClick={() => {}}
                    icon={activePostType === 'challenge' ? Target : Trophy}
                  />
                </div>

                {/* Description Input */}
                <div>
                  <textarea
                    value={postDescription}
                    onChange={(e) => setPostDescription(e.target.value)}
                    placeholder="Add a description to your post (optional)..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500 min-h-[60px] max-h-[60px] resize-none"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => setSelectedGoalId(null)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Back
                  </button>
                  <button
                    onClick={handlePost}
                    className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
                  >
                    Post
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Posts Feed */}
      <div 
        ref={feedRef}
        className="flex-1 overflow-y-auto space-y-6 pr-2"
      >
        {visiblePosts.map(post => (
          <Post key={post.id} post={post} />
        ))}
        
        {/* Loading indicator */}
        {shouldShowLoading && (
          <div ref={loadingRef} className="text-center py-4">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-400 border-r-transparent motion-reduce:animate-[spin_1.5s_linear_infinite]" />
          </div>
        )}
      </div>
    </div>
  );
}