import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { useGroupsStore } from '../stores/groupsStore';
import { GroupCard } from './GroupCard';
import { CreateGroupModal } from './CreateGroupModal';

interface GroupsProps {
  onGroupSelect: (groupId: string) => void;
}

export function Groups({ onGroupSelect }: GroupsProps) {
  const { groups, loading, error, fetchGroups } = useGroupsStore();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  useEffect(() => {
    fetchGroups();
  }, [fetchGroups]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">Error loading groups: {error}</p>
        <button
          onClick={() => fetchGroups()}
          className="mt-4 px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <>
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl">
            <span className="font-medium text-gray-900">Groups</span>
          </h2>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="p-2.5 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
            aria-label="Create new group"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {groups.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
            <p className="text-gray-500">You haven't joined any groups yet</p>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="mt-4 px-4 py-2 text-sm font-medium text-orange-600 bg-orange-50 rounded-md hover:bg-orange-100"
            >
              Create Your First Group
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {groups.map(group => (
              <div key={group.id} onClick={() => onGroupSelect(group.id)}>
                <GroupCard group={group} />
              </div>
            ))}
          </div>
        )}
      </div>

      <CreateGroupModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </>
  );
}