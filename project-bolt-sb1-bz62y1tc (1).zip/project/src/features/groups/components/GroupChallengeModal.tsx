import React, { useState } from 'react';
import { Modal } from '../../../components/ui/Modal';
import { GoalCard } from '../../../components/planning/GoalCard';
import { TaskCard } from '../../../components/planning/tasks-and-habits/TaskCard';
import { HabitScheduler } from '../../../components/planning/tasks-and-habits/HabitScheduler';
import { WeeklyView } from '../../../components/planning/tasks-and-habits/WeeklyView';
import { useGoals } from '../../../contexts/GoalsContext';
import { useTasks } from '../../../contexts/TasksContext';
import { useGroupChallengesStore } from '../stores/groupChallengesStore';
import { Target, Trash2 } from 'lucide-react';
import { ConfirmationModal } from '../../../components/ui/ConfirmationModal';

interface GroupChallengeModalProps {
  isOpen: boolean;
  onClose: () => void;
  challenge: {
    id: string;
    name: string;
    description?: string;
    goal: {
      name: string;
      targetDate?: string;
    };
    task: {
      name: string;
      type: 'task' | 'habit';
    };
  };
}

export function GroupChallengeModal({ isOpen, onClose, challenge }: GroupChallengeModalProps) {
  const [scheduleType, setScheduleType] = useState<'daily' | 'weekly' | null>(null);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [selectedDates, setSelectedDates] = useState<Date[]>([]);
  const [isJoining, setIsJoining] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  
  const { addGoal } = useGoals();
  const { addTask } = useTasks();
  const { joinChallenge, isJoined, deleteChallenge } = useGroupChallengesStore();

  const handleScheduleTypeChange = (type: 'daily' | 'weekly') => {
    setScheduleType(type);
    if (type === 'daily') {
      setSelectedDays([0, 1, 2, 3, 4, 5, 6]); // Select all days
    } else {
      setSelectedDays([]); // Clear selection for weekly
    }
  };

  const handleDayToggle = (day: number) => {
    setSelectedDays(prev => {
      const newDays = prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day].sort((a, b) => a - b);

      // If all days are selected, switch to daily
      if (newDays.length === 7 && scheduleType === 'weekly') {
        setScheduleType('daily');
      }
      // If removing a day while on daily, switch to weekly
      else if (scheduleType === 'daily' && newDays.length < 7) {
        setScheduleType('weekly');
      }

      return newDays;
    });
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDates(prev => {
      const dateString = date.toDateString();
      const exists = prev.some(d => d.toDateString() === dateString);
      
      if (exists) {
        return prev.filter(d => d.toDateString() !== dateString);
      } else {
        return [...prev, date];
      }
    });
  };

  const handleJoinChallenge = () => {
    if (isJoining) return;

    // For tasks, require exactly 3 dates
    if (challenge.task.type === 'task' && selectedDates.length !== 3) return;

    // For habits, require schedule type and days
    if (challenge.task.type === 'habit' && (!scheduleType || selectedDays.length === 0)) return;

    setIsJoining(true);

    try {
      // Add the goal first
      const goalId = addGoal({
        name: challenge.goal.name,
        targetDate: challenge.goal.targetDate,
      });

      if (challenge.task.type === 'task') {
        // Add the task with fixed dates
        addTask({
          name: challenge.task.name,
          type: 'fixed',
          dates: selectedDates,
          goalId,
        });
      } else {
        // Calculate habit dates based on schedule
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const endDate = new Date(today);
        endDate.setMonth(endDate.getMonth() + 3);

        let dates: Date[] = [];
        let currentDate = new Date(today);

        while (currentDate <= endDate) {
          if (scheduleType === 'daily' || 
              selectedDays.includes(currentDate.getDay() === 0 ? 6 : currentDate.getDay() - 1)) {
            dates.push(new Date(currentDate));
          }
          currentDate.setDate(currentDate.getDate() + 1);
        }

        // Add the habit
        addTask({
          name: challenge.task.name,
          type: 'habit',
          frequency: scheduleType,
          dates,
          goalId,
        });
      }

      // Mark challenge as joined
      joinChallenge(challenge.id);

      // Close the modal
      onClose();
    } catch (error) {
      console.error('Error joining challenge:', error);
    } finally {
      setIsJoining(false);
    }
  };

  const handleDeleteChallenge = () => {
    deleteChallenge(challenge.id);
    setIsDeleteModalOpen(false);
    onClose();
  };

  const hasJoined = isJoined(challenge.id);

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} title={challenge.name}>
        <div className="space-y-6">
          {/* Description */}
          {challenge.description && (
            <div className="space-y-2">
              <h3 className="font-medium text-gray-900">About this Challenge</h3>
              <p className="text-gray-600">{challenge.description}</p>
            </div>
          )}

          {/* Goal and Task Cards Side by Side */}
          <div className="grid grid-cols-2 gap-6">
            {/* Challenge Goal */}
            <div className="space-y-2">
              <h3 className="font-medium text-gray-900">Challenge Goal</h3>
              <div className="h-full">
                <GoalCard 
                  goal={{
                    id: 'preview',
                    name: challenge.goal.name,
                    targetDate: challenge.goal.targetDate,
                  }}
                  onClick={() => {}}
                  icon={Target}
                />
              </div>
            </div>

            {/* Challenge Task */}
            <div className="space-y-2">
              <h3 className="font-medium text-gray-900">
                Challenge {challenge.task.type === 'habit' ? 'Habit' : 'Task'}
              </h3>
              <div className="h-full">
                <TaskCard
                  name={challenge.task.name}
                  onClick={() => {}}
                  icon={Target}
                  goalName={challenge.goal.name}
                />
              </div>
            </div>
          </div>

          {/* Scheduling Options */}
          {!hasJoined && (
            <div className="space-y-3">
              {challenge.task.type === 'task' ? (
                <>
                  <h3 className="font-medium text-gray-900">Select 3 Days</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Choose 3 days to work on this task. Each session should be at least 30 minutes.
                  </p>
                  <WeeklyView 
                    selectable 
                    selectedDates={selectedDates}
                    onDateSelect={handleDateSelect}
                  />
                  {selectedDates.length !== 3 && (
                    <p className="text-sm text-orange-600 mt-2">
                      Please select exactly 3 days to continue
                    </p>
                  )}
                </>
              ) : (
                <>
                  <h3 className="font-medium text-gray-900">Schedule Your Habit</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => handleScheduleTypeChange('daily')}
                      className={`p-4 text-left border rounded-lg transition-colors ${
                        scheduleType === 'daily'
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-medium text-gray-900">Daily</div>
                      <div className="text-sm text-gray-500">Every day</div>
                    </button>
                    <button
                      onClick={() => handleScheduleTypeChange('weekly')}
                      className={`p-4 text-left border rounded-lg transition-colors ${
                        scheduleType === 'weekly'
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-medium text-gray-900">Weekly</div>
                      <div className="text-sm text-gray-500">Selected days</div>
                    </button>
                  </div>

                  {/* Day Selection */}
                  {scheduleType && (
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700">
                        Select days for this habit
                      </label>
                      <HabitScheduler
                        selectedDays={selectedDays}
                        onDayToggle={handleDayToggle}
                      />
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-between pt-4 border-t">
            {/* Delete Button (Shown to all group members) */}
            <button
              onClick={() => setIsDeleteModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
              Delete Challenge
            </button>

            {/* Join Button */}
            <div>
              {hasJoined ? (
                <button
                  disabled
                  className="px-6 py-2 text-sm font-medium text-white bg-gray-400 rounded-md cursor-not-allowed"
                >
                  Already Joined
                </button>
              ) : (
                <button
                  onClick={handleJoinChallenge}
                  disabled={
                    isJoining || 
                    (challenge.task.type === 'task' 
                      ? selectedDates.length !== 3
                      : !scheduleType || selectedDays.length === 0)
                  }
                  className="px-6 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isJoining ? 'Joining...' : 'Join Challenge'}
                </button>
              )}
            </div>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDeleteChallenge}
        title="Delete Challenge"
        message="Are you sure you want to delete this challenge? This action cannot be undone and will remove the challenge for all group members."
      />
    </>
  );
}