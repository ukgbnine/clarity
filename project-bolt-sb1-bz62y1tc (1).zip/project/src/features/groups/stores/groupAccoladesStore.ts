import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useGroupsStore } from './groupsStore';

interface GroupAccolade {
  groupId: string;
  weekStartDate: string; // ISO date string
  achieved: boolean;
}

interface GroupAccoladesState {
  accolades: GroupAccolade[];
  getCurrentStreak: (groupId: string) => number;
  getAllTimeStreak: (groupId: string) => number;
  checkWeeklyAccolade: (groupId: string) => void;
}

export const useGroupAccoladesStore = create<GroupAccoladesState>()(
  persist(
    (set, get) => ({
      accolades: [],

      getCurrentStreak: (groupId: string) => {
        const { accolades } = get();
        const groupAccolades = accolades
          .filter(a => a.groupId === groupId)
          .sort((a, b) => new Date(b.weekStartDate).getTime() - new Date(a.weekStartDate).getTime());

        let streak = 0;
        let currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        // Start from the most recent week
        for (const accolade of groupAccolades) {
          const weekStart = new Date(accolade.weekStartDate);
          const weekDiff = Math.floor((currentDate.getTime() - weekStart.getTime()) / (7 * 24 * 60 * 60 * 1000));

          // Break if there's a gap in weeks or if the accolade wasn't achieved
          if (weekDiff > streak + 1 || !accolade.achieved) break;

          if (accolade.achieved) {
            streak++;
          }
        }

        return streak;
      },

      getAllTimeStreak: (groupId: string) => {
        const { accolades } = get();
        const groupAccolades = accolades
          .filter(a => a.groupId === groupId)
          .sort((a, b) => new Date(a.weekStartDate).getTime() - new Date(b.weekStartDate).getTime());

        let maxStreak = 0;
        let currentStreak = 0;

        for (let i = 0; i < groupAccolades.length; i++) {
          if (groupAccolades[i].achieved) {
            currentStreak++;
            maxStreak = Math.max(maxStreak, currentStreak);
          } else {
            currentStreak = 0;
          }

          // Check for gaps between weeks
          if (i < groupAccolades.length - 1) {
            const currentWeek = new Date(groupAccolades[i].weekStartDate);
            const nextWeek = new Date(groupAccolades[i + 1].weekStartDate);
            const weekDiff = Math.floor((nextWeek.getTime() - currentWeek.getTime()) / (7 * 24 * 60 * 60 * 1000));

            if (weekDiff > 1) {
              currentStreak = 0;
            }
          }
        }

        return maxStreak;
      },

      checkWeeklyAccolade: (groupId: string) => {
        const { getGroupConsistencyScore } = useGroupsStore.getState();
        const score = getGroupConsistencyScore(groupId);

        // Get the start of the current week
        const now = new Date();
        const dayOfWeek = now.getDay();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - dayOfWeek);
        weekStart.setHours(0, 0, 0, 0);

        // Check if we already have an accolade for this week
        const weekStartStr = weekStart.toISOString();
        const existingAccolade = get().accolades.find(
          a => a.groupId === groupId && a.weekStartDate === weekStartStr
        );

        if (!existingAccolade) {
          set(state => ({
            accolades: [
              ...state.accolades,
              {
                groupId,
                weekStartDate: weekStartStr,
                achieved: score >= 75,
              }
            ]
          }));
        }
      },
    }),
    {
      name: 'group-accolades',
    }
  )
);