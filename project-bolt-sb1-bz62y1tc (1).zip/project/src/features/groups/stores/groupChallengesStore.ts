import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface GroupChallenge {
  id: string;
  name: string;
  description?: string;
  groupId: string;
  createdAt: number;
  createdBy: string;
  goal: {
    name: string;
    targetDate?: string;
  };
  task: {
    name: string;
    type: 'task' | 'habit';
  };
}

interface GroupChallengesState {
  challenges: GroupChallenge[];
  joinedChallenges: string[]; // Array of challenge IDs
  addChallenge: (challenge: Omit<GroupChallenge, 'id' | 'createdAt' | 'createdBy'>) => void;
  updateChallenge: (id: string, challenge: Partial<GroupChallenge>) => void;
  deleteChallenge: (id: string) => void;
  joinChallenge: (challengeId: string) => void;
  isJoined: (challengeId: string) => boolean;
  canModifyChallenge: (challengeId: string) => boolean;
}

export const useGroupChallengesStore = create<GroupChallengesState>()(
  persist(
    (set, get) => ({
      challenges: [],
      joinedChallenges: [],

      addChallenge: (challenge) => set(state => ({
        challenges: [
          ...state.challenges,
          {
            ...challenge,
            id: crypto.randomUUID(),
            createdAt: Date.now(),
            createdBy: 'current-user',
          }
        ]
      })),

      updateChallenge: (id, updates) => set(state => ({
        challenges: state.challenges.map(challenge =>
          challenge.id === id
            ? { ...challenge, ...updates }
            : challenge
        )
      })),

      deleteChallenge: (id) => set(state => ({
        challenges: state.challenges.filter(challenge => challenge.id !== id),
        joinedChallenges: state.joinedChallenges.filter(challengeId => challengeId !== id)
      })),

      joinChallenge: (challengeId: string) => {
        const isAlreadyJoined = get().isJoined(challengeId);
        if (!isAlreadyJoined) {
          set(state => ({
            joinedChallenges: [...state.joinedChallenges, challengeId]
          }));
        }
      },

      isJoined: (challengeId: string) => {
        return get().joinedChallenges.includes(challengeId);
      },

      canModifyChallenge: (challengeId: string) => {
        const challenge = get().challenges.find(c => c.id === challengeId);
        return challenge?.createdBy === 'current-user';
      },
    }),
    {
      name: 'group-challenges',
    }
  )
);