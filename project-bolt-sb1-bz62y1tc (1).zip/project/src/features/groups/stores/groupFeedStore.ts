import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Post {
  id: string;
  type: 'goal' | 'challenge' | 'accolade';
  goalId?: string;
  description: string;
  createdAt: number;
  userId: string;
  groupId: string;
  celebrations: string[]; // Array of user IDs who celebrated
}

interface GroupFeedState {
  posts: Post[];
  page: number;
  hasMore: boolean;
  isLoading: boolean;
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'celebrations'>) => void;
  updatePost: (postId: string, description: string) => void;
  deletePost: (postId: string) => void;
  celebratePost: (postId: string, userId: string) => void;
  hasCelebrated: (postId: string, userId: string) => boolean;
  loadMorePosts: () => void;
}

export const useGroupFeedStore = (groupId: string) => {
  const store = create<GroupFeedState>()(
    persist(
      (set, get) => ({
        posts: [],
        page: 1,
        hasMore: true,
        isLoading: false,

        addPost: (post) => set(state => ({
          posts: [
            {
              ...post,
              id: crypto.randomUUID(),
              createdAt: Date.now(),
              celebrations: [],
            },
            ...state.posts,
          ]
        })),

        updatePost: (postId, description) => set(state => ({
          posts: state.posts.map(post =>
            post.id === postId
              ? { ...post, description }
              : post
          )
        })),

        deletePost: (postId) => set(state => ({
          posts: state.posts.filter(post => post.id !== postId)
        })),

        celebratePost: (postId, userId) => set(state => ({
          posts: state.posts.map(post =>
            post.id === postId && !post.celebrations.includes(userId)
              ? { ...post, celebrations: [...post.celebrations, userId] }
              : post
          )
        })),

        hasCelebrated: (postId, userId) => {
          const post = get().posts.find(p => p.id === postId);
          return post ? post.celebrations.includes(userId) : false;
        },

        loadMorePosts: () => {
          const state = get();
          const filteredPosts = state.posts.filter(post => post.groupId === groupId);
          const totalPages = Math.ceil(filteredPosts.length / 10);
          
          if (state.isLoading || state.page >= totalPages) return;

          set({ isLoading: true });

          // Simulate loading delay
          setTimeout(() => {
            set(state => ({
              page: state.page + 1,
              hasMore: state.page + 1 < totalPages,
              isLoading: false,
            }));
          }, 500);
        },
      }),
      {
        name: `group-feed-${groupId}`,
      }
    )
  );

  return store(state => ({
    posts: state.posts.filter(post => post.groupId === groupId),
    page: state.page,
    hasMore: state.hasMore,
    isLoading: state.isLoading,
    addPost: state.addPost,
    updatePost: state.updatePost,
    deletePost: state.deletePost,
    celebratePost: state.celebratePost,
    hasCelebrated: state.hasCelebrated,
    loadMorePosts: state.loadMorePosts,
  }));
};