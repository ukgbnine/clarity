import { create } from 'zustand';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';

type Group = Database['public']['Tables']['groups']['Row'];

interface GroupsState {
  groups: Group[];
  loading: boolean;
  error: string | null;
  fetchGroups: () => Promise<void>;
  createGroup: (name: string, description?: string, image?: string | null) => Promise<void>;
  updateGroup: (id: string, updates: Partial<Omit<Group, 'id'>>) => Promise<void>;
  deleteGroup: (id: string) => Promise<void>;
  findGroups: (query: string) => Promise<Group[]>;
  joinGroup: (groupId: string) => Promise<void>;
  leaveGroup: (groupId: string) => Promise<void>;
  isMember: (groupId: string) => boolean;
  getGroupConsistencyScore: (groupId: string) => Promise<number>;
}

export const useGroupsStore = create<GroupsState>()((set, get) => ({
  groups: [],
  loading: false,
  error: null,

  fetchGroups: async () => {
    try {
      set({ loading: true, error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Get groups where user is a member
      const { data: memberships, error: membershipError } = await supabase
        .from('group_members')
        .select('group_id')
        .eq('user_id', user.id);

      if (membershipError) throw membershipError;

      if (memberships.length === 0) {
        set({ groups: [], loading: false });
        return;
      }

      // Get group details
      const { data: groups, error: groupsError } = await supabase
        .from('groups')
        .select('*')
        .in('id', memberships.map(m => m.group_id));

      if (groupsError) throw groupsError;

      set({ groups });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error fetching groups:', error);
    } finally {
      set({ loading: false });
    }
  },

  createGroup: async (name: string, description?: string, image?: string | null) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Create group
      const { data: group, error: groupError } = await supabase
        .from('groups')
        .insert({
          name: name.trim(),
          description: description?.trim(),
          image_url: image,
          created_by: user.id,
        })
        .select()
        .single();

      if (groupError) throw groupError;

      // Add creator as member
      const { error: memberError } = await supabase
        .from('group_members')
        .insert({
          group_id: group.id,
          user_id: user.id,
          role: 'admin',
        });

      if (memberError) throw memberError;

      // Update local state
      set(state => ({
        groups: [...state.groups, group],
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error creating group:', error);
      throw error;
    }
  },

  updateGroup: async (id: string, updates: Partial<Omit<Group, 'id'>>) => {
    try {
      set({ error: null });

      const { error } = await supabase
        .from('groups')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      set(state => ({
        groups: state.groups.map(group =>
          group.id === id ? { ...group, ...updates } : group
        ),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error updating group:', error);
      throw error;
    }
  },

  deleteGroup: async (id: string) => {
    try {
      set({ error: null });

      const { error } = await supabase
        .from('groups')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      set(state => ({
        groups: state.groups.filter(group => group.id !== id),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error deleting group:', error);
      throw error;
    }
  },

  findGroups: async (query: string) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const normalizedQuery = query.toLowerCase().trim();
      
      if (!normalizedQuery) return [];

      // Search for groups by name or description
      const { data: groups, error } = await supabase
        .from('groups')
        .select('*')
        .or(`name.ilike.%${normalizedQuery}%,description.ilike.%${normalizedQuery}%`)
        .limit(10);

      if (error) throw error;

      return groups;
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error searching groups:', error);
      return [];
    }
  },

  joinGroup: async (groupId: string) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Add user as member
      const { error: memberError } = await supabase
        .from('group_members')
        .insert({
          group_id: groupId,
          user_id: user.id,
          role: 'member',
        });

      if (memberError) throw memberError;

      // Get group details
      const { data: group, error: groupError } = await supabase
        .from('groups')
        .select('*')
        .eq('id', groupId)
        .single();

      if (groupError) throw groupError;

      // Update local state
      set(state => ({
        groups: [...state.groups, group],
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error joining group:', error);
      throw error;
    }
  },

  leaveGroup: async (groupId: string) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('group_members')
        .delete()
        .eq('group_id', groupId)
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      set(state => ({
        groups: state.groups.filter(group => group.id !== groupId),
      }));
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      console.error('Error leaving group:', error);
      throw error;
    }
  },

  isMember: (groupId: string) => {
    return get().groups.some(group => group.id === groupId);
  },

  getGroupConsistencyScore: async (groupId: string) => {
    try {
      // Get group members
      const { data: members, error: membersError } = await supabase
        .from('group_members')
        .select('user_id')
        .eq('group_id', groupId);

      if (membersError) throw membersError;

      // Calculate average score of all members
      const scores = await Promise.all(
        members.map(member => get().calculateUserScore(member.user_id))
      );

      const totalScore = scores.reduce((sum, score) => sum + score, 0);
      return Math.round(totalScore / scores.length);
    } catch (error) {
      console.error('Error calculating group consistency:', error);
      return 0;
    }
  },

  calculateUserScore: async (userId: string) => {
    try {
      // Get the date range (past 7 days)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);

      // Get user's tasks and their completion status
      const { data: tasks, error: tasksError } = await supabase
        .from('tasks')
        .select('id, type')
        .eq('user_id', userId)
        .neq('type', 'flexible');

      if (tasksError) throw tasksError;

      if (!tasks.length) return 0;

      // Get task logs for the past 7 days
      const { data: logs, error: logsError } = await supabase
        .from('task_logs')
        .select('task_id, date, status')
        .eq('user_id', userId)
        .eq('status', 'completed')
        .gte('date', sevenDaysAgo.toISOString().split('T')[0])
        .lte('date', today.toISOString().split('T')[0]);

      if (logsError) throw logsError;

      // Calculate completion percentage
      const taskIds = tasks.map(t => t.id);
      const completedTasks = logs.filter(log => taskIds.includes(log.task_id));
      return Math.round((completedTasks.length / (taskIds.length * 7)) * 100);
    } catch (error) {
      console.error('Error calculating user score:', error);
      return 0;
    }
  },
}));