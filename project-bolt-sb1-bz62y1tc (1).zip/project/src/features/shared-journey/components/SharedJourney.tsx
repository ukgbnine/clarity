import React, { useState, useEffect } from 'react';
import { useConsistencyStore } from '../../../features/task-logging/stores/consistencyStore';
import { Tab } from './Tab';
import { UserPlus, AlertCircle } from 'lucide-react';
import { useFriendsStore } from '../stores/friendsStore';
import { FindFriendsModal } from './FindFriendsModal';
import { useGroupsStore } from '../../groups/stores/groupsStore';
import { useAuth } from '../../../contexts/AuthContext';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'] & { score?: number };

interface SharedJourneyProps {
  groupId?: string;
}

export function SharedJourney({ groupId }: SharedJourneyProps) {
  const [activeTab, setActiveTab] = useState<'current' | 'yesterday'>('current');
  const [isFindFriendsOpen, setIsFindFriendsOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [friends, setFriends] = useState<Profile[]>([]);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);
  const { user } = useAuth();
  const { groups } = useGroupsStore();
  const friendsStore = useFriendsStore();
  const consistencyStore = useConsistencyStore();

  // Initialize friends store
  useEffect(() => {
    friendsStore.initialize();
  }, []);

  // Load and subscribe to current user's score
  useEffect(() => {
    let cleanup: (() => void) | undefined;

    async function loadCurrentUser() {
      if (!user) return;

      try {
        // Get current user's profile
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Calculate initial score
        const score = await consistencyStore.calculateUserScore(user.id);
        
        // Set up real-time subscription
        cleanup = consistencyStore.subscribeToChanges(user.id);

        setCurrentUser({ ...profile, score });
      } catch (error) {
        console.error('Error loading current user:', error);
      }
    }

    loadCurrentUser();

    return () => {
      if (cleanup) cleanup();
    };
  }, [user]);

  // Load and subscribe to friends' scores
  useEffect(() => {
    const cleanups: (() => void)[] = [];

    async function loadFriends() {
      if (!user || friendsStore.friends.length === 0) {
        setFriends([]);
        setLoading(false);
        return;
      }

      try {
        setError(null);

        // Get friends' profiles
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select('*')
          .in('id', friendsStore.friends);

        if (profilesError) throw profilesError;

        // Calculate initial scores and set up subscriptions
        const friendsWithScores = await Promise.all(
          profiles.map(async (profile) => {
            const score = await consistencyStore.calculateUserScore(profile.id);
            const cleanup = consistencyStore.subscribeToChanges(profile.id);
            cleanups.push(cleanup);
            return { ...profile, score };
          })
        );

        // Sort by score
        setFriends(friendsWithScores.sort((a, b) => (b.score || 0) - (a.score || 0)));
      } catch (error) {
        console.error('Error loading friends:', error);
        setError('Unable to load friends. Please try again.');
      } finally {
        setLoading(false);
      }
    }

    loadFriends();

    return () => {
      cleanups.forEach(cleanup => cleanup());
    };
  }, [user, friendsStore.friends]);

  // Update scores when they change in the store
  useEffect(() => {
    const scores = consistencyStore.scores;

    // Update friends' scores
    setFriends(prev => {
      const updated = prev.map(friend => ({
        ...friend,
        score: scores[friend.id] ?? friend.score ?? 0
      }));
      return updated.sort((a, b) => (b.score || 0) - (a.score || 0));
    });

    // Update current user's score
    if (currentUser) {
      setCurrentUser(prev => prev ? {
        ...prev,
        score: scores[prev.id] ?? prev.score ?? 0
      } : null);
    }
  }, [consistencyStore.scores]);

  // Get group data if groupId is provided
  const group = groupId ? groups.find(g => g.id === groupId) : null;

  // Combine friends and current user for leaderboard
  const allUsers = currentUser 
    ? [...friends, currentUser].sort((a, b) => (b.score || 0) - (a.score || 0))
    : friends;

  return (
    <>
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl">
            <span className="font-medium text-gray-900">
              {group ? `${group.name} Journey` : 'Shared Journey'}
            </span>
          </h2>
          {!groupId && (
            <button
              onClick={() => setIsFindFriendsOpen(true)}
              className="p-2.5 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
              aria-label="Find friends"
            >
              <UserPlus className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col">
          {/* Tabs */}
          <div className="flex border-b border-gray-200">
            <Tab
              active={activeTab === 'current'}
              onClick={() => setActiveTab('current')}
            >
              Current
            </Tab>
            <Tab
              active={activeTab === 'yesterday'}
              onClick={() => setActiveTab('yesterday')}
            >
              Yesterday
            </Tab>
          </div>

          {/* Scrollable Leaderboard */}
          <div className="h-[240px] overflow-y-auto border-b border-gray-200">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-12 text-red-600">
                <AlertCircle className="w-8 h-8 mb-2" />
                <p>{error}</p>
                <button
                  onClick={() => window.location.reload()}
                  className="mt-4 px-4 py-2 text-sm font-medium text-orange-600 bg-orange-50 rounded-md hover:bg-orange-100"
                >
                  Try Again
                </button>
              </div>
            ) : allUsers.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <p>You haven't added any friends yet</p>
                <button
                  onClick={() => setIsFindFriendsOpen(true)}
                  className="mt-4 px-4 py-2 text-sm font-medium text-orange-600 bg-orange-50 rounded-md hover:bg-orange-100"
                >
                  Find Friends
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {allUsers.map((user) => (
                  <div 
                    key={user.id}
                    className={`p-4 flex items-center gap-4 ${
                      currentUser?.id === user.id ? 'bg-orange-50' : ''
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                      {user.avatar_url ? (
                        <img
                          src={user.avatar_url}
                          alt={user.full_name || user.username || 'User'}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-lg font-medium">
                          {user.full_name?.[0]?.toUpperCase() || user.username?.[0]?.toUpperCase() || '?'}
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {currentUser?.id === user.id ? 'You' : (user.full_name || user.username)}
                      </p>
                      {user.username && currentUser?.id !== user.id && (
                        <p className="text-xs text-gray-500">@{user.username}</p>
                      )}
                    </div>
                    <div className="flex-shrink-0">
                      {consistencyStore.getConsistencyIcon(user.score || 0)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Current User (Fixed at Bottom) */}
          {currentUser && (
            <div className="p-4 flex items-center gap-4 bg-orange-50">
              <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                {currentUser.avatar_url ? (
                  <img
                    src={currentUser.avatar_url}
                    alt="You"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-lg font-medium">
                    {currentUser.full_name?.[0]?.toUpperCase() || currentUser.username?.[0]?.toUpperCase() || 'Y'}
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">You</p>
              </div>
              <div className="flex-shrink-0">
                {consistencyStore.getConsistencyIcon(currentUser.score || 0)}
              </div>
            </div>
          )}
        </div>
      </div>

      {!groupId && (
        <FindFriendsModal
          isOpen={isFindFriendsOpen}
          onClose={() => setIsFindFriendsOpen(false)}
        />
      )}
    </>
  );
}