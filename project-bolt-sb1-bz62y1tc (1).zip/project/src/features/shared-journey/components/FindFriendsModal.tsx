import React, { useState, useEffect, useCallback } from 'react';
import { Search, UserPlus2, Check, Users } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';
import { useFriendsStore } from '../stores/friendsStore';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface FindFriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FindFriendsModal({ isOpen, onClose }: FindFriendsModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { searchUsers, sendFriendRequest, isFriend, hasPendingRequest, friends } = useFriendsStore();

  // Debounced search function
  const debouncedSearch = useCallback(async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    try {
      const results = await searchUsers(query);
      setSearchResults(results);
      setError(null);
    } catch (error) {
      console.error('Error searching users:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
    } finally {
      setSearching(false);
    }
  }, [searchUsers]);

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      debouncedSearch(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, debouncedSearch]);

  const handleSendRequest = async (userId: string) => {
    try {
      setError(null);
      await sendFriendRequest(userId);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
    }
  };

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setSearchQuery('');
      setSearchResults([]);
      setError(null);
    }
  }, [isOpen]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Find Friends">
      {/* Search Input */}
      <div className="relative mb-6">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by username or name..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
        />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
      </div>

      {error && (
        <div className="mb-6 p-3 text-sm text-red-600 bg-red-50 rounded-md">
          {error}
        </div>
      )}

      {/* Current Friends Section */}
      {!searchQuery && friends.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-gray-600" />
            <h3 className="text-sm font-medium text-gray-900">Your Friends</h3>
          </div>
          <div className="space-y-3">
            {friends.map(friendId => {
              // Get friend profile
              const { data: profile } = supabase
                .from('profiles')
                .select('*')
                .eq('id', friendId)
                .single();

              return (
                <div 
                  key={friendId}
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                      {profile?.avatar_url ? (
                        <img
                          src={profile.avatar_url}
                          alt={profile.full_name || profile.username || 'Friend avatar'}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-xl font-medium">
                          {profile?.full_name?.[0]?.toUpperCase() || profile?.username?.[0]?.toUpperCase() || '?'}
                        </div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">
                        {profile?.full_name || profile?.username}
                      </h3>
                      {profile?.username && (
                        <p className="text-sm text-gray-500">@{profile.username}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Search Results */}
      <div className="space-y-4">
        {searching ? (
          <div className="text-center py-8">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-solid border-orange-400 border-r-transparent" />
          </div>
        ) : searchResults.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            {searchQuery 
              ? "No users found matching your search"
              : "Search for users to add as friends"}
          </div>
        ) : (
          searchResults.map(user => {
            const isAlreadyFriend = isFriend(user.id);
            const hasPending = hasPendingRequest(user.id);

            return (
              <div 
                key={user.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                    {user.avatar_url ? (
                      <img
                        src={user.avatar_url}
                        alt={user.full_name || user.username || 'User avatar'}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-xl font-medium">
                        {user.full_name?.[0]?.toUpperCase() || user.username?.[0]?.toUpperCase() || '?'}
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {user.full_name || user.username}
                    </h3>
                    {user.username && (
                      <p className="text-sm text-gray-500">@{user.username}</p>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleSendRequest(user.id)}
                  disabled={isAlreadyFriend || hasPending}
                  className={`p-2 rounded-md transition-colors ${
                    isAlreadyFriend
                      ? 'bg-gray-100 text-gray-400 cursor-default'
                      : hasPending
                      ? 'bg-orange-100 text-orange-600 cursor-default'
                      : 'bg-orange-50 text-orange-600 hover:bg-orange-100'
                  }`}
                >
                  {isAlreadyFriend ? (
                    <Check className="w-5 h-5" />
                  ) : hasPending ? (
                    <span className="text-sm px-2">Pending</span>
                  ) : (
                    <UserPlus2 className="w-5 h-5" />
                  )}
                </button>
              </div>
            );
          })
        )}
      </div>
    </Modal>
  );
}