import React from 'react';

interface TabProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

export function Tab({ active, onClick, children }: TabProps) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-3 text-sm font-medium transition-colors ${
        active
          ? 'text-orange-600 border-b-2 border-orange-500'
          : 'text-gray-500 hover:text-gray-700'
      }`}
    >
      {children}
    </button>
  );
}