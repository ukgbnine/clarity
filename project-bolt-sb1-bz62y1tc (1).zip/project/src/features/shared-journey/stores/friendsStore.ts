import { create } from 'zustand';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface FriendsState {
  friends: string[];
  pendingRequests: {
    sent: string[];
    received: string[];
  };
  loading: boolean;
  error: string | null;
  initialized: boolean;
  initialize: () => Promise<void>;
  searchUsers: (query: string) => Promise<Profile[]>;
  sendFriendRequest: (userId: string) => Promise<void>;
  acceptFriendRequest: (userId: string) => Promise<void>;
  rejectFriendRequest: (userId: string) => Promise<void>;
  isFriend: (userId: string) => boolean;
  hasPendingRequest: (userId: string) => boolean;
}

export const useFriendsStore = create<FriendsState>()((set, get) => ({
  friends: [],
  pendingRequests: {
    sent: [],
    received: [],
  },
  loading: false,
  error: null,
  initialized: false,

  initialize: async () => {
    if (get().initialized) return;

    try {
      set({ loading: true, error: null });

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        set({ friends: [], pendingRequests: { sent: [], received: [] } });
        return;
      }

      // Get accepted friendships
      const { data: acceptedFriendships, error: acceptedError } = await supabase
        .from('friendships')
        .select('user_id, friend_id')
        .eq('status', 'accepted')
        .or(`user_id.eq.${session.user.id},friend_id.eq.${session.user.id}`);

      if (acceptedError) throw acceptedError;

      // Get pending friendships
      const { data: pendingFriendships, error: pendingError } = await supabase
        .from('friendships')
        .select('user_id, friend_id')
        .eq('status', 'pending')
        .or(`user_id.eq.${session.user.id},friend_id.eq.${session.user.id}`);

      if (pendingError) throw pendingError;

      // Process accepted friendships
      const friends = acceptedFriendships.map(friendship => 
        friendship.user_id === session.user.id ? friendship.friend_id : friendship.user_id
      );

      // Process pending friendships
      const sent = pendingFriendships
        .filter(f => f.user_id === session.user.id)
        .map(f => f.friend_id);

      const received = pendingFriendships
        .filter(f => f.friend_id === session.user.id)
        .map(f => f.user_id);

      set({
        friends,
        pendingRequests: { sent, received },
        initialized: true,
      });
    } catch (error) {
      console.error('Error initializing friends:', error);
      set({ error: 'Failed to load friends. Please try again.' });
    } finally {
      set({ loading: false });
    }
  },

  searchUsers: async (query: string) => {
    if (!query.trim()) return [];

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return [];

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .or(`username.ilike.%${query}%,full_name.ilike.%${query}%`)
        .neq('id', session.user.id)
        .limit(10);

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error searching users:', error);
      return [];
    }
  },

  sendFriendRequest: async (userId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('friendships')
        .insert({
          user_id: session.user.id,
          friend_id: userId,
          status: 'pending',
        });

      if (error) throw error;

      set(state => ({
        pendingRequests: {
          ...state.pendingRequests,
          sent: [...state.pendingRequests.sent, userId],
        },
      }));
    } catch (error) {
      console.error('Error sending friend request:', error);
      throw error;
    }
  },

  acceptFriendRequest: async (userId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('friendships')
        .update({ status: 'accepted' })
        .eq('user_id', userId)
        .eq('friend_id', session.user.id)
        .eq('status', 'pending');

      if (error) throw error;

      set(state => ({
        friends: [...state.friends, userId],
        pendingRequests: {
          ...state.pendingRequests,
          received: state.pendingRequests.received.filter(id => id !== userId),
        },
      }));
    } catch (error) {
      console.error('Error accepting friend request:', error);
      throw error;
    }
  },

  rejectFriendRequest: async (userId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('friendships')
        .delete()
        .eq('user_id', userId)
        .eq('friend_id', session.user.id)
        .eq('status', 'pending');

      if (error) throw error;

      set(state => ({
        pendingRequests: {
          ...state.pendingRequests,
          received: state.pendingRequests.received.filter(id => id !== userId),
        },
      }));
    } catch (error) {
      console.error('Error rejecting friend request:', error);
      throw error;
    }
  },

  isFriend: (userId: string) => {
    return get().friends.includes(userId);
  },

  hasPendingRequest: (userId: string) => {
    const { sent, received } = get().pendingRequests;
    return sent.includes(userId) || received.includes(userId);
  },
}));