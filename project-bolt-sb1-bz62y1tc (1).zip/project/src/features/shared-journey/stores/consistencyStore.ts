import { create } from 'zustand';
import { Medal, Trophy, Loader2 } from 'lucide-react';
import React from 'react';
import { useGroupsStore } from '../../groups/stores/groupsStore';

interface User {
  id: string;
  name: string;
  avatar?: string;
  consistencyScore: number;
  consistencyIcon: React.ReactNode;
}

interface ConsistencyState {
  getCurrentLeaderboard: (userScore: number, groupId?: string) => User[];
  getYesterdayLeaderboard: (userScore: number, groupId?: string) => User[];
}

// Helper function to get consistency icon based on score
const getConsistencyIcon = (score: number): React.ReactNode => {
  if (score < 25) {
    return React.createElement(Loader2, { className: "w-6 h-6 text-gray-400" });
  } else if (score < 55) {
    return React.createElement(Medal, { className: "w-6 h-6 text-gray-400" });
  } else if (score < 100) {
    return React.createElement(Medal, { className: "w-6 h-6 text-orange-500" });
  } else {
    return React.createElement(Trophy, { className: "w-6 h-6 text-orange-500" });
  }
};

// Mock data for other users
const mockUsers: Omit<User, 'consistencyIcon'>[] = [
  {
    id: '2',
    name: 'Michael Park',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    consistencyScore: 85,
  },
  {
    id: '3',
    name: 'Emma Wilson',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    consistencyScore: 72,
  },
  {
    id: '4',
    name: 'James Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    consistencyScore: 45,
  },
  {
    id: '5',
    name: 'Olivia Taylor',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    consistencyScore: 35,
  },
];

// Mock data for yesterday's scores
const mockYesterdayUsers: Omit<User, 'consistencyIcon'>[] = [
  {
    id: '2',
    name: 'Michael Park',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    consistencyScore: 92,
  },
  {
    id: '4',
    name: 'James Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    consistencyScore: 65,
  },
  {
    id: '3',
    name: 'Emma Wilson',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    consistencyScore: 50,
  },
  {
    id: '5',
    name: 'Olivia Taylor',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    consistencyScore: 35,
  },
];

export const useConsistencyStore = create<ConsistencyState>()(() => ({
  getCurrentLeaderboard: (userScore: number, groupId?: string) => {
    // Create current user object
    const currentUser: User = {
      id: 'current-user',
      name: 'You',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      consistencyScore: userScore,
      consistencyIcon: getConsistencyIcon(userScore),
    };

    // If groupId is provided, filter users based on group membership
    let filteredUsers = mockUsers;
    if (groupId) {
      const groups = useGroupsStore.getState().groups;
      const group = groups.find(g => g.id === groupId);
      if (group) {
        filteredUsers = mockUsers.filter(user => group.members.includes(user.id));
      }
    }

    // Combine current user with other users and sort by score
    const allUsers = [...filteredUsers, currentUser]
      .map(user => ({
        ...user,
        consistencyIcon: getConsistencyIcon(user.consistencyScore),
      }))
      .sort((a, b) => b.consistencyScore - a.consistencyScore);

    return allUsers;
  },

  getYesterdayLeaderboard: (userScore: number, groupId?: string) => {
    // Create current user object with yesterday's score
    const currentUser: User = {
      id: 'current-user',
      name: 'You',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      consistencyScore: userScore - 5, // Simulate a slightly different score for yesterday
      consistencyIcon: getConsistencyIcon(userScore - 5),
    };

    // If groupId is provided, filter users based on group membership
    let filteredUsers = mockYesterdayUsers;
    if (groupId) {
      const groups = useGroupsStore.getState().groups;
      const group = groups.find(g => g.id === groupId);
      if (group) {
        filteredUsers = mockYesterdayUsers.filter(user => group.members.includes(user.id));
      }
    }

    // Combine current user with other users and sort by score
    const allUsers = [...filteredUsers, currentUser]
      .map(user => ({
        ...user,
        consistencyIcon: getConsistencyIcon(user.consistencyScore),
      }))
      .sort((a, b) => b.consistencyScore - a.consistencyScore);

    return allUsers;
  },
}));