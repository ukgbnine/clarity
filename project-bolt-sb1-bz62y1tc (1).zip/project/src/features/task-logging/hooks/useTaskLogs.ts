import { useState, useEffect } from 'react';
import { useTaskLogStore } from '../stores/taskLogStore';
import type { Database } from '../../../lib/database.types';

type TaskLog = Database['public']['Tables']['task_logs']['Row'];

export function useTaskLogs(taskId: string) {
  const store = useTaskLogStore();
  const [logs, setLogs] = useState<TaskLog[]>([]);

  useEffect(() => {
    setLogs(store.getLogsForTask(taskId));
  }, [taskId, store.logs]); // Update when store.logs changes

  const logTask = async (date: Date, status: 'completed' | 'uncompleted') => {
    const log: Omit<TaskLog, 'id' | 'created_at'> = {
      task_id: taskId,
      user_id: '', // This will be set by the store
      date: date.toISOString().split('T')[0],
      status,
      metadata: null,
    };

    await store.addLog(log);
    setLogs(store.getLogsForTask(taskId));
  };

  const getTaskStatus = (date: Date): 'completed' | 'uncompleted' | undefined => {
    const dateStr = date.toISOString().split('T')[0];
    const log = logs.find(l => l.date === dateStr);
    return log?.status as 'completed' | 'uncompleted' | undefined;
  };

  const getStreak = (): number => {
    const sortedLogs = [...logs]
      .filter(log => log.status === 'completed')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    if (sortedLogs.length === 0) return 0;

    let streak = 1;
    let currentDate = new Date(sortedLogs[0].date);

    for (let i = 1; i < sortedLogs.length; i++) {
      const prevDate = new Date(sortedLogs[i].date);
      const diffDays = Math.floor(
        (currentDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (diffDays === 1) {
        streak++;
        currentDate = prevDate;
      } else {
        break;
      }
    }

    return streak;
  };

  return {
    logs,
    logTask,
    getTaskStatus,
    getStreak,
  };
}