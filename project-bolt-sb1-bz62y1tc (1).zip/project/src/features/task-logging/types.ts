export interface TaskLog {
  taskId: string;
  date: string; // ISO date string
  status: 'completed' | 'uncompleted';
  timestamp: number; // Unix timestamp
}

export interface TaskLogEntry {
  id: string;
  taskId: string;
  date: string;
  status: 'completed' | 'uncompleted';
  timestamp: number;
  metadata?: {
    streakCount?: number;
    streakStart?: string;
  };
}