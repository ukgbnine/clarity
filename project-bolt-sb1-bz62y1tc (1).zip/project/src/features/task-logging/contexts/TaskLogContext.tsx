import React, { createContext, useContext, useState, useEffect } from 'react';

interface TaskLog {
  taskId: string;
  date: string;
  status: 'completed' | 'uncompleted';
  timestamp: number;
}

interface TaskLogContextType {
  logs: TaskLog[];
  addLog: (log: TaskLog) => void;
  getTaskStatus: (taskId: string, date: Date) => 'completed' | 'uncompleted' | undefined;
}

const TaskLogContext = createContext<TaskLogContextType | undefined>(undefined);

export function TaskLogProvider({ children }: { children: React.ReactNode }) {
  const [logs, setLogs] = useState<TaskLog[]>(() => {
    const savedLogs = localStorage.getItem('taskLogs');
    return savedLogs ? JSON.parse(savedLogs) : [];
  });

  useEffect(() => {
    localStorage.setItem('taskLogs', JSON.stringify(logs));
  }, [logs]);

  const addLog = (log: TaskLog) => {
    setLogs(prevLogs => {
      const existingLogIndex = prevLogs.findIndex(
        l => l.taskId === log.taskId && l.date === log.date
      );

      if (existingLogIndex !== -1) {
        const newLogs = [...prevLogs];
        newLogs[existingLogIndex] = log;
        return newLogs;
      }

      return [...prevLogs, log];
    });
  };

  const getTaskStatus = (taskId: string, date: Date): 'completed' | 'uncompleted' | undefined => {
    const dateStr = date.toISOString().split('T')[0];
    const log = logs.find(l => l.taskId === taskId && l.date === dateStr);
    return log?.status;
  };

  return (
    <TaskLogContext.Provider value={{ logs, addLog, getTaskStatus }}>
      {children}
    </TaskLogContext.Provider>
  );
}

export function useTaskLogs(taskId: string) {
  const context = useContext(TaskLogContext);
  if (!context) {
    throw new Error('useTaskLogs must be used within a TaskLogProvider');
  }

  const logTask = (date: Date, status: 'completed' | 'uncompleted') => {
    context.addLog({
      taskId,
      date: date.toISOString().split('T')[0],
      status,
      timestamp: Date.now(),
    });
  };

  const getTaskStatus = (date: Date) => {
    return context.getTaskStatus(taskId, date);
  };

  return {
    logTask,
    getTaskStatus,
  };
}