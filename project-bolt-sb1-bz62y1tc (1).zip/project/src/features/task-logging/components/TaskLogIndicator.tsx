import React from 'react';
import { useTaskLogs } from '../hooks/useTaskLogs';

interface TaskLogIndicatorProps {
  taskId: string;
  date: Date;
  onComplete?: () => void;
  className?: string;
}

export function TaskLogIndicator({ 
  taskId, 
  date,
  onComplete,
  className = ''
}: TaskLogIndicatorProps) {
  const { getTaskStatus, logTask } = useTaskLogs(taskId);
  const status = getTaskStatus(date);

  const handleToggle = async () => {
    const newStatus = status === 'completed' ? 'uncompleted' : 'completed';
    await logTask(date, newStatus);
    if (onComplete) {
      onComplete();
    }
  };

  return (
    <button
      onClick={handleToggle}
      className={`w-6 h-6 border-2 rounded-md flex items-center justify-center transition-colors ${
        status === 'completed'
          ? 'bg-white border-white'
          : 'border-gray-300 hover:border-orange-500'
      } ${className}`}
    >
      {status === 'completed' && (
        <svg
          className="w-4 h-4 text-orange-500"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M5 13l4 4L19 7"
          />
        </svg>
      )}
    </button>
  );
}