import React from 'react';
import { Flame } from 'lucide-react';
import { useTaskLogs } from '../hooks/useTaskLogs';

interface TaskStreakIndicatorProps {
  taskId: string;
  className?: string;
}

export function TaskStreakIndicator({ taskId, className = '' }: TaskStreakIndicatorProps) {
  const { getStreak } = useTaskLogs(taskId);
  const streak = getStreak();

  if (streak === 0) return null;

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      <Flame className="w-4 h-4 text-orange-500" />
      <span className="text-sm font-medium text-orange-600">
        {streak} day{streak === 1 ? '' : 's'}
      </span>
    </div>
  );
}