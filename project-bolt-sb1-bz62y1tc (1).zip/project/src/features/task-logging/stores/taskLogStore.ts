import { create } from 'zustand';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';
import { useConsistencyStore } from './consistencyStore';

type TaskLog = Database['public']['Tables']['task_logs']['Row'];

interface TaskLogState {
  logs: TaskLog[];
  loading: boolean;
  error: string | null;
  addLog: (log: Omit<TaskLog, 'id' | 'created_at'>) => Promise<void>;
  getLogsForTask: (taskId: string) => TaskLog[];
  clearLogs: (taskId: string) => Promise<void>;
  fetchLogs: () => Promise<void>;
}

export const useTaskLogStore = create<TaskLogState>()((set, get) => ({
  logs: [],
  loading: false,
  error: null,

  fetchLogs: async () => {
    try {
      set({ loading: true, error: null });

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        set({ logs: [] });
        return;
      }

      const { data, error } = await supabase
        .from('task_logs')
        .select('*')
        .eq('user_id', session.user.id);

      if (error) throw error;

      set({ logs: data || [] });
    } catch (error) {
      console.error('Error fetching task logs:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      set({ logs: [] });
    } finally {
      set({ loading: false });
    }
  },

  addLog: async (log) => {
    try {
      set({ error: null });

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No user found');

      // Always ensure metadata is an empty object if not provided
      const metadata = log.metadata || {};

      // Check if a log already exists for this task and date
      const { data: existingLog, error: checkError } = await supabase
        .from('task_logs')
        .select('id')
        .eq('task_id', log.task_id)
        .eq('date', log.date)
        .maybeSingle();

      if (checkError) throw checkError;

      let newLog;

      if (existingLog) {
        // Update existing log
        const { data: updatedLog, error: updateError } = await supabase
          .from('task_logs')
          .update({
            status: log.status,
            metadata
          })
          .eq('id', existingLog.id)
          .select()
          .single();

        if (updateError) throw updateError;
        newLog = updatedLog;
      } else {
        // Create new log
        const { data: insertedLog, error: insertError } = await supabase
          .from('task_logs')
          .insert({
            task_id: log.task_id,
            user_id: session.user.id,
            date: log.date,
            status: log.status,
            metadata
          })
          .select()
          .single();

        if (insertError) throw insertError;
        newLog = insertedLog;
      }

      // Update local state
      set(state => ({
        logs: [
          ...state.logs.filter(l => !(l.task_id === log.task_id && l.date === log.date)),
          newLog
        ]
      }));

      // Update consistency score
      const consistencyStore = useConsistencyStore.getState();
      await consistencyStore.calculateUserScore(session.user.id);

    } catch (error) {
      console.error('Error adding task log:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      throw error;
    }
  },

  getLogsForTask: (taskId: string) => {
    return get().logs.filter(log => log.task_id === taskId);
  },

  clearLogs: async (taskId: string) => {
    try {
      set({ error: null });

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('No user found');

      const { error } = await supabase
        .from('task_logs')
        .delete()
        .eq('task_id', taskId)
        .eq('user_id', session.user.id);

      if (error) throw error;

      set(state => ({
        logs: state.logs.filter(log => log.task_id !== taskId),
      }));

      // Update consistency score after clearing logs
      const consistencyStore = useConsistencyStore.getState();
      await consistencyStore.calculateUserScore(session.user.id);

    } catch (error) {
      console.error('Error clearing task logs:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      throw error;
    }
  },
}));