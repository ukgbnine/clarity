import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '../../../lib/supabase';
import { Medal, Trophy, Loader2 } from 'lucide-react';
import React from 'react';

interface ConsistencyState {
  scores: Record<string, number>;
  loading: boolean;
  error: string | null;
  initialized: boolean;
  calculateUserScore: (userId: string) => Promise<number>;
  setScore: (userId: string, score: number) => void;
  getConsistencyIcon: (score: number) => React.ReactNode;
  subscribeToChanges: (userId: string) => () => void;
  initialize: () => Promise<void>;
  updateScoreFromLog: (userId: string, taskId: string, date: string, status: string) => Promise<void>;
}

export const useConsistencyStore = create<ConsistencyState>()(
  persist(
    (set, get) => {
      // Keep track of active subscriptions
      const subscriptions = new Map<string, () => void>();

      const calculateScore = async (userId: string) => {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (!session) return 0;

          // Get the date range (past 7 days)
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          const sevenDaysAgo = new Date(today);
          sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);

          // Get user's tasks
          const { data: tasks, error: tasksError } = await supabase
            .from('tasks')
            .select('id, type, dates')
            .eq('user_id', userId)
            .neq('type', 'flexible');

          if (tasksError) throw tasksError;
          if (!tasks?.length) return 0;

          // Get task logs
          const { data: logs, error: logsError } = await supabase
            .from('task_logs')
            .select('task_id, date, status')
            .eq('user_id', userId)
            .eq('status', 'completed')
            .gte('date', sevenDaysAgo.toISOString().split('T')[0])
            .lte('date', today.toISOString().split('T')[0]);

          if (logsError) throw logsError;

          // Calculate completion rate
          let totalTasks = 0;
          let completedTasks = 0;

          // Process each task
          tasks.forEach(task => {
            const taskDates = task.dates.map(date => {
              const taskDate = new Date(date);
              taskDate.setHours(0, 0, 0, 0);
              return taskDate;
            });

            // Count tasks within date range
            taskDates.forEach(taskDate => {
              if (taskDate >= sevenDaysAgo && taskDate <= today) {
                totalTasks++;
                const dateStr = taskDate.toISOString().split('T')[0];
                if (logs?.some(log => 
                  log.task_id === task.id && 
                  log.date === dateStr && 
                  log.status === 'completed'
                )) {
                  completedTasks++;
                }
              }
            });
          });

          // Calculate percentage
          const score = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
          get().setScore(userId, score);
          return score;
        } catch (error) {
          console.error('Error calculating score:', error);
          return 0;
        }
      };

      return {
        scores: {},
        loading: true,
        error: null,
        initialized: false,

        initialize: async () => {
          if (get().initialized) return;

          try {
            set({ loading: true, error: null });

            const { data: { session } } = await supabase.auth.getSession();
            if (!session?.user) {
              set({ scores: {}, loading: false });
              return;
            }

            // Calculate current user's score
            const userScore = await calculateScore(session.user.id);
            
            set(state => ({
              scores: { ...state.scores, [session.user.id]: userScore },
              initialized: true,
              loading: false,
            }));

            // Set up subscription for the current user
            get().subscribeToChanges(session.user.id);

          } catch (error) {
            console.error('Error initializing consistency store:', error);
            set({ error: 'Failed to initialize consistency scores', loading: false });
          }
        },

        setScore: (userId: string, score: number) => {
          set(state => ({
            scores: { ...state.scores, [userId]: score }
          }));
        },

        calculateUserScore: async (userId: string) => {
          const score = await calculateScore(userId);
          return score;
        },

        updateScoreFromLog: async (userId: string, taskId: string, date: string, status: string) => {
          try {
            // Get the task to check if it's countable
            const { data: task, error: taskError } = await supabase
              .from('tasks')
              .select('type')
              .eq('id', taskId)
              .single();

            if (taskError) throw taskError;
            if (task.type === 'flexible') return; // Don't update score for flexible tasks

            // Calculate new score immediately
            await calculateScore(userId);
          } catch (error) {
            console.error('Error updating score from log:', error);
          }
        },

        subscribeToChanges: (userId: string) => {
          // Clean up existing subscription
          if (subscriptions.has(userId)) {
            subscriptions.get(userId)?.();
            subscriptions.delete(userId);
          }

          // Set up real-time subscription for task logs
          const channel = supabase.channel(`consistency:${userId}`)
            .on(
              'postgres_changes',
              {
                event: '*',
                schema: 'public',
                table: 'task_logs',
                filter: `user_id=eq.${userId}`,
              },
              async (payload) => {
                if (payload.new) {
                  await get().updateScoreFromLog(
                    userId,
                    payload.new.task_id,
                    payload.new.date,
                    payload.new.status
                  );
                }
              }
            )
            .subscribe();

          // Set up real-time subscription for tasks
          const tasksChannel = supabase.channel(`tasks:${userId}`)
            .on(
              'postgres_changes',
              {
                event: '*',
                schema: 'public',
                table: 'tasks',
                filter: `user_id=eq.${userId}`,
              },
              async () => {
                await calculateScore(userId);
              }
            )
            .subscribe();

          // Store cleanup function
          const cleanup = () => {
            channel.unsubscribe();
            tasksChannel.unsubscribe();
            subscriptions.delete(userId);
          };
          subscriptions.set(userId, cleanup);

          return cleanup;
        },

        getConsistencyIcon: (score: number) => {
          if (score < 25) {
            return React.createElement(Loader2, { 
              className: "w-6 h-6 text-gray-400 animate-spin"
            });
          } else if (score < 55) {
            return React.createElement(Medal, { 
              className: "w-6 h-6 text-gray-400" 
            });
          } else if (score < 100) {
            return React.createElement(Medal, { 
              className: "w-6 h-6 text-orange-500" 
            });
          } else {
            return React.createElement(Trophy, { 
              className: "w-6 h-6 text-orange-500" 
            });
          }
        },
      };
    },
    {
      name: 'consistency-store',
      partialize: (state) => ({
        scores: state.scores,
      }),
    }
  )
);