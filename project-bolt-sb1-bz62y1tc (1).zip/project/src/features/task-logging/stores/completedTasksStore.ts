import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface CompletedTasksState {
  completedTasks: {
    [date: string]: string[]; // date -> taskIds
  };
  addCompletedTask: (taskId: string, date: string) => void;
  removeCompletedTask: (taskId: string, date: string) => void;
  isTaskCompleted: (taskId: string, date: string) => boolean;
  getCompletedTasks: (date: string) => string[];
  clearCompletedTasks: (date: string) => void;
}

export const useCompletedTasksStore = create<CompletedTasksState>()(
  persist(
    (set, get) => ({
      completedTasks: {},

      addCompletedTask: (taskId: string, date: string) => {
        set(state => {
          const dateStr = date.split('T')[0];
          const existingTasks = state.completedTasks[dateStr] || [];
          
          if (!existingTasks.includes(taskId)) {
            return {
              completedTasks: {
                ...state.completedTasks,
                [dateStr]: [...existingTasks, taskId]
              }
            };
          }
          return state;
        });
      },

      removeCompletedTask: (taskId: string, date: string) => {
        set(state => {
          const dateStr = date.split('T')[0];
          const existingTasks = state.completedTasks[dateStr] || [];
          
          return {
            completedTasks: {
              ...state.completedTasks,
              [dateStr]: existingTasks.filter(id => id !== taskId)
            }
          };
        });
      },

      isTaskCompleted: (taskId: string, date: string) => {
        const dateStr = date.split('T')[0];
        const completedTasks = get().completedTasks[dateStr] || [];
        return completedTasks.includes(taskId);
      },

      getCompletedTasks: (date: string) => {
        const dateStr = date.split('T')[0];
        return get().completedTasks[dateStr] || [];
      },

      clearCompletedTasks: (date: string) => {
        set(state => {
          const { [date]: _, ...rest } = state.completedTasks;
          return { completedTasks: rest };
        });
      },
    }),
    {
      name: 'completed-tasks',
      version: 1,
      storage: createJSONStorage(() => localStorage),
      migrate: (persistedState: any, version: number) => {
        if (version === 0) {
          // Handle migration from version 0 to 1
          return {
            completedTasks: {},
          };
        }
        return persistedState as CompletedTasksState;
      },
    }
  )
);