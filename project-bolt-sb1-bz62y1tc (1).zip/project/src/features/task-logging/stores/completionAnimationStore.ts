import { create } from 'zustand';

interface CompletionAnimation {
  taskId: string;
  goalId?: string;
  date: string;
  progress: number;
  animationFrame?: number;
  timeoutId?: number;
}

interface GoalAnimation {
  goalId: string;
  progress: number;
  animationFrame?: number;
  timeoutId?: number;
}

interface CompletionAnimationState {
  animations: CompletionAnimation[];
  goalAnimations: GoalAnimation[];
  startAnimation: (taskId: string, goalId: string | undefined, date: string) => void;
  cancelAnimation: (taskId: string, date: string) => void;
  updateProgress: (taskId: string, date: string, progress: number) => void;
  getAnimation: (taskId: string, date: string) => CompletionAnimation | undefined;
  getGoalAnimation: (goalId: string) => GoalAnimation | undefined;
  cancelGoalAnimation: (goalId: string) => void;
}

export const useCompletionAnimationStore = create<CompletionAnimationState>()((set, get) => ({
  animations: [],
  goalAnimations: [],

  startAnimation: (taskId: string, goalId: string | undefined, date: string) => {
    // Cancel any existing animations first
    get().cancelAnimation(taskId, date);
    if (goalId) {
      get().cancelGoalAnimation(goalId);
    }

    set(state => ({
      animations: [
        ...state.animations.filter(a => !(a.taskId === taskId && a.date === date)),
        { taskId, goalId, date, progress: 0 }
      ],
      ...(goalId && {
        goalAnimations: [
          ...state.goalAnimations.filter(a => a.goalId !== goalId),
          { goalId, progress: 0 }
        ]
      })
    }));

    const startTime = performance.now();
    const totalDuration = 4000; // 4 seconds total
    const phase1Duration = 1000; // First 0.1 takes 1 second
    const phase2Duration = 2000; // Middle 0.8 takes 2 seconds
    const phase3Duration = 1000; // Last 0.1 takes 1 second

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      let progress = 0;

      if (elapsed <= phase1Duration) {
        // Phase 1: First 0.1 (0 to 0.1)
        progress = (elapsed / phase1Duration) * 0.1;
      } else if (elapsed <= phase1Duration + phase2Duration) {
        // Phase 2: Middle 0.8 (0.1 to 0.9)
        const phase2Progress = (elapsed - phase1Duration) / phase2Duration;
        progress = 0.1 + (phase2Progress * 0.8);
      } else if (elapsed <= totalDuration) {
        // Phase 3: Last 0.1 (0.9 to 1.0)
        const phase3Progress = (elapsed - (phase1Duration + phase2Duration)) / phase3Duration;
        progress = 0.9 + (phase3Progress * 0.1);
      } else {
        progress = 1;
      }

      get().updateProgress(taskId, date, progress);

      // Update goal progress if there's a linked goal
      if (goalId) {
        set(state => ({
          goalAnimations: state.goalAnimations.map(a => 
            a.goalId === goalId 
              ? { ...a, progress } 
              : a
          )
        }));
      }

      if (progress < 1) {
        // Use requestAnimationFrame for smoother animation
        const frame = requestAnimationFrame(animate);
        // Store animation frame for cancellation
        set(state => ({
          animations: state.animations.map(a => 
            a.taskId === taskId && a.date === date 
              ? { ...a, animationFrame: frame } 
              : a
          ),
          ...(goalId && {
            goalAnimations: state.goalAnimations.map(a => 
              a.goalId === goalId 
                ? { ...a, animationFrame: frame } 
                : a
            )
          })
        }));
      } else {
        // Remove animations when complete
        set(state => ({
          animations: state.animations.filter(a => !(a.taskId === taskId && a.date === date)),
          ...(goalId && {
            goalAnimations: state.goalAnimations.filter(a => a.goalId !== goalId)
          })
        }));
      }
    };

    // Start the animation
    const frame = requestAnimationFrame(animate);

    // Store the animation frame and timeout ID
    set(state => ({
      animations: state.animations.map(a => 
        a.taskId === taskId && a.date === date 
          ? { 
              ...a, 
              animationFrame: frame,
              timeoutId: window.setTimeout(() => {
                // This timeout will be cleared if animation is cancelled
                // Play sound and update state when animation completes
                set(state => ({
                  animations: state.animations.filter(a => !(a.taskId === taskId && a.date === date)),
                  ...(goalId && {
                    goalAnimations: state.goalAnimations.filter(a => a.goalId !== goalId)
                  })
                }));
              }, totalDuration)
            } 
          : a
      ),
      ...(goalId && {
        goalAnimations: state.goalAnimations.map(a => 
          a.goalId === goalId 
            ? { 
                ...a, 
                animationFrame: frame,
                timeoutId: window.setTimeout(() => {}, totalDuration)
              } 
            : a
        )
      })
    }));
  },

  cancelAnimation: (taskId: string, date: string) => {
    const animation = get().animations.find(
      a => a.taskId === taskId && a.date === date
    );
    
    if (animation) {
      // Cancel the animation frame
      if (animation.animationFrame) {
        cancelAnimationFrame(animation.animationFrame);
      }
      // Clear the timeout
      if (animation.timeoutId) {
        clearTimeout(animation.timeoutId);
      }

      // If this animation has a linked goal, cancel that too
      if (animation.goalId) {
        get().cancelGoalAnimation(animation.goalId);
      }
    }

    set(state => ({
      animations: state.animations.filter(a => !(a.taskId === taskId && a.date === date))
    }));
  },

  cancelGoalAnimation: (goalId: string) => {
    const animation = get().goalAnimations.find(a => a.goalId === goalId);
    
    if (animation) {
      // Cancel the animation frame
      if (animation.animationFrame) {
        cancelAnimationFrame(animation.animationFrame);
      }
      // Clear the timeout
      if (animation.timeoutId) {
        clearTimeout(animation.timeoutId);
      }
    }

    set(state => ({
      goalAnimations: state.goalAnimations.filter(a => a.goalId !== goalId)
    }));
  },

  updateProgress: (taskId: string, date: string, progress: number) => {
    set(state => ({
      animations: state.animations.map(a => 
        a.taskId === taskId && a.date === date 
          ? { ...a, progress } 
          : a
      )
    }));
  },

  getAnimation: (taskId: string, date: string) => {
    return get().animations.find(
      a => a.taskId === taskId && a.date === date
    );
  },

  getGoalAnimation: (goalId: string) => {
    return get().goalAnimations.find(a => a.goalId === goalId);
  },
}));