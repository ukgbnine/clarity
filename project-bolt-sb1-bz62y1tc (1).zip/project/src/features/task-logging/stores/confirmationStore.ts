import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ConfirmationState {
  showTaskCompletionConfirmation: boolean;
  setShowTaskCompletionConfirmation: (show: boolean) => void;
}

export const useConfirmationStore = create<ConfirmationState>()(
  persist(
    (set) => ({
      showTaskCompletionConfirmation: true,
      setShowTaskCompletionConfirmation: (show: boolean) => set({ showTaskCompletionConfirmation: show }),
    }),
    {
      name: 'confirmation-preferences',
    }
  )
);