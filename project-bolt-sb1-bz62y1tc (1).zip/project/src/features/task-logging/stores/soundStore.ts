import { create } from 'zustand';

interface SoundState {
  completionSound: HTMLAudioElement | null;
  initializeCompletionSound: () => void;
  playCompletionSound: () => void;
}

export const useSoundStore = create<SoundState>()((set, get) => ({
  completionSound: null,

  initializeCompletionSound: () => {
    // Using a shorter, more satisfying "success" sound
    // This sound has a bright, positive tone with no fade-in
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2018/2018-preview.mp3');
    audio.preload = 'auto';
    // Ensure volume is at maximum for consistent playback
    audio.volume = 1.0;
    set({ completionSound: audio });
  },

  playCompletionSound: () => {
    const { completionSound } = get();
    if (completionSound) {
      // Reset the audio to the start
      completionSound.currentTime = 0;
      // Force load the audio before playing
      completionSound.load();
      // Play immediately
      const playPromise = completionSound.play();
      
      if (playPromise) {
        playPromise.catch(error => {
          console.warn('Failed to play completion sound:', error);
        });
      }
    }
  },
}));