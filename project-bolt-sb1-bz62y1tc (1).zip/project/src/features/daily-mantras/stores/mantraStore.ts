import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Mantra {
  id: string;
  text: string;
  createdAt: number;
}

interface MantraState {
  mantras: Mantra[];
  addMantra: (text: string) => void;
  updateMantra: (id: string, text: string) => void;
  deleteMantra: (id: string) => void;
}

const defaultMantra: Mantra = {
  id: 'default-mantra',
  text: "Don't over complicate it. The work you're doing today is all you need to do to. Just stay consistent.",
  createdAt: Date.now(),
};

export const useMantraStore = create<MantraState>()(
  persist(
    (set) => ({
      mantras: [defaultMantra],
      
      addMantra: (text: string) => set(state => ({
        mantras: [
          ...state.mantras,
          {
            id: crypto.randomUUID(),
            text: text.trim(),
            createdAt: Date.now(),
          }
        ]
      })),

      updateMantra: (id: string, text: string) => set(state => ({
        mantras: state.mantras.map(mantra =>
          mantra.id === id
            ? { ...mantra, text: text.trim() }
            : mantra
        )
      })),

      deleteMantra: (id: string) => set(state => ({
        mantras: state.mantras.filter(mantra => mantra.id !== id)
      })),
    }),
    {
      name: 'daily-mantras',
      // Only initialize with default mantra if there are no existing mantras
      partialize: (state) => ({
        ...state,
        mantras: state.mantras.length === 0 ? [defaultMantra] : state.mantras,
      }),
    }
  )
);