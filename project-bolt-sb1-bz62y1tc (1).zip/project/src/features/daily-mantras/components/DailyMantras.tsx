import React, { useState, useRef, useEffect } from 'react';
import { X } from 'lucide-react';
import { useMantraStore } from '../stores/mantraStore';

export function DailyMantras() {
  const { mantras, addMantra, updateMantra, deleteMantra } = useMantraStore();
  const [isAdding, setIsAdding] = useState(false);
  const [newMantra, setNewMantra] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);
  const addInputRef = useRef<HTMLInputElement>(null);

  // Focus the edit input when starting to edit
  useEffect(() => {
    if (editingId && editInputRef.current) {
      editInputRef.current.focus();
    }
  }, [editingId]);

  // Focus the add input when starting to add
  useEffect(() => {
    if (isAdding && addInputRef.current) {
      addInputRef.current.focus();
    }
  }, [isAdding]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMantra.trim()) {
      addMantra(newMantra);
      setNewMantra('');
      setIsAdding(false);
    }
  };

  const startEditing = (mantra: { id: string; text: string }) => {
    setEditingId(mantra.id);
    setEditText(mantra.text);
  };

  const handleUpdate = (id: string) => {
    if (editText.trim()) {
      updateMantra(id, editText);
    }
    setEditingId(null);
    setEditText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent, id?: string) => {
    if (e.key === 'Enter') {
      if (id) {
        handleUpdate(id);
      } else {
        handleSubmit(e);
      }
    } else if (e.key === 'Escape') {
      if (id) {
        setEditingId(null);
        setEditText('');
      } else {
        setIsAdding(false);
        setNewMantra('');
      }
    }
  };

  return (
    <div className="mt-8">
      <h2 className="text-2xl mb-6">
        <span className="font-medium text-gray-900">Daily Mantras</span>
        <span className="font-light text-gray-500 italic ml-2 tracking-wide">- notes to self</span>
      </h2>

      {/* Mantras List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <ul className="divide-y divide-gray-200">
          {mantras.map((mantra) => (
            <li
              key={mantra.id}
              className="flex items-center gap-3 p-4 group hover:bg-gray-50 transition-colors"
            >
              <div className="w-2 h-2 rounded-full bg-orange-500 flex-shrink-0" />
              
              {editingId === mantra.id ? (
                <input
                  ref={editInputRef}
                  type="text"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onBlur={() => handleUpdate(mantra.id)}
                  onKeyDown={(e) => handleKeyDown(e, mantra.id)}
                  className="flex-1 bg-transparent text-gray-900 focus:outline-none"
                />
              ) : (
                <span
                  onClick={() => startEditing(mantra)}
                  className="flex-1 text-gray-900 cursor-text"
                >
                  {mantra.text}
                </span>
              )}

              <button
                onClick={() => deleteMantra(mantra.id)}
                className="p-1 text-gray-400 hover:text-red-500 rounded transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </li>
          ))}

          {/* Add New Mantra Item */}
          <li className="flex items-center gap-3 p-4 group hover:bg-gray-50 transition-colors">
            <div className="w-2 h-2 rounded-full bg-orange-500 flex-shrink-0" />
            
            {isAdding ? (
              <form onSubmit={handleSubmit} className="flex-1">
                <input
                  ref={addInputRef}
                  type="text"
                  value={newMantra}
                  onChange={(e) => setNewMantra(e.target.value)}
                  onBlur={() => {
                    if (!newMantra.trim()) {
                      setIsAdding(false);
                    }
                  }}
                  onKeyDown={(e) => handleKeyDown(e)}
                  placeholder="Type your mantra and press Enter..."
                  className="w-full bg-transparent text-gray-900 focus:outline-none"
                />
              </form>
            ) : (
              <button
                onClick={() => setIsAdding(true)}
                className="flex-1 text-left text-gray-500 hover:text-gray-900"
              >
                Add new mantra...
              </button>
            )}
          </li>
        </ul>
      </div>
    </div>
  );
}