import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { ChallengeCard } from './ChallengeCard';
import { useChallengesStore } from '../stores/challengesStore';

export function ClubsAndChallenges() {
  const { challenges } = useChallengesStore();
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 2;
  const totalPages = Math.ceil(challenges.length / itemsPerPage);

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % totalPages);
  };

  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + totalPages) % totalPages);
  };

  const currentChallenges = challenges.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">Clubs & Challenges</span>
        </h2>
      </div>

      <div className="relative">
        <div className="grid grid-cols-2 gap-4">
          {currentChallenges.map(challenge => (
            <ChallengeCard
              key={challenge.id}
              challenge={challenge}
            />
          ))}
        </div>

        {/* Navigation Buttons */}
        <div className="absolute inset-y-0 left-0 flex items-center -ml-4">
          <button
            onClick={prevPage}
            className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
            aria-label="Previous challenges"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
        <div className="absolute inset-y-0 right-0 flex items-center -mr-4">
          <button
            onClick={nextPage}
            className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
            aria-label="Next challenges"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Page Indicators */}
        <div className="flex justify-center gap-2 mt-4">
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentPage(index)}
              className={`w-2 h-2 rounded-full transition-colors ${
                currentPage === index
                  ? 'bg-orange-500'
                  : 'bg-gray-300 hover:bg-gray-400'
              }`}
              aria-label={`Go to page ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}