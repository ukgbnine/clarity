import React, { useState } from 'react';
import { ChallengeModal } from './ChallengeModal';

interface ChallengeCardProps {
  challenge: {
    id: string;
    name: string;
    image?: string;
  };
}

export function ChallengeCard({ challenge }: ChallengeCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsModalOpen(true)}
        className="w-full bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:border-gray-300 transition-all hover:shadow-md"
      >
        {challenge.image && (
          <div className="relative h-40 overflow-hidden">
            <img
              src={challenge.image}
              alt={challenge.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          </div>
        )}
        <div className="p-4">
          <h3 className="text-lg font-medium text-gray-900">
            {challenge.name}
          </h3>
        </div>
      </button>

      <ChallengeModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        challenge={challenge}
      />
    </>
  );
}