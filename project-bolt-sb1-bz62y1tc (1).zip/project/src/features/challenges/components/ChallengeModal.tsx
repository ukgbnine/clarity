import React, { useState } from 'react';
import { Modal } from '../../../components/ui/Modal';
import { GoalCard } from '../../../components/planning/GoalCard';
import { TaskCard } from '../../../components/planning/tasks-and-habits/TaskCard';
import { HabitScheduler } from '../../../components/planning/tasks-and-habits/HabitScheduler';
import { WeeklyView } from '../../../components/planning/tasks-and-habits/WeeklyView';
import { useGoals } from '../../../contexts/GoalsContext';
import { useTasks } from '../../../contexts/TasksContext';
import { useChallengesStore } from '../stores/challengesStore';
import { 
  PersonStanding as PersonRunning, 
  Dumbbell, 
  TrendingUp, 
  Briefcase,
  ArrowRight
} from 'lucide-react';

interface ChallengeModalProps {
  isOpen: boolean;
  onClose: () => void;
  challenge: {
    id: string;
    name: string;
    image?: string;
  };
}

const getChallengeIcon = (challengeId: string) => {
  switch (challengeId) {
    case 'runners':
      return PersonRunning;
    case 'gym-club':
      return Dumbbell;
    case 'cv-upgrade':
      return (props: any) => (
        <TrendingUp 
          {...props} 
          style={{ 
            ...props.style,
            transform: `${props.style?.transform || ''} rotate(-22.5deg)` 
          }} 
        />
      );
    case 'side-hustles':
      return Briefcase;
    default:
      return null;
  }
};

const getChallengeGoal = (challengeId: string) => {
  const icon = getChallengeIcon(challengeId);
  switch (challengeId) {
    case 'runners':
      return {
        id: 'runners-goal',
        name: 'Runners Club',
        targetDate: 'End of 2024',
        icon
      };
    case 'gym-club':
      return {
        id: 'gym-goal',
        name: 'Gym Club',
        targetDate: 'End of 2024',
        icon
      };
    case 'cv-upgrade':
      return {
        id: 'cv-goal',
        name: 'CV Upgrade',
        targetDate: 'End of 2024',
        icon
      };
    case 'side-hustles':
      return {
        id: 'side-hustle-goal',
        name: 'Side Hustles',
        targetDate: 'End of 2024',
        icon
      };
    default:
      return null;
  }
};

const getChallengeTask = (challengeId: string) => {
  const icon = getChallengeIcon(challengeId);
  switch (challengeId) {
    case 'runners':
      return {
        id: 'running-habit',
        name: 'Run',
        type: 'habit',
        icon
      };
    case 'gym-club':
      return {
        id: 'gym-habit',
        name: 'Go to the gym',
        type: 'habit',
        icon
      };
    case 'cv-upgrade':
      return {
        id: 'cv-task',
        name: 'Explore new skills',
        type: 'task',
        icon
      };
    case 'side-hustles':
      return {
        id: 'side-hustle-habit',
        name: 'Work on side project',
        type: 'habit',
        icon
      };
    default:
      return null;
  }
};

export function ChallengeModal({ isOpen, onClose, challenge }: ChallengeModalProps) {
  const [scheduleType, setScheduleType] = useState<'daily' | 'weekly' | null>(null);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [selectedDates, setSelectedDates] = useState<Date[]>([]);
  const [isJoining, setIsJoining] = useState(false);
  const goal = getChallengeGoal(challenge.id);
  const task = getChallengeTask(challenge.id);
  
  const { addGoal } = useGoals();
  const { addTask } = useTasks();
  const { joinChallenge, isJoined } = useChallengesStore();

  const handleScheduleTypeChange = (type: 'daily' | 'weekly') => {
    setScheduleType(type);
    if (type === 'daily') {
      setSelectedDays([0, 1, 2, 3, 4, 5, 6]); // Select all days
    } else {
      setSelectedDays([]); // Clear selection for weekly
    }
  };

  const handleDayToggle = (day: number) => {
    setSelectedDays(prev => {
      const newDays = prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day].sort((a, b) => a - b);

      // If all days are selected, switch to daily
      if (newDays.length === 7 && scheduleType === 'weekly') {
        setScheduleType('daily');
      }
      // If removing a day while on daily, switch to weekly
      else if (scheduleType === 'daily' && newDays.length < 7) {
        setScheduleType('weekly');
      }

      return newDays;
    });
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDates(prev => {
      const dateString = date.toDateString();
      const exists = prev.some(d => d.toDateString() === dateString);
      
      if (exists) {
        return prev.filter(d => d.toDateString() !== dateString);
      } else {
        return [...prev, date];
      }
    });
  };

  const handleJoinChallenge = () => {
    if (!goal || !task || isJoining) return;

    // For CV challenge, require exactly 3 dates
    if (challenge.id === 'cv-upgrade' && selectedDates.length !== 3) return;

    // For other challenges, require schedule type and days
    if (challenge.id !== 'cv-upgrade' && (!scheduleType || selectedDays.length === 0)) return;

    setIsJoining(true);

    try {
      // Add the goal first
      const goalId = addGoal({
        name: goal.name,
        targetDate: goal.targetDate,
      });

      if (challenge.id === 'cv-upgrade') {
        // Add the task with fixed dates
        addTask({
          name: task.name,
          type: 'fixed',
          dates: selectedDates,
          goalId,
        });
      } else {
        // Calculate habit dates based on schedule
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const endDate = new Date(today);
        endDate.setMonth(endDate.getMonth() + 3);

        let dates: Date[] = [];
        let currentDate = new Date(today);

        while (currentDate <= endDate) {
          if (scheduleType === 'daily' || 
              selectedDays.includes(currentDate.getDay() === 0 ? 6 : currentDate.getDay() - 1)) {
            dates.push(new Date(currentDate));
          }
          currentDate.setDate(currentDate.getDate() + 1);
        }

        // Add the habit
        addTask({
          name: task.name,
          type: 'habit',
          frequency: scheduleType,
          dates,
          goalId,
        });
      }

      // Mark challenge as joined
      joinChallenge(challenge.id);

      // Close the modal
      onClose();
    } catch (error) {
      console.error('Error joining challenge:', error);
    } finally {
      setIsJoining(false);
    }
  };

  const hasJoined = isJoined(challenge.id);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={challenge.name}>
      <div className="space-y-6">
        {/* Challenge Image */}
        {challenge.image && (
          <div className="relative h-48 rounded-lg overflow-hidden">
            <img
              src={challenge.image}
              alt={challenge.name}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Description */}
        <div className="space-y-2">
          <h3 className="font-medium text-gray-900">About this Challenge</h3>
          <p className="text-gray-600">
            {challenge.id === 'runners' && 
              "Join fellow runners in achieving your running goals. Whether you're a beginner or experienced, this challenge helps you stay consistent with your running routine."}
            {challenge.id === 'gym-club' && 
              "Build strength and consistency in your gym workouts. Track your progress, share achievements, and motivate each other to reach fitness goals."}
            {challenge.id === 'cv-upgrade' && 
              "Find 3 half-hour slots in your schedule to explore new skills you could learn."}
            {challenge.id === 'side-hustles' && 
              "Turn your side project into a success story. Share progress, get advice, and stay accountable with others building their side hustles."}
          </p>
        </div>

        {/* Goal and Task Cards Side by Side */}
        <div className="grid grid-cols-2 gap-6">
          {/* Challenge Goal */}
          {goal && (
            <div className="space-y-2">
              <h3 className="font-medium text-gray-900">Challenge Goal</h3>
              <div className="h-full">
                <GoalCard 
                  goal={goal}
                  onClick={() => {}}
                  icon={goal.icon}
                />
              </div>
            </div>
          )}

          {/* Challenge Task */}
          {task && goal && (
            <div className="space-y-2">
              <h3 className="font-medium text-gray-900">
                Challenge {task.type === 'habit' ? 'Habit' : 'Task'}
              </h3>
              <div className="h-full">
                <TaskCard
                  name={task.name}
                  onClick={() => {}}
                  icon={task.icon}
                  goalName={goal.name}
                  goalId={goal.id}
                />
              </div>
            </div>
          )}
        </div>

        {/* Scheduling Options */}
        {!hasJoined && (
          <div className="space-y-3">
            {challenge.id === 'cv-upgrade' ? (
              <>
                <h3 className="font-medium text-gray-900">Select 3 Days</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Choose 3 days to explore potential new skills. Each session should be at least 30 minutes.
                </p>
                <WeeklyView 
                  selectable 
                  selectedDates={selectedDates}
                  onDateSelect={handleDateSelect}
                />
                {selectedDates.length !== 3 && (
                  <p className="text-sm text-orange-600 mt-2">
                    Please select exactly 3 days to continue
                  </p>
                )}
              </>
            ) : (
              <>
                <h3 className="font-medium text-gray-900">Schedule Your Habit</h3>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleScheduleTypeChange('daily')}
                    className={`p-4 text-left border rounded-lg transition-colors ${
                      scheduleType === 'daily'
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-gray-900">Daily</div>
                    <div className="text-sm text-gray-500">Every day</div>
                  </button>
                  <button
                    onClick={() => handleScheduleTypeChange('weekly')}
                    className={`p-4 text-left border rounded-lg transition-colors ${
                      scheduleType === 'weekly'
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-gray-900">Weekly</div>
                    <div className="text-sm text-gray-500">Selected days</div>
                  </button>
                </div>

                {/* Day Selection */}
                {scheduleType && (
                  <div className="space-y-3">
                    <label className="block text-sm font-medium text-gray-700">
                      Select days for this habit
                    </label>
                    <HabitScheduler
                      selectedDays={selectedDays}
                      onDayToggle={handleDayToggle}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Join Button */}
        <div className="flex justify-end pt-4 border-t">
          {hasJoined ? (
            <button
              disabled
              className="px-6 py-2 text-sm font-medium text-white bg-gray-400 rounded-md cursor-not-allowed"
            >
              Already Joined
            </button>
          ) : (
            <button
              onClick={handleJoinChallenge}
              disabled={
                isJoining || 
                (challenge.id === 'cv-upgrade' 
                  ? selectedDates.length !== 3
                  : !scheduleType || selectedDays.length === 0)
              }
              className="px-6 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isJoining ? 'Joining...' : 'Join Challenge'}
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}