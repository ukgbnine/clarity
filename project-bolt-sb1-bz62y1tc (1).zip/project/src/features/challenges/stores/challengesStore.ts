import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Challenge {
  id: string;
  name: string;
  image?: string;
}

interface ChallengesState {
  challenges: Challenge[];
  joinedChallenges: string[];
  joinChallenge: (challengeId: string) => void;
  isJoined: (challengeId: string) => boolean;
}

// Clear existing data from localStorage
localStorage.removeItem('challenges-data');

export const useChallengesStore = create<ChallengesState>()(
  persist(
    (set, get) => ({
      challenges: [
        {
          id: 'runners',
          name: 'Runners',
          image: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=400&h=300&fit=crop',
        },
        {
          id: 'gym-club',
          name: 'Gym Club',
          image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=300&fit=crop',
        },
        {
          id: 'cv-upgrade',
          name: 'CV Upgrade',
          image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&h=300&fit=crop',
        },
        {
          id: 'side-hustles',
          name: 'Side Hustles',
          image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=400&h=300&fit=crop',
        },
      ],
      joinedChallenges: [],

      joinChallenge: (challengeId: string) => {
        const isAlreadyJoined = get().isJoined(challengeId);
        if (!isAlreadyJoined) {
          set(state => ({
            joinedChallenges: [...state.joinedChallenges, challengeId]
          }));
        }
      },

      isJoined: (challengeId: string) => {
        return get().joinedChallenges.includes(challengeId);
      },
    }),
    {
      name: 'challenges-data',
    }
  )
);