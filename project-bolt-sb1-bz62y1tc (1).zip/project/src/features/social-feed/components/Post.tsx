import React, { useState } from 'react';
import { Heart, Trophy, Target, MoreVertical, Pencil, Trash2 } from 'lucide-react';
import { GoalCard } from '../../../components/planning/GoalCard';
import { useGoals } from '../../../contexts/GoalsContext';
import { useFeedStore } from '../stores/feedStore';
import { ConfirmationModal } from '../../../components/ui/ConfirmationModal';

interface PostProps {
  post: {
    id: string;
    type: 'goal' | 'challenge' | 'accolade';
    goalId?: string;
    description: string;
    createdAt: number;
    userId: string;
  };
}

export function Post({ post }: PostProps) {
  const { goals } = useGoals();
  const { celebratePost, hasCelebrated, updatePost, deletePost } = useFeedStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedDescription, setEditedDescription] = useState(post.description);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const goal = post.goalId ? goals.find(g => g.id === post.goalId) : null;
  const hasCelebratedPost = hasCelebrated(post.id, 'current-user');

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const handleCelebrate = () => {
    if (!hasCelebratedPost) {
      celebratePost(post.id, 'current-user');
    }
  };

  const handleSaveEdit = () => {
    updatePost(post.id, editedDescription.trim());
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditedDescription(post.description);
    setIsEditing(false);
  };

  // Get the appropriate icon based on post type
  const getPostIcon = () => {
    switch (post.type) {
      case 'challenge':
        return Target;
      case 'goal':
      default:
        return Trophy;
    }
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-4 space-y-3">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                <img
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
                  alt="User avatar"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="font-medium text-gray-900">You</div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-gray-500">{formatDate(post.createdAt)}</div>
              
              {/* Edit Button */}
              {!isEditing && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <Pencil className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>

          {/* Goal Card */}
          {goal && (
            <GoalCard 
              goal={goal} 
              onClick={() => {}} 
              icon={getPostIcon()}
            />
          )}

          {/* Description */}
          {isEditing ? (
            <div className="space-y-3">
              <textarea
                value={editedDescription}
                onChange={(e) => setEditedDescription(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500 min-h-[60px] resize-none"
                placeholder="Add a description to your post (optional)..."
              />
              <div className="flex justify-between">
                <button
                  onClick={() => setIsDeleteModalOpen(true)}
                  className="px-3 py-1.5 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50 flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={handleCancelEdit}
                    className="px-3 py-1.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveEdit}
                    className="px-3 py-1.5 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          ) : (
            post.description && (
              <p className="text-gray-700 whitespace-pre-wrap text-sm">{post.description}</p>
            )
          )}

          {/* Celebrate Button */}
          {!isEditing && (
            <div className="flex justify-end">
              <button
                onClick={handleCelebrate}
                className={`p-1.5 rounded-full transition-colors ${
                  hasCelebratedPost
                    ? 'text-orange-500 bg-orange-50'
                    : 'text-gray-400 hover:text-orange-500 hover:bg-orange-50'
                }`}
                aria-label="Celebrate"
              >
                <Heart className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={() => {
          deletePost(post.id);
          setIsDeleteModalOpen(false);
          setIsEditing(false);
        }}
        title="Delete Post"
        message="Are you sure you want to delete this post? This action cannot be undone."
      />
    </>
  );
}