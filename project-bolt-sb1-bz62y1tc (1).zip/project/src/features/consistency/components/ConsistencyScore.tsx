import React, { useEffect, useState } from 'react';
import { Loader2, Medal, Trophy, Info } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal';
import { useAuth } from '../../../contexts/AuthContext';
import { useConsistencyStore } from '../../task-logging/stores/consistencyStore';

export function ConsistencyScore() {
  const { user } = useAuth();
  const consistencyStore = useConsistencyStore();
  const [animatedScore, setAnimatedScore] = useState(0);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);

  // Initialize consistency store and set up subscriptions
  useEffect(() => {
    if (user) {
      // Initialize store and subscribe to changes
      const cleanup = consistencyStore.subscribeToChanges(user.id);
      consistencyStore.initialize();

      // Calculate initial score
      consistencyStore.calculateUserScore(user.id);

      return () => cleanup();
    }
  }, [user?.id]);

  // Get current user's score
  const score = user ? consistencyStore.scores[user.id] || 0 : 0;

  // Animate score changes
  useEffect(() => {
    if (score === animatedScore) return;

    const duration = 1000; // 1 second animation
    const startTime = performance.now();
    const startScore = animatedScore;
    
    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Use easeOutQuad for smooth animation
      const easeOutQuad = (t: number) => t * (2 - t);
      const easedProgress = easeOutQuad(progress);
      
      setAnimatedScore(Math.round(startScore + (score - startScore) * easedProgress));
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, [score, animatedScore]);

  // Calculate circle dimensions
  const radius = 110;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (animatedScore / 100) * circumference;

  // Get consistency icon based on score
  const getConsistencyIcon = () => {
    if (animatedScore < 25) {
      return <Loader2 className="w-10 h-10 text-gray-400 animate-spin" />;
    } else if (animatedScore < 55) {
      return <Medal className="w-10 h-10 text-gray-400" />;
    } else if (animatedScore < 100) {
      return <Medal className="w-10 h-10 text-orange-500" />;
    } else {
      return <Trophy className="w-10 h-10 text-orange-500" />;
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">Consistency</span>
        </h2>
        <button
          onClick={() => setIsInfoModalOpen(true)}
          className="p-2.5 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
          aria-label="Learn about consistency"
        >
          <Info className="w-5 h-5" />
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div className="flex flex-col items-center">
          <div className="relative w-72 h-72">
            {/* Background circle */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="144"
                cy="144"
                r={radius}
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-gray-200"
              />
              {/* Progress circle */}
              <circle
                cx="144"
                cy="144"
                r={radius}
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeLinecap="round"
                className={`transition-all duration-300 ${
                  animatedScore >= 55 ? 'text-orange-500' : 'text-gray-400'
                }`}
                style={{
                  strokeDasharray: circumference,
                  strokeDashoffset: offset,
                }}
              />
            </svg>
            {/* Percentage text and icon */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-bold text-gray-900 mb-2">
                {animatedScore}%
              </span>
              {getConsistencyIcon()}
            </div>
          </div>

          {/* Motivational Text */}
          <div className="mt-4 text-center space-y-4">
            {animatedScore === 100 ? (
              <>
                <p className="text-sm text-gray-600">
                  NICE! You are 100% on the path to achieving your goals.
                </p>
                <p className="text-sm text-gray-600">
                  Stay consistent, keep being your best self, and success is inevitable.
                </p>
              </>
            ) : (
              <>
                <p className="text-sm text-gray-600">
                  Each step taken today is a step closer to the person you want to become.
                </p>
                <p className="text-sm text-gray-600">
                  Stay consistent and watch the transformation unfold.
                </p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Info Modal */}
      <Modal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
        title="Consistency is Key"
      >
        <div className="space-y-6 text-gray-700">
          <blockquote className="italic border-l-4 border-orange-500 pl-4">
            "We are what we repeatedly do. Excellence, then, is not an act, but a habit."*
          </blockquote>

          <p>
            Success is a result of small, consistent actions compounded over time.
          </p>

          <p>
            Many people give up in the "valley of disappointment"**—the point where results haven't yet caught up with their effort. But the truth is, success takes time to surface.
          </p>

          <p>
            Even if results aren't visible now, trust the process. The compounding effect of your efforts will eventually create breakthroughs.**
          </p>

          <p>
            Your consistency is proof for yourself that you're progressing towards your goals.
          </p>

          <div className="text-sm text-gray-500 space-y-2 pt-4 border-t">
            <p>*Quote from Will Durant paraphrasing Aristotle</p>
            <p>**Check out James Clear - these ideas are from his book, Atomic Habits (a must-read)</p>
          </div>
        </div>
      </Modal>
    </div>
  );
}