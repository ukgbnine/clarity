import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ProfileAccolade {
  weekStartDate: string; // ISO date string
  achieved: boolean;
}

interface ProfileAccoladesState {
  accolades: ProfileAccolade[];
  getCurrentStreak: () => number;
  getAllTimeStreak: () => number;
  checkWeeklyAccolade: (score: number) => void;
}

export const useProfileAccoladesStore = create<ProfileAccoladesState>()(
  persist(
    (set, get) => ({
      accolades: [],

      getCurrentStreak: () => {
        const { accolades } = get();
        const sortedAccolades = accolades
          .sort((a, b) => new Date(b.weekStartDate).getTime() - new Date(a.weekStartDate).getTime());

        let streak = 0;
        let currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);

        // Start from the most recent week
        for (const accolade of sortedAccolades) {
          const weekStart = new Date(accolade.weekStartDate);
          const weekDiff = Math.floor((currentDate.getTime() - weekStart.getTime()) / (7 * 24 * 60 * 60 * 1000));

          // Break if there's a gap in weeks or if the accolade wasn't achieved
          if (weekDiff > streak + 1 || !accolade.achieved) break;

          if (accolade.achieved) {
            streak++;
          }
        }

        return streak;
      },

      getAllTimeStreak: () => {
        const { accolades } = get();
        const sortedAccolades = accolades
          .sort((a, b) => new Date(a.weekStartDate).getTime() - new Date(b.weekStartDate).getTime());

        let maxStreak = 0;
        let currentStreak = 0;

        for (let i = 0; i < sortedAccolades.length; i++) {
          if (sortedAccolades[i].achieved) {
            currentStreak++;
            maxStreak = Math.max(maxStreak, currentStreak);
          } else {
            currentStreak = 0;
          }

          // Check for gaps between weeks
          if (i < sortedAccolades.length - 1) {
            const currentWeek = new Date(sortedAccolades[i].weekStartDate);
            const nextWeek = new Date(sortedAccolades[i + 1].weekStartDate);
            const weekDiff = Math.floor((nextWeek.getTime() - currentWeek.getTime()) / (7 * 24 * 60 * 60 * 1000));

            if (weekDiff > 1) {
              currentStreak = 0;
            }
          }
        }

        return maxStreak;
      },

      checkWeeklyAccolade: (score: number) => {
        // Get the start of the current week
        const now = new Date();
        const dayOfWeek = now.getDay();
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - dayOfWeek);
        weekStart.setHours(0, 0, 0, 0);

        // Check if we already have an accolade for this week
        const weekStartStr = weekStart.toISOString();
        const existingAccolade = get().accolades.find(
          a => a.weekStartDate === weekStartStr
        );

        if (!existingAccolade) {
          set(state => ({
            accolades: [
              ...state.accolades,
              {
                weekStartDate: weekStartStr,
                achieved: score >= 75,
              }
            ]
          }));
        }
      },
    }),
    {
      name: 'profile-accolades',
    }
  )
);