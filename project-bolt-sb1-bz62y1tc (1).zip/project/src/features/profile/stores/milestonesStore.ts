import { create } from 'zustand';
import { supabase } from '../../../lib/supabase';
import type { Database } from '../../../lib/database.types';

type Milestone = Database['public']['Tables']['milestones']['Row'];

interface MilestonesState {
  milestones: Milestone[];
  loading: boolean;
  error: string | null;
  addMilestone: (milestone: Omit<Milestone, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateMilestone: (id: string, milestone: Partial<Milestone>) => Promise<void>;
  deleteMilestone: (id: string) => Promise<void>;
  fetchMilestones: () => Promise<void>;
}

export const useMilestonesStore = create<MilestonesState>()((set, get) => ({
  milestones: [],
  loading: false,
  error: null,

  fetchMilestones: async () => {
    try {
      set({ loading: true, error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('milestones')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false });

      if (error) throw error;

      set({ milestones: data || [] });
    } catch (error) {
      console.error('Error fetching milestones:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
    } finally {
      set({ loading: false });
    }
  },

  addMilestone: async (milestone) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('milestones')
        .insert({
          ...milestone,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      set(state => ({
        milestones: [data, ...state.milestones],
      }));
    } catch (error) {
      console.error('Error adding milestone:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      throw error;
    }
  },

  updateMilestone: async (id, updates) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('milestones')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      set(state => ({
        milestones: state.milestones.map(milestone =>
          milestone.id === id ? data : milestone
        ),
      }));
    } catch (error) {
      console.error('Error updating milestone:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      throw error;
    }
  },

  deleteMilestone: async (id) => {
    try {
      set({ error: null });

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('milestones')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      set(state => ({
        milestones: state.milestones.filter(milestone => milestone.id !== id),
      }));
    } catch (error) {
      console.error('Error deleting milestone:', error);
      set({ error: error instanceof Error ? error.message : 'An error occurred' });
      throw error;
    }
  },
}));