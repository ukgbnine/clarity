import React from 'react';
import { ArrowRight, Trophy } from 'lucide-react';
import { useGoals } from '../../../contexts/GoalsContext';
import { useMilestonesStore } from '../stores/milestonesStore';
import { GoalCard } from '../../../components/planning/GoalCard';

interface MyJourneyProps {
  onTimelineClick: () => void;
}

export function MyJourney({ onTimelineClick }: MyJourneyProps) {
  const { goals } = useGoals();
  const { milestones } = useMilestonesStore();

  // Get the most recent achieved goal
  const recentGoal = goals
    .filter(goal => goal.achieved)
    .sort((a, b) => {
      const dateA = a.targetDate ? new Date(a.targetDate).getTime() : 0;
      const dateB = b.targetDate ? new Date(b.targetDate).getTime() : 0;
      return dateB - dateA;
    })[0];

  // Get the most recent milestone
  const recentMilestone = [...milestones]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">My Journey</span>
        </h2>
        <button
          onClick={onTimelineClick}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-900 bg-white hover:bg-gray-50 rounded-lg transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
        >
          <span>Timeline</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-6">
        {/* Most Recent Goal */}
        {recentGoal && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Most Recent Goal</h3>
            <GoalCard 
              goal={recentGoal} 
              onClick={() => {}} 
              icon={Trophy}
            />
          </div>
        )}

        {/* Most Recent Milestone */}
        {recentMilestone && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700">Most Recent Milestone</h3>
            <div className="bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg shadow-md border border-amber-300 p-4">
              <div className="flex flex-col">
                <h4 className="text-lg font-medium text-white">{recentMilestone.name}</h4>
                <span className="text-sm text-white/90 mt-1">{recentMilestone.date}</span>
              </div>
            </div>
          </div>
        )}

        {!recentGoal && !recentMilestone && (
          <div className="text-center py-8 text-gray-500">
            No achievements yet. Keep going!
          </div>
        )}
      </div>
    </div>
  );
}