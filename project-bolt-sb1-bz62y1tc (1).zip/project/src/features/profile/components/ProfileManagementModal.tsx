import React, { useState, useRef, useEffect } from 'react';
import { Modal } from '../../../components/ui/Modal';
import { Settings, UserPlus2, Inbox, Image as ImageIcon, Check, X } from 'lucide-react';
import { useFriendsStore } from '../../shared-journey/stores/friendsStore';
import { supabase } from '../../../lib/supabase';
import { useAuth } from '../../../contexts/AuthContext';
import type { Database } from '../../../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface ProfileManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProfileManagementModal({ isOpen, onClose }: ProfileManagementModalProps) {
  const [activeTab, setActiveTab] = useState<'settings' | 'requests'>('settings');
  const [profileImage, setProfileImage] = useState<string>('');
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const { 
    pendingRequests, 
    loading: requestsLoading,
    error: requestsError,
    fetchPendingRequests,
    acceptFriendRequest,
    rejectFriendRequest,
  } = useFriendsStore();

  // Load friend requests
  useEffect(() => {
    if (activeTab === 'requests') {
      fetchPendingRequests();
    }
  }, [activeTab, fetchPendingRequests]);

  // Load profile data
  useEffect(() => {
    async function loadProfile() {
      try {
        if (!user) return;

        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;

        setUsername(profile.username || '');
        setFullName(profile.full_name || '');
        setProfileImage(profile.avatar_url || '');
      } catch (error) {
        console.error('Error loading profile:', error);
      }
    }

    loadProfile();
  }, [user]);

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image size should be less than 5MB');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Upload image to storage
      const fileExt = file.name.split('.').pop();
      const filePath = `${user.id}/${crypto.randomUUID()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      // Update profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setProfileImage(publicUrl);
    } catch (error) {
      console.error('Error uploading image:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { error } = await supabase
        .from('profiles')
        .update({
          username: username.toLowerCase(),
          full_name: fullName,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;

      onClose();
    } catch (error) {
      console.error('Error updating profile:', error);
      setError(error instanceof Error ? error.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Profile Management">
      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-6">
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'settings'
              ? 'text-orange-600 border-b-2 border-orange-500'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Settings
        </button>
        <button
          onClick={() => setActiveTab('requests')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activeTab === 'requests'
              ? 'text-orange-600 border-b-2 border-orange-500'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Friend Requests
          {pendingRequests.received.length > 0 && (
            <span className="ml-2 px-2 py-0.5 text-xs bg-orange-100 text-orange-600 rounded-full">
              {pendingRequests.received.length}
            </span>
          )}
        </button>
      </div>

      {error && (
        <div className="mb-6 p-3 text-sm text-red-600 bg-red-50 rounded-md">
          {error}
        </div>
      )}

      {activeTab === 'settings' ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Profile Picture */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-4">Profile Picture</h3>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="relative w-32 h-32 mx-auto rounded-full overflow-hidden cursor-pointer group"
            >
              {profileImage ? (
                <>
                  <img 
                    src={profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ImageIcon className="w-6 h-6 text-white mb-2" />
                    <div className="text-sm font-medium text-white">Change Photo</div>
                  </div>
                </>
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-4xl font-medium">
                  {fullName?.[0]?.toUpperCase() || username?.[0]?.toUpperCase() || '?'}
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <p className="mt-2 text-xs text-gray-500 text-center">
              Click to upload a new photo. Maximum file size: 5MB
            </p>
          </div>

          {/* Account Settings */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-4">Account Settings</h3>
            <div className="space-y-4">
              {/* Username */}
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Enter username"
                />
              </div>

              {/* Full Name */}
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Enter full name"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Changes
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-4">
          {requestsLoading ? (
            <div className="text-center py-8">
              <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-solid border-orange-400 border-r-transparent" />
            </div>
          ) : requestsError ? (
            <div className="text-center py-8 text-red-600">
              {requestsError}
            </div>
          ) : pendingRequests.received.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No pending friend requests
            </div>
          ) : (
            pendingRequests.received.map(userId => (
              <div 
                key={userId}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                    {/* Avatar will be added when we fetch user details */}
                    <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500 text-xl font-medium">
                      ?
                    </div>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      Friend Request
                    </h3>
                    <p className="text-sm text-gray-500">
                      Someone wants to be your friend
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => rejectFriendRequest(userId)}
                    className="p-2 text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded-md transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => acceptFriendRequest(userId)}
                    className="p-2 text-green-600 hover:text-green-700 bg-green-50 hover:bg-green-100 rounded-md transition-colors"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </Modal>
  );
}