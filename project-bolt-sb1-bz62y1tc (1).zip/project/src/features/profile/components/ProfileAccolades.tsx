import React from 'react';
import { Award } from 'lucide-react';
import { useProfileAccoladesStore } from '../stores/profileAccoladesStore';

export function ProfileAccolades() {
  const { getCurrentStreak, getAllTimeStreak } = useProfileAccoladesStore();
  const currentStreak = getCurrentStreak();
  const allTimeStreak = getAllTimeStreak();

  return (
    <div>
      <h2 className="text-2xl mb-6">
        <span className="font-medium text-gray-900">Accolades</span>
      </h2>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="divide-y divide-gray-200">
          {/* Current Streak */}
          <div className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-50 rounded-lg">
                <Award className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-900">Current Streak</h3>
                <p className="text-2xl font-bold text-orange-500 mt-1">
                  {currentStreak} {currentStreak === 1 ? 'week' : 'weeks'}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  {currentStreak > 0 
                    ? 'You have maintained 75%+ consistency'
                    : 'Achieve 75%+ consistency to start a streak'}
                </p>
              </div>
            </div>
          </div>

          {/* All-Time Best */}
          <div className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-50 rounded-lg">
                <Award className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-900">All-Time Best</h3>
                <p className="text-2xl font-bold text-orange-500 mt-1">
                  {allTimeStreak} {allTimeStreak === 1 ? 'week' : 'weeks'}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  {allTimeStreak > 0 
                    ? 'Your highest consistency streak'
                    : 'No streaks achieved yet'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}