import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface NavLinkProps {
  icon: LucideIcon;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

export function NavLink({ icon: Icon, label, active = false, onClick }: NavLinkProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3.5 text-left transition-colors
        ${active 
          ? 'bg-[#f5f5f5] text-gray-900' 
          : 'text-gray-600 hover:bg-gray-100'
        }`}
    >
      <Icon className={`w-5 h-5 ${active ? 'text-gray-900' : 'text-gray-500'}`} />
      <span className="font-normal tracking-wide">{label}</span>
    </button>
  );
}