import React from 'react';
import { Home, LayoutGrid, Users, UserCircle, Settings } from 'lucide-react';
import { NavLink } from './NavLink';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: 'home' | 'planning' | 'social' | 'settings' | 'profile') => void;
}

export function Sidebar({ currentPage, onPageChange }: SidebarProps) {
  return (
    <nav className="fixed left-0 top-0 h-screen w-44 bg-white border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="px-4 py-6">
        <h1 className="text-2xl font-medium text-gray-900">Clarity</h1>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 py-6 space-y-1">
        <NavLink 
          icon={Home} 
          label="Home" 
          onClick={() => onPageChange('home')}
          active={currentPage === 'home'}
        />
        <NavLink 
          icon={LayoutGrid} 
          label="Overview" 
          onClick={() => onPageChange('planning')}
          active={currentPage === 'planning'}
        />
        <NavLink 
          icon={Users} 
          label="Social" 
          onClick={() => onPageChange('social')}
          active={currentPage === 'social'}
        />
      </div>

      {/* User Navigation */}
      <div className="py-6 space-y-1">
        <NavLink 
          icon={UserCircle} 
          label="Profile" 
          onClick={() => onPageChange('profile')}
          active={currentPage === 'profile'}
        />
        <NavLink 
          icon={Settings} 
          label="Settings" 
          onClick={() => onPageChange('settings')}
          active={currentPage === 'settings'}
        />
      </div>
    </nav>
  );
}