import React, { useState } from 'react';
import { Modal } from './Modal';
import { AlertTriangle } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  showDoNotAskAgain?: boolean;
  onDoNotAskAgainChange?: (checked: boolean) => void;
}

export function ConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  showDoNotAskAgain = false,
  onDoNotAskAgainChange,
}: ConfirmationModalProps) {
  const [doNotAskAgain, setDoNotAskAgain] = useState(false);

  const handleConfirm = () => {
    if (doNotAskAgain && onDoNotAskAgainChange) {
      onDoNotAskAgainChange(true);
    }
    onConfirm();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <div className="space-y-6">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-orange-100 rounded-full">
            <AlertTriangle className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <p className="text-gray-700">{message}</p>
          </div>
        </div>

        {showDoNotAskAgain && (
          <div className="flex items-center">
            <input
              type="checkbox"
              id="doNotAskAgain"
              checked={doNotAskAgain}
              onChange={(e) => setDoNotAskAgain(e.target.checked)}
              className="w-4 h-4 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
            />
            <label htmlFor="doNotAskAgain" className="ml-2 text-sm text-gray-600">
              Don't show this message again
            </label>
          </div>
        )}

        <div className="flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
          >
            Confirm
          </button>
        </div>
      </div>
    </Modal>
  );
}