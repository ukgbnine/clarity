import React from 'react';
import { X } from 'lucide-react';
import { createPortal } from 'react-dom';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  isNested?: boolean;
}

export function Modal({ isOpen, onClose, title, children, isNested = false }: ModalProps) {
  if (!isOpen) return null;

  const modalContent = (
    <div 
      className={`fixed inset-0 flex items-center justify-center p-4 overflow-y-auto ${
        isNested 
          ? 'z-[60] bg-black/60' 
          : 'z-50 bg-black/50'
      }`}
    >
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-xl font-medium text-gray-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4 max-h-[calc(100vh-16rem)] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );

  // Use createPortal to render the modal at the root level
  return createPortal(modalContent, document.body);
}