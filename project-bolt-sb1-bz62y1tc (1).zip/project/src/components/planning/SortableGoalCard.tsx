import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GoalCard } from './GoalCard';

interface SortableGoalCardProps {
  id: string;
  goal: {
    id: string;
    name: string;
    targetDate?: string;
  };
  onClick: () => void;
}

export function SortableGoalCard({ id, goal, onClick }: SortableGoalCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: id,
  });

  const style = transform ? {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : undefined,
    zIndex: isDragging ? 1 : undefined,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      className="touch-none"
    >
      <GoalCard 
        goal={goal}
        onClick={onClick}
        dragHandleProps={listeners}
      />
    </div>
  );
}