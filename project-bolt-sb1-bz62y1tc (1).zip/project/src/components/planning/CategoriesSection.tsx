import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { CategoryCard } from './CategoryCard';
import { useCategories } from '../../contexts/CategoriesContext';

export function CategoriesSection() {
  const { categories, addCategory, updateCategory, deleteCategory } = useCategories();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<{ id: string; name: string } | null>(null);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    addCategory(newCategoryName);
    setNewCategoryName('');
    setIsCreateModalOpen(false);
  };

  const handleEditCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCategory || !newCategoryName.trim()) return;

    updateCategory(selectedCategory.id, newCategoryName.trim());
    setNewCategoryName('');
    setSelectedCategory(null);
    setIsEditModalOpen(false);
  };

  const handleDeleteCategory = () => {
    if (!selectedCategory) return;
    deleteCategory(selectedCategory.id);
    setSelectedCategory(null);
    setIsEditModalOpen(false);
  };

  const openEditModal = (category: { id: string; name: string }) => {
    setSelectedCategory(category);
    setNewCategoryName(category.name);
    setIsEditModalOpen(true);
  };

  return (
    <section className="flex-1">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">Categories</span>
          <span className="font-light text-gray-500 italic ml-2 tracking-wide">- the areas of your life</span>
        </h2>
        <button
          onClick={() => {
            setNewCategoryName('');
            setIsCreateModalOpen(true);
          }}
          className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
          aria-label="Create new category"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map(category => (
          <CategoryCard
            key={category.id}
            name={category.name}
            onEdit={() => openEditModal(category)}
          />
        ))}
      </div>

      {/* Create Category Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create Category"
      >
        <form onSubmit={handleCreateCategory}>
          <div className="mb-4">
            <label htmlFor="categoryName" className="block text-sm font-medium text-gray-700 mb-1">
              Category Name
            </label>
            <input
              type="text"
              id="categoryName"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="e.g., Personal, Work, Health/Fitness..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              autoFocus
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
            >
              Create
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Category Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Category"
      >
        <form onSubmit={handleEditCategory}>
          <div className="mb-4">
            <label htmlFor="editCategoryName" className="block text-sm font-medium text-gray-700 mb-1">
              Category Name
            </label>
            <input
              type="text"
              id="editCategoryName"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              autoFocus
            />
          </div>
          <div className="flex justify-between">
            <button
              type="button"
              onClick={handleDeleteCategory}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      </Modal>
    </section>
  );
}