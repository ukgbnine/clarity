import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useGoals } from '../../contexts/GoalsContext';
import { useCompletionAnimationStore } from '../../features/task-logging/stores/completionAnimationStore';
import { useSoundStore } from '../../features/task-logging/stores/soundStore';
import { useConfirmationStore } from '../../features/task-logging/stores/confirmationStore';
import { useMilestonesStore } from '../../features/profile/stores/milestonesStore';
import { Calendar } from 'lucide-react';

interface EditGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  goalId: string;
}

export function EditGoalModal({ isOpen, onClose, goalId }: EditGoalModalProps) {
  const { goals, updateGoal, deleteGoal, markGoalAchieved } = useGoals();
  const { addMilestone } = useMilestonesStore();
  const goal = goals.find(g => g.id === goalId);
  const [name, setName] = useState(goal?.name || '');
  const [targetDate, setTargetDate] = useState(goal?.targetDate || '');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isAchieveModalOpen, setIsAchieveModalOpen] = useState(false);
  
  // Initialize with current date
  const today = new Date();
  const [achievementYear, setAchievementYear] = useState(today.getFullYear().toString());
  const [achievementMonth, setAchievementMonth] = useState(
    ['January', 'February', 'March', 'April', 'May', 'June',
     'July', 'August', 'September', 'October', 'November', 'December'][today.getMonth()]
  );
  const [achievementDay, setAchievementDay] = useState(today.getDate().toString());
  const [convertToMilestone, setConvertToMilestone] = useState(true);
  const { startAnimation } = useCompletionAnimationStore();
  const { playCompletionSound } = useSoundStore();

  if (!goal) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    updateGoal(goal.id, {
      name: name.trim(),
      targetDate: targetDate.trim() || undefined,
    });

    onClose();
  };

  const handleAchieveGoal = () => {
    setIsAchieveModalOpen(true);
  };

  const handleConfirmAchievement = () => {
    // Format the achievement date based on what's provided
    let achievementDate = achievementYear;
    if (achievementMonth) {
      achievementDate = `${achievementMonth} ${achievementYear}`;
      if (achievementDay) {
        achievementDate = `${achievementMonth} ${achievementDay}, ${achievementYear}`;
      }
    }

    // Start the animation
    startAnimation(goal.id, goal.id, achievementDate);
    
    // Close both modals
    setIsAchieveModalOpen(false);
    onClose();
    
    // After 4 seconds (matching the animation duration), play sound and mark as achieved
    setTimeout(() => {
      playCompletionSound();
      
      // Mark the goal as achieved with the achievement date
      markGoalAchieved(goal.id, achievementDate);

      // If converting to milestone, create the milestone
      if (convertToMilestone) {
        addMilestone({
          name: goal.name,
          date: achievementDate,
        });
      }
    }, 4000);
  };

  // Generate month options
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Generate day options based on selected month
  const getDaysInMonth = () => {
    if (!achievementMonth) return 31;
    const monthIndex = months.indexOf(achievementMonth);
    const year = parseInt(achievementYear);
    return new Date(year, monthIndex + 1, 0).getDate();
  };

  const days = Array.from({ length: getDaysInMonth() }, (_, i) => i + 1);

  // Generate year options (last 10 years)
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - i);

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} title="Edit Goal">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="goalName" className="block text-sm font-medium text-gray-700 mb-1">
              Goal Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="goalName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              placeholder="Enter goal name"
              autoFocus
              required
            />
          </div>

          <div>
            <label htmlFor="targetDate" className="block text-sm font-medium text-gray-700 mb-1">
              Target Date
            </label>
            <input
              type="text"
              id="targetDate"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              placeholder="e.g., End of 2024, Next month..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>

          {/* Mark as Achieved Button */}
          {!goal.achieved && (
            <button
              type="button"
              onClick={handleAchieveGoal}
              className="w-full px-4 py-3 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
            >
              Mark as Achieved!
            </button>
          )}

          <div className="flex justify-between pt-4 border-t">
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(true)}
                className="px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-md hover:bg-red-50"
              >
                Delete
              </button>
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Save Changes
              </button>
            </div>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={() => {
          deleteGoal(goal.id);
          setIsDeleteModalOpen(false);
          onClose();
        }}
        title="Delete Goal"
        message="Are you sure you want to delete this goal? This action cannot be undone."
      />

      {/* Achievement Modal */}
      <Modal
        isOpen={isAchieveModalOpen}
        onClose={() => setIsAchieveModalOpen(false)}
        title="Mark Goal as Achieved"
      >
        <div className="space-y-6">
          {/* Achievement Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              When did you achieve this goal? <span className="text-red-500">*</span>
            </label>
            <p className="text-sm text-gray-500 mb-4">
              Don't worry about being exact - you can be as specific as you'd like. Just the year, year and month, or if you remember the exact date, that works too!
            </p>
            <div className="flex gap-3">
              {/* Month Selection */}
              <select
                value={achievementMonth}
                onChange={(e) => {
                  setAchievementMonth(e.target.value);
                  // Reset day if it's greater than days in new month
                  const daysInNewMonth = new Date(
                    parseInt(achievementYear),
                    months.indexOf(e.target.value) + 1,
                    0
                  ).getDate();
                  if (parseInt(achievementDay) > daysInNewMonth) {
                    setAchievementDay('1');
                  }
                }}
                className="w-1/3 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              >
                {months.map(month => (
                  <option key={month} value={month}>{month}</option>
                ))}
              </select>

              {/* Day Selection */}
              <select
                value={achievementDay}
                onChange={(e) => setAchievementDay(e.target.value)}
                className="w-1/3 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              >
                {days.map(day => (
                  <option key={day} value={day}>{day}</option>
                ))}
              </select>

              {/* Year Selection */}
              <select
                value={achievementYear}
                onChange={(e) => setAchievementYear(e.target.value)}
                className="w-1/3 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              >
                {years.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Convert to Milestone Option */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="convertToMilestone"
              checked={convertToMilestone}
              onChange={(e) => setConvertToMilestone(e.target.checked)}
              className="w-4 h-4 text-orange-500 border-gray-300 rounded focus:ring-orange-500"
            />
            <label htmlFor="convertToMilestone" className="text-sm text-gray-700">
              Convert to a milestone?
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => setIsAchieveModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmAchievement}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600"
            >
              Mark as Achieved
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}