import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { SortableGoalCard } from './SortableGoalCard';
import { useGoals } from '../../contexts/GoalsContext';
import type { CreateGoalModalState } from '../../pages/PlanningPage';
import { EditGoalModal } from './EditGoalModal';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from '@dnd-kit/sortable';

interface HomeGoalsSectionProps {
  createGoalModal: CreateGoalModalState;
  onCreateGoalModalClose: () => void;
}

export function HomeGoalsSection({ createGoalModal, onCreateGoalModalClose }: HomeGoalsSectionProps) {
  const { goals, addGoal, updateGoal, deleteGoal, reorderGoals } = useGoals();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTargetDate, setNewGoalTargetDate] = useState('');
  const [removingGoalIds, setRemovingGoalIds] = useState<string[]>([]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Filter out achieved goals and sort by order
  const visibleGoals = goals
    .filter(goal => !goal.achieved)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = visibleGoals.findIndex(goal => goal.id === active.id);
      const newIndex = visibleGoals.findIndex(goal => goal.id === over.id);

      const reorderedGoals = [...goals];
      const movedGoals = arrayMove(visibleGoals, oldIndex, newIndex);
      
      // Update order of all goals
      movedGoals.forEach((goal, index) => {
        const goalIndex = reorderedGoals.findIndex(g => g.id === goal.id);
        if (goalIndex !== -1) {
          reorderedGoals[goalIndex] = { ...goal, order: index };
        }
      });

      reorderGoals(reorderedGoals);
    }
  };

  const resetFormState = () => {
    setNewGoalName('');
    setNewGoalTargetDate('');
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalName.trim()) return;

    const goalId = addGoal({
      name: newGoalName.trim(),
      targetDate: newGoalTargetDate.trim() || undefined,
    });
    
    // If this was triggered from the task/habit modal, call the callback
    if (createGoalModal.onGoalCreated) {
      createGoalModal.onGoalCreated(goalId);
    }
    
    // Close the appropriate modal
    if (createGoalModal.isOpen) {
      onCreateGoalModalClose();
    } else {
      setIsCreateModalOpen(false);
    }
    
    resetFormState();
  };

  return (
    <section className="flex-1">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">Goals</span>
          <span className="font-light text-gray-500 italic ml-2 tracking-wide">- what you're going to do</span>
        </h2>
        <button
          onClick={() => {
            resetFormState();
            setIsCreateModalOpen(true);
          }}
          className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
          aria-label="Create new goal"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={visibleGoals.map(goal => goal.id)}
          strategy={rectSortingStrategy}
        >
          <div className="grid grid-cols-2 gap-4">
            {visibleGoals.map(goal => (
              <SortableGoalCard
                key={goal.id}
                id={goal.id}
                goal={goal}
                onClick={() => setEditingGoalId(goal.id)}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {/* Create Goal Modal */}
      <Modal
        isOpen={isCreateModalOpen || createGoalModal.isOpen}
        onClose={() => {
          if (createGoalModal.isOpen) {
            onCreateGoalModalClose();
          } else {
            setIsCreateModalOpen(false);
          }
          resetFormState();
        }}
        title="Create Goal"
        isNested={createGoalModal.isOpen}
      >
        <form onSubmit={handleCreateGoal}>
          <div className="space-y-4">
            {/* Goal Name Input */}
            <div>
              <label htmlFor="goalName" className="block text-sm font-medium text-gray-700 mb-1">
                Goal Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="goalName"
                value={newGoalName}
                onChange={(e) => setNewGoalName(e.target.value)}
                placeholder="Enter goal name"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                autoFocus
                required
              />
            </div>

            {/* Target Date Input */}
            <div>
              <label htmlFor="targetDate" className="block text-sm font-medium text-gray-700 mb-1">
                Target Date
              </label>
              <input
                type="text"
                id="targetDate"
                value={newGoalTargetDate}
                onChange={(e) => setNewGoalTargetDate(e.target.value)}
                placeholder="e.g., End of 2024, Next month..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              type="button"
              onClick={() => {
                if (createGoalModal.isOpen) {
                  onCreateGoalModalClose();
                } else {
                  setIsCreateModalOpen(false);
                }
                resetFormState();
              }}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!newGoalName.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Goal Modal */}
      {editingGoalId && (
        <EditGoalModal
          isOpen={true}
          onClose={() => setEditingGoalId(null)}
          goalId={editingGoalId}
        />
      )}
    </section>
  );
}