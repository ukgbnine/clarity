import React from 'react';
import { Trophy, Calendar } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useCompletionAnimationStore } from '../../features/task-logging/stores/completionAnimationStore';

interface GoalCardProps {
  goal: {
    id: string;
    name: string;
    targetDate?: string;
    achievementDate?: string;
    achieved?: boolean;
  };
  onClick: () => void;
  icon?: LucideIcon;
}

export function GoalCard({ goal, onClick, icon: Icon }: GoalCardProps) {
  const { getGoalAnimation, cancelGoalAnimation } = useCompletionAnimationStore();
  const animation = getGoalAnimation(goal.id);

  const handleCancelClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (goal.id) {
      cancelGoalAnimation(goal.id);
    }
  };

  return (
    <div 
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      className={`w-full rounded-lg shadow-sm text-left transition-all relative group border-l-4 border-l-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 ${
        goal.achieved 
          ? 'bg-orange-500 border border-orange-500 scale-[1.02] transform'
          : 'bg-white border border-gray-200 hover:border-gray-300'
      } ${animation ? 'animate-completion' : ''}`}
    >
      <div className={`p-4 ${goal.achieved ? 'relative' : 'flex items-center gap-4'}`}>
        {goal.achieved ? (
          <>
            <Trophy className="w-6 h-6 text-white absolute left-4 top-1/2 -translate-y-1/2" />
            <div className="text-center px-6">
              <span className="text-xl font-medium text-white">
                {goal.name}
              </span>
            </div>
          </>
        ) : (
          <>
            {Icon && (
              <Icon className="w-5 h-5 flex-shrink-0 text-gray-900" />
            )}
            <div className="flex-1">
              <span className="text-xl font-medium text-gray-900 group-hover:text-orange-600 transition-colors">
                {goal.name}
              </span>
              {goal.targetDate && (
                <div className="flex items-center gap-2 mt-2 text-gray-600">
                  <Calendar className="w-4 h-4 flex-shrink-0" />
                  <span className="text-sm">{goal.targetDate}</span>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Progress Bar Section */}
      {animation && (
        <div className="mt-2 pb-6 relative">
          <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden mx-4">
            <div 
              className="h-full bg-orange-500 transition-all duration-100 ease-linear rounded-full"
              style={{ width: `${animation.progress * 100}%` }}
            />
          </div>
          <button
            onClick={handleCancelClick}
            className="cancel-button absolute left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 text-xs font-medium text-gray-600 hover:text-gray-900 transition-colors"
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
}