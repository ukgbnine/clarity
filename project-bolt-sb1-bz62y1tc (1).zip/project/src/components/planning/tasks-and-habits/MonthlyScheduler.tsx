import React from 'react';
import { TaskCard } from './TaskCard';
import { useTasks } from '../../../contexts/TasksContext';
import { Calendar } from 'lucide-react';
import { MonthlyWeekdayScheduler } from './MonthlyWeekdayScheduler';

interface MonthlySchedulerProps {
  selectedDates: number[];
  onDateToggle: (date: number) => void;
  selectedWeekdays: string[];
  onWeekdayToggle: (weekday: string) => void;
}

function getOrdinalSuffix(n: number): string {
  if (n > 3 && n < 21) return 'th';
  switch (n % 10) {
    case 1: return 'st';
    case 2: return 'nd';
    case 3: return 'rd';
    default: return 'th';
  }
}

export function MonthlyScheduler({ 
  selectedDates, 
  onDateToggle,
  selectedWeekdays,
  onWeekdayToggle
}: MonthlySchedulerProps) {
  const { tasks } = useTasks();
  // Start from 2 since we handle 1st day separately
  const dates = Array.from({ length: 30 }, (_, i) => i + 2);

  // Group dates into rows of 7 for better visual layout
  const dateRows = dates.reduce<number[][]>((rows, date) => {
    if (rows[rows.length - 1]?.length === 7) {
      rows.push([date]);
    } else {
      if (rows.length === 0) rows.push([]);
      rows[rows.length - 1].push(date);
    }
    return rows;
  }, []);

  const handleDateClick = (date: number) => {
    // If clicking on 29-31, show warning and suggest last day option
    if (date >= 29) {
      const shouldUseLastDay = window.confirm(
        `Scheduling a habit on the ${date}${getOrdinalSuffix(date)} may cause inconsistencies as not all months have this date.\n\n` +
        `Would you like to schedule this habit for the last day of each month instead?`
      );

      if (shouldUseLastDay) {
        // Use 32 as a special number to indicate "last day of month"
        onDateToggle(32);
        return;
      }
    }
    
    onDateToggle(date);
  };

  return (
    <div className="space-y-4">
      {/* First Day of Month Option */}
      <div
        onClick={() => onDateToggle(1)}
        className={`w-full px-4 py-3 text-left border rounded-lg transition-colors cursor-pointer ${
          selectedDates.includes(1)
            ? 'border-orange-500 bg-orange-50 hover:bg-orange-100'
            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
        }`}
      >
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-gray-600" />
          <div>
            <div className="font-medium text-gray-900">First day of each month</div>
            <div className="text-sm text-gray-500">
              Always occurs on the 1st day of every month
            </div>
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="border border-gray-200 rounded-lg bg-white overflow-hidden">
        <div className="grid gap-px bg-gray-200">
          {dateRows.map((row, rowIndex) => (
            <div key={rowIndex} className="grid grid-cols-7 divide-x divide-gray-200 bg-white">
              {row.map((date, colIndex) => {
                const dateTasks = tasks.filter(task => 
                  task.type === 'habit' && 
                  task.frequency === 'monthly' &&
                  task.dates.some(taskDate => taskDate.getDate() === date)
                );

                const isHighRiskDate = date >= 29;
                const isLastInRow = colIndex === row.length - 1;

                return (
                  <div
                    key={date}
                    onClick={() => handleDateClick(date)}
                    className={`text-left transition-colors relative cursor-pointer ${
                      selectedDates.includes(date)
                        ? 'bg-orange-50 hover:bg-orange-100'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    {isLastInRow && (
                      <div className="absolute top-0 right-0 bottom-0 w-px bg-gray-200" />
                    )}
                    <div className={`sticky top-0 z-10 px-4 py-3 text-center border-b border-gray-200 bg-inherit ${
                      selectedDates.includes(date) ? 'text-orange-600' : ''
                    }`}>
                      <div className={`text-sm font-medium ${isHighRiskDate ? 'text-amber-600' : ''}`}>
                        {date}<sup>{getOrdinalSuffix(date)}</sup>
                        {isHighRiskDate && (
                          <div className="text-xs text-amber-600">
                            ⚠️ Not all months
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="p-2 space-y-2 min-h-[80px]">
                      {dateTasks.map(task => (
                        <TaskCard
                          key={task.id}
                          name={task.name}
                          onClick={(e) => {
                            e.stopPropagation(); // Prevent date selection when clicking a task
                          }}
                          isInteractive={false}
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Last Day of Month Option */}
      <div
        onClick={() => onDateToggle(32)} // Use 32 as special number for last day
        className={`w-full px-4 py-3 text-left border rounded-lg transition-colors cursor-pointer ${
          selectedDates.includes(32)
            ? 'border-orange-500 bg-orange-50 hover:bg-orange-100'
            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
        }`}
      >
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-gray-600" />
          <div>
            <div className="font-medium text-gray-900">Last day of each month</div>
            <div className="text-sm text-gray-500">
              Automatically adjusts to the last day (28th-31st depending on month)
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Weekday Scheduler */}
      <MonthlyWeekdayScheduler
        selectedWeekdays={selectedWeekdays}
        onWeekdayToggle={onWeekdayToggle}
      />
    </div>
  );
}