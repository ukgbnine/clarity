import React from 'react';
import { TaskCard } from './TaskCard';
import { useTasks } from '../../../contexts/TasksContext';

interface HabitSchedulerProps {
  selectedDays: number[];
  onDayToggle: (day: number) => void;
  editingTaskId?: string;
}

export function HabitScheduler({ selectedDays, onDayToggle, editingTaskId }: HabitSchedulerProps) {
  const { tasks } = useTasks();
  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  // Only show other habits' patterns if we're not editing a task
  const otherHabits = editingTaskId 
    ? tasks.filter(task => 
        task.type === 'habit' && 
        task.id !== editingTaskId && 
        (task.frequency === 'daily' || task.frequency === 'weekly')
      )
    : tasks.filter(task => 
        task.type === 'habit' && 
        (task.frequency === 'daily' || task.frequency === 'weekly')
      );

  return (
    <div className="grid grid-cols-7 divide-x divide-gray-200 border border-gray-200 rounded-lg bg-white">
      {dayNames.map((day, index) => {
        // Get habits that occur on this day
        const dayHabits = otherHabits.filter(task => {
          if (task.frequency === 'daily') return true;
          
          // For weekly habits, check if any dates fall on this day
          return task.dates.some(date => {
            const dayOfWeek = date.getDay();
            const normalizedDay = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
            return normalizedDay === index;
          });
        });

        return (
          <div
            key={day}
            onClick={() => onDayToggle(index)}
            className={`text-left transition-colors cursor-pointer ${
              selectedDays.includes(index)
                ? 'bg-orange-50 hover:bg-orange-100'
                : 'hover:bg-gray-50'
            }`}
          >
            <div className={`sticky top-0 z-10 px-4 py-3 text-center border-b border-gray-200 bg-inherit ${
              selectedDays.includes(index) ? 'text-orange-600' : ''
            }`}>
              <div className="text-sm font-medium">{day}</div>
            </div>
            <div className="p-2 space-y-2 min-h-[80px]">
              {dayHabits.map(task => (
                <TaskCard
                  key={task.id}
                  name={task.name}
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent day selection when clicking a task
                  }}
                  isInteractive={false}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}