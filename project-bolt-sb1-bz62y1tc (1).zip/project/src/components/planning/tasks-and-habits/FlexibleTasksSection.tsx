import React from 'react';
import { useTasks } from '../../../contexts/TasksContext';
import { useGoals } from '../../../contexts/GoalsContext';
import { useTaskLogStore } from '../../../features/task-logging/stores/taskLogStore';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { SortableTaskCard } from './SortableTaskCard';

interface FlexibleTasksSectionProps {
  onTaskClick: (taskId: string) => void;
}

export function FlexibleTasksSection({ onTaskClick }: FlexibleTasksSectionProps) {
  const { tasks, reorderTasks } = useTasks();
  const { goals } = useGoals();
  const logs = useTaskLogStore(state => state.logs);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Get all completed task IDs
  const completedTaskIds = tasks
    .filter(task => task.type === 'flexible')
    .filter(task => 
      logs.some(log => 
        log.taskId === task.id && 
        log.status === 'completed'
      )
    )
    .map(task => task.id);

  // Filter out completed tasks from the flexible tasks list
  const flexibleTasks = tasks
    .filter(task => task.type === 'flexible')
    .filter(task => !completedTaskIds.includes(task.id))
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = flexibleTasks.findIndex(task => task.id === active.id);
      const newIndex = flexibleTasks.findIndex(task => task.id === over.id);

      const reorderedTasks = [...tasks];
      const movedTasks = arrayMove(flexibleTasks, oldIndex, newIndex);
      
      movedTasks.forEach((task, index) => {
        const taskIndex = reorderedTasks.findIndex(t => t.id === task.id);
        if (taskIndex !== -1) {
          reorderedTasks[taskIndex] = { ...task, order: index };
        }
      });

      reorderTasks(reorderedTasks);
    }
  };

  if (flexibleTasks.length === 0) {
    return null;
  }

  return (
    <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Title Bar */}
      <div className="px-8 py-4 border-b border-gray-200">
        <h3 className="text-base font-medium text-gray-900 text-center">
          Flexible Scheduling
        </h3>
      </div>

      {/* Tasks Grid */}
      <div className="p-4">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={flexibleTasks.map(task => task.id)}
            strategy={rectSortingStrategy}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {flexibleTasks.map(task => {
                const goal = goals.find(g => g.id === task.goalId);
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                return (
                  <SortableTaskCard
                    key={task.id}
                    id={task.id}
                    taskId={task.id}
                    name={task.name}
                    goalName={goal?.name}
                    goalId={goal?.id}
                    timeframe={task.timeframe}
                    onClick={() => onTaskClick(task.id)}
                    date={today}
                  />
                );
              })}
            </div>
          </SortableContext>
        </DndContext>
      </div>
    </div>
  );
}