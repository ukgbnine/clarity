import React from 'react';
import { formatDayName, formatDayNumber } from '../../../utils/dateUtils';
import { useTasks } from '../../../contexts/TasksContext';
import { useGoals } from '../../../contexts/GoalsContext';
import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { SortableTaskCard } from './SortableTaskCard';

interface WeeklyViewDayProps {
  date: Date;
  selectable?: boolean;
  selected?: boolean;
  onSelect?: (date: Date) => void;
  onTaskClick?: (taskId: string) => void;
  activeId?: string | null;
  activeDate?: Date | null;
}

export function WeeklyViewDay({ 
  date,
  selectable = false,
  selected = false,
  onSelect,
  onTaskClick,
  activeId,
  activeDate,
}: WeeklyViewDayProps) {
  const { tasks } = useTasks();
  const { goals } = useGoals();
  const isToday = new Date().toDateString() === date.toDateString();

  const { setNodeRef, isOver } = useDroppable({
    id: date.toISOString(),
    data: {
      date,
      type: 'day'
    }
  });

  const handleClick = () => {
    if (selectable && onSelect) {
      onSelect(date);
    }
  };

  const dayTasks = tasks
    .filter(task => task.dates.some(taskDate => 
      taskDate.toDateString() === date.toDateString()
    ))
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  return (
    <div 
      ref={setNodeRef}
      onClick={handleClick}
      className={`relative text-left transition-colors min-h-[200px] ${
        selectable ? 'cursor-pointer hover:bg-gray-50' : ''
      } ${selected ? 'bg-orange-50' : ''} ${
        isOver ? 'bg-orange-50/50' : ''
      }`}
    >
      {isToday && (
        <div className="absolute top-0 left-0 right-0 h-0.5 bg-orange-500" />
      )}
      <div className="sticky top-0 z-20 px-4 py-3 text-center border-b border-gray-200 bg-inherit">
        <div className="text-sm font-medium text-gray-900">
          {formatDayName(date)}
        </div>
        <div className="text-sm font-medium text-gray-900">
          {formatDayNumber(date)}
        </div>
      </div>
      <div className="p-2">
        <SortableContext
          items={dayTasks.map(task => task.id)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-2">
            {dayTasks.map(task => {
              const goal = goals.find(g => g.id === task.goalId);
              const isDragging = activeId === task.id && activeDate?.toDateString() === date.toDateString();

              return (
                <SortableTaskCard
                  key={task.id}
                  id={task.id}
                  taskId={task.id}
                  name={task.name}
                  goalName={goal?.name}
                  goalId={goal?.id}
                  reminder={task.reminder}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onTaskClick) {
                      onTaskClick(task.id);
                    }
                  }}
                  date={date}
                  isDragging={isDragging}
                />
              );
            })}
          </div>
        </SortableContext>
      </div>
    </div>
  );
}