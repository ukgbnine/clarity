import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { TaskCard } from './TaskCard';

interface SortableTaskCardProps {
  id: string;
  taskId: string;
  name: string;
  goalName?: string;
  goalId?: string;
  reminder?: string;
  timeframe?: string;
  onClick: (e: React.MouseEvent) => void;
  showCheckbox?: boolean;
  isCheckboxDisabled?: boolean;
  date?: Date;
  isDragging?: boolean;
}

export function SortableTaskCard({
  id,
  taskId,
  name,
  goalName,
  goalId,
  reminder,
  timeframe,
  onClick,
  showCheckbox,
  isCheckboxDisabled,
  date,
  isDragging,
}: SortableTaskCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({
    id: id,
    data: {
      taskId,
      date,
    },
  });

  const style = transform ? {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : undefined,
    zIndex: isDragging ? 1 : undefined,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      className="touch-none"
    >
      <TaskCard 
        taskId={taskId}
        name={name}
        goalName={goalName}
        goalId={goalId}
        reminder={reminder}
        timeframe={timeframe}
        onClick={onClick}
        dragHandleProps={listeners}
        showCheckbox={showCheckbox}
        isCheckboxDisabled={isCheckboxDisabled}
        date={date}
      />
    </div>
  );
}