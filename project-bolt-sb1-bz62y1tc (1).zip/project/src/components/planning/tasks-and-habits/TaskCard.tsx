import React, { useState, useEffect, useRef } from 'react';
import { Clock, ArrowRight, Calendar, GripVertical } from 'lucide-react';
import { useTaskLogStore } from '../../../features/task-logging/stores/taskLogStore';
import { useCompletionAnimationStore } from '../../../features/task-logging/stores/completionAnimationStore';
import { useConfirmationStore } from '../../../features/task-logging/stores/confirmationStore';
import { ConfirmationModal } from '../../ui/ConfirmationModal';
import { useSoundStore } from '../../../features/task-logging/stores/soundStore';
import { useCompletedTasksStore } from '../../../features/task-logging/stores/completedTasksStore';
import type { LucideIcon } from 'lucide-react';

interface TaskCardProps {
  name: string;
  taskId?: string;
  goalName?: string;
  goalId?: string;
  reminder?: string;
  timeframe?: string;
  onClick: (e: React.MouseEvent) => void;
  dragHandleProps?: React.HTMLAttributes<HTMLDivElement>;
  isInteractive?: boolean;
  showCheckbox?: boolean;
  isCheckboxDisabled?: boolean;
  date?: Date;
  icon?: LucideIcon;
}

export function TaskCard({ 
  name, 
  taskId,
  goalName,
  goalId,
  reminder, 
  timeframe, 
  onClick,
  dragHandleProps,
  isInteractive = true,
  showCheckbox = false,
  isCheckboxDisabled = false,
  date,
  icon: Icon,
}: TaskCardProps) {
  const { addLog } = useTaskLogStore();
  const { startAnimation, cancelAnimation, getAnimation } = useCompletionAnimationStore();
  const { showTaskCompletionConfirmation, setShowTaskCompletionConfirmation } = useConfirmationStore();
  const { initializeCompletionSound, playCompletionSound } = useSoundStore();
  const { addCompletedTask, isTaskCompleted } = useCompletedTasksStore();
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isAnimatingCompletion, setIsAnimatingCompletion] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const completionTimeoutRef = useRef<number>();
  const dbUpdateTimeoutRef = useRef<number>();

  // Initialize sound on component mount
  useEffect(() => {
    initializeCompletionSound();
  }, [initializeCompletionSound]);

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (completionTimeoutRef.current) {
        clearTimeout(completionTimeoutRef.current);
      }
      if (dbUpdateTimeoutRef.current) {
        clearTimeout(dbUpdateTimeoutRef.current);
      }
    };
  }, []);

  const dateString = date?.toISOString().split('T')[0] || '';
  const animation = taskId && date ? getAnimation(taskId, dateString) : undefined;

  // Set initial completion state
  useEffect(() => {
    if (date && taskId) {
      const taskCompleted = isTaskCompleted(taskId, dateString);
      setIsCompleted(taskCompleted);
      setIsAnimatingCompletion(false);
    }
  }, [date, taskId, dateString, isTaskCompleted]);

  // Component type based on interaction mode
  const Component = showCheckbox ? 'div' : (isInteractive ? 'button' : 'div');

  const handleClick = (e: React.MouseEvent) => {
    // Only trigger onClick if we're not clicking the checkbox or cancel button
    if (!showCheckbox || 
        ((e.target as HTMLElement).closest('.checkbox-area') === null &&
         (e.target as HTMLElement).closest('.cancel-button') === null)) {
      onClick(e);
    }
  };

  const startTaskCompletion = async () => {
    if (!taskId || !date || animation) return;

    try {
      setError(null);
      setIsAnimatingCompletion(true);

      // Start animation immediately
      startAnimation(taskId, goalId, dateString);
      
      // Clear any existing timeouts
      if (completionTimeoutRef.current) {
        clearTimeout(completionTimeoutRef.current);
      }
      if (dbUpdateTimeoutRef.current) {
        clearTimeout(dbUpdateTimeoutRef.current);
      }

      // Set a timeout to update the database halfway through the animation
      dbUpdateTimeoutRef.current = window.setTimeout(async () => {
        try {
          await addLog({
            task_id: taskId,
            user_id: '', // Will be set by the store
            date: dateString,
            status: 'completed',
            metadata: {} // Always provide an empty object for metadata
          });

          // Add to completed tasks store
          addCompletedTask(taskId, dateString);
        } catch (error) {
          setError(error instanceof Error ? error.message : 'An error occurred');
          setIsAnimatingCompletion(false);
          if (taskId && dateString) {
            cancelAnimation(taskId, dateString);
          }
        }
      }, 2000); // Update database halfway through animation

      // Set a timeout to play the sound and update state when animation completes
      completionTimeoutRef.current = window.setTimeout(() => {
        playCompletionSound();
        setIsCompleted(true);
        setIsAnimatingCompletion(false);
      }, 4000); // Complete animation after 4 seconds
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
      setIsAnimatingCompletion(false);
      if (taskId && dateString) {
        cancelAnimation(taskId, dateString);
      }
    }
  };

  const handleCheckboxClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isCheckboxDisabled && taskId && date && !animation && !isCompleted) {
      if (showTaskCompletionConfirmation) {
        setIsConfirmationOpen(true);
      } else {
        startTaskCompletion();
      }
    }
  };

  const handleCancelClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (taskId && date) {
      // Clear any existing timeouts
      if (completionTimeoutRef.current) {
        clearTimeout(completionTimeoutRef.current);
      }
      if (dbUpdateTimeoutRef.current) {
        clearTimeout(dbUpdateTimeoutRef.current);
      }
      setIsAnimatingCompletion(false);
      cancelAnimation(taskId, dateString);
    }
  };

  return (
    <>
      <Component
        onClick={handleClick}
        className={`relative w-full rounded-lg shadow-sm text-left group ${
          isCompleted 
            ? 'bg-orange-500 border-2 border-orange-500 scale-[1.02] transform'
            : 'bg-white border border-gray-200 hover:border-gray-300 border-l-4 border-l-orange-500'
        } ${showCheckbox && !isCompleted ? 'cursor-pointer' : ''} ${
          isAnimatingCompletion ? 'animate-completion' : ''
        }`}
      >
        <div className="flex items-center p-2">
          {Icon && (
            <Icon className={`w-5 h-5 mr-3 flex-shrink-0 ${
              isCompleted ? 'text-white' : 'text-gray-900'
            }`} />
          )}
          <div className="flex-1 min-w-0 pr-2">
            <h4 className={`font-medium transition-colors line-clamp-2 ${
              isCompleted 
                ? 'text-white text-sm'
                : 'text-sm text-gray-900 group-hover:text-orange-600'
            }`}>
              {name}
            </h4>
            {goalName && (
              <div className={`flex items-start gap-1.5 mt-1 ${
                isCompleted
                  ? 'text-white/90 text-xs'
                  : 'text-xs text-gray-600'
              }`}>
                <ArrowRight className={`w-3 h-3 flex-shrink-0 mt-0.5 ${
                  isCompleted ? 'text-white/90' : 'text-gray-600'
                }`} />
                <span className="line-clamp-1">{goalName}</span>
              </div>
            )}
            {timeframe && (
              <div className={`flex items-center gap-1.5 mt-1 ${
                isCompleted
                  ? 'text-white/90 text-xs'
                  : 'text-xs text-gray-600'
              }`}>
                <Calendar className={`w-3 h-3 flex-shrink-0 ${
                  isCompleted ? 'text-white/90' : 'text-gray-600'
                }`} />
                <span className="truncate">{timeframe}</span>
              </div>
            )}
            {reminder && (
              <div className={`flex items-center gap-1.5 mt-1 ${
                isCompleted
                  ? 'text-white/90 text-xs'
                  : 'text-xs text-gray-600'
              }`}>
                <Clock className={`w-3 h-3 flex-shrink-0 ${
                  isCompleted ? 'text-white/90' : 'text-gray-600'
                }`} />
                <span className="truncate">{reminder}</span>
              </div>
            )}
          </div>
          {dragHandleProps && (
            <div
              {...dragHandleProps}
              className="opacity-0 group-hover:opacity-100 transition-opacity cursor-grab active:cursor-grabbing"
              onClick={(e) => e.stopPropagation()}
            >
              <div className={`p-1 rounded-md ${
                isCompleted
                  ? 'hover:bg-white/10'
                  : 'hover:bg-gray-100'
              }`}>
                <GripVertical className={`w-5 h-5 ${
                  isCompleted ? 'text-white/70' : 'text-gray-300'
                }`} />
              </div>
            </div>
          )}
          {showCheckbox && (
            <div
              onClick={handleCheckboxClick}
              className={`checkbox-area ml-2 w-5 h-5 border-2 rounded-md flex items-center justify-center transition-colors ${
                isCompleted
                  ? 'bg-white border-white cursor-default'
                  : 'border-gray-300 hover:border-orange-500 cursor-pointer'
              } ${
                isCheckboxDisabled || isCompleted
                  ? 'opacity-50 cursor-not-allowed'
                  : ''
              }`}
            >
              {isCompleted && (
                <svg
                  className="w-3 h-3 text-orange-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              )}
            </div>
          )}
        </div>

        {/* Progress Bar and Cancel Button */}
        {animation && (
          <div className="mt-2 pb-6 relative">
            <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden mx-2">
              <div 
                className="h-full bg-orange-500 transition-all duration-100 ease-linear rounded-full"
                style={{ width: `${animation.progress * 100}%` }}
              />
            </div>
            <button
              onClick={handleCancelClick}
              className="cancel-button absolute left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 text-xs font-medium text-gray-600 hover:text-gray-900 transition-colors"
            >
              Cancel
            </button>
          </div>
        )}

        {error && (
          <div className="px-4 py-2 text-sm text-red-600">
            {error}
          </div>
        )}
      </Component>

      <ConfirmationModal
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        onConfirm={() => {
          startTaskCompletion();
          setIsConfirmationOpen(false);
        }}
        title="Complete Task"
        message="This action will mark the task as completed and cannot be undone. Are you sure you want to proceed?"
        showDoNotAskAgain={true}
        onDoNotAskAgainChange={(checked) => {
          setShowTaskCompletionConfirmation(false);
          startTaskCompletion();
          setIsConfirmationOpen(false);
        }}
      />
    </>
  );
}