import React, { useState, useEffect } from 'react';
import { useTasks } from '../../../contexts/TasksContext';
import { useGoals } from '../../../contexts/GoalsContext';
import { useTaskLogStore } from '../../../features/task-logging/stores/taskLogStore';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { SortableTaskCard } from './SortableTaskCard';

interface HomeFlexibleTasksSectionProps {
  onTaskClick: (taskId: string) => void;
}

export function HomeFlexibleTasksSection({ onTaskClick }: HomeFlexibleTasksSectionProps) {
  const { tasks, reorderTasks } = useTasks();
  const { goals } = useGoals();
  const logs = useTaskLogStore(state => state.logs);
  const [removingTaskIds, setRemovingTaskIds] = useState<string[]>([]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split('T')[0];

  // Get all completed task IDs
  const completedTaskIds = tasks
    .filter(task => task.type === 'flexible')
    .filter(task => 
      logs.some(log => 
        log.taskId === task.id && 
        log.status === 'completed'
      )
    )
    .map(task => task.id);

  // Filter out completed tasks from the flexible tasks list
  const flexibleTasks = tasks
    .filter(task => task.type === 'flexible')
    .filter(task => !completedTaskIds.includes(task.id))
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  // Handle task removal animation
  useEffect(() => {
    const newCompletedTasks = completedTaskIds.filter(id => !removingTaskIds.includes(id));
    
    newCompletedTasks.forEach(taskId => {
      // Wait 2 seconds before starting the removal animation
      const timeout = setTimeout(() => {
        setRemovingTaskIds(prev => [...prev, taskId]);
      }, 2000);

      return () => clearTimeout(timeout);
    });
  }, [completedTaskIds, removingTaskIds]);

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = flexibleTasks.findIndex(task => task.id === active.id);
      const newIndex = flexibleTasks.findIndex(task => task.id === over.id);

      const reorderedTasks = [...tasks];
      const movedTasks = arrayMove(flexibleTasks, oldIndex, newIndex);
      
      movedTasks.forEach((task, index) => {
        const taskIndex = reorderedTasks.findIndex(t => t.id === task.id);
        if (taskIndex !== -1) {
          reorderedTasks[taskIndex] = { ...task, order: index };
        }
      });

      reorderTasks(reorderedTasks);
    }
  };

  if (flexibleTasks.length === 0) {
    return null;
  }

  const visibleTasks = flexibleTasks.filter(task => !removingTaskIds.includes(task.id));

  return (
    <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Title Bar */}
      <div className="px-8 py-4 border-b border-gray-200">
        <h3 className="text-base font-medium text-gray-900 text-center">
          Flexible Scheduling
        </h3>
      </div>

      {/* Tasks Grid */}
      <div className="p-4">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={visibleTasks.map(task => task.id)}
            strategy={rectSortingStrategy}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {visibleTasks.map(task => {
                const goal = goals.find(g => g.id === task.goalId);
                const isRemoving = removingTaskIds.includes(task.id);

                return (
                  <div
                    key={task.id}
                    className={`transition-all duration-500 ${
                      isRemoving ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
                    }`}
                  >
                    <SortableTaskCard
                      id={task.id}
                      taskId={task.id}
                      name={task.name}
                      goalName={goal?.name}
                      goalId={goal?.id}
                      timeframe={task.timeframe}
                      onClick={() => onTaskClick(task.id)}
                      showCheckbox={true}
                      date={today}
                    />
                  </div>
                );
              })}
            </div>
          </SortableContext>
        </DndContext>
      </div>
    </div>
  );
}