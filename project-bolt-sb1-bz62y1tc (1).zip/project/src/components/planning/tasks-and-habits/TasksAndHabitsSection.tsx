import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { WeeklyView } from './WeeklyView';
import { FlexibleTasksSection } from './FlexibleTasksSection';
import { CreateTaskHabitModal } from './CreateTaskHabitModal';
import { EditTaskModal } from './EditTaskModal';
import type { CreateGoalModalState } from '../../../pages/PlanningPage';

interface TasksAndHabitsSectionProps {
  setCreateGoalModal: React.Dispatch<React.SetStateAction<CreateGoalModalState>>;
}

export function TasksAndHabitsSection({ setCreateGoalModal }: TasksAndHabitsSectionProps) {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

  return (
    <section className="flex-1">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl">
          <span className="font-medium text-gray-900">Tasks & Habits</span>
          <span className="font-light text-gray-500 italic ml-2 tracking-wide">- how you're going to do it</span>
        </h2>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="p-2 text-gray-600 hover:text-gray-900 bg-white hover:bg-gray-100 rounded-full transition-colors shadow-sm border border-gray-200 hover:border-gray-300 active:scale-95"
          aria-label="Create new task or habit"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <WeeklyView onTaskClick={setEditingTaskId} />
      <FlexibleTasksSection onTaskClick={setEditingTaskId} />

      <CreateTaskHabitModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        setCreateGoalModal={setCreateGoalModal}
      />

      {editingTaskId && (
        <EditTaskModal
          isOpen={true}
          onClose={() => setEditingTaskId(null)}
          taskId={editingTaskId}
          setCreateGoalModal={setCreateGoalModal}
        />
      )}
    </section>
  );
}