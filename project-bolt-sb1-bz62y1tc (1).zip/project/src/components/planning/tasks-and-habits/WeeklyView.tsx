import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { WeeklyViewDay } from './WeeklyViewDay';
import { getWeekDays, formatDateRange } from '../../../utils/dateUtils';
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragStartEvent,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  closestCenter,
} from '@dnd-kit/core';
import { useTasks } from '../../../contexts/TasksContext';

interface WeeklyViewProps {
  selectable?: boolean;
  selectedDates?: Date[];
  onDateSelect?: (date: Date) => void;
  onTaskClick?: (taskId: string) => void;
}

export function WeeklyView({ 
  selectable = false,
  selectedDates = [],
  onDateSelect,
  onTaskClick
}: WeeklyViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const weekDays = getWeekDays(currentDate);
  const { tasks, updateTask } = useTasks();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeDate, setActiveDate] = useState<Date | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor)
  );

  const navigateWeek = (direction: 'prev' | 'next') => {
    setCurrentDate(prevDate => {
      const newDate = new Date(prevDate);
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
      return newDate;
    });
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const task = tasks.find(t => t.id === active.id);
    if (!task) return;

    const date = active.data.current?.date as Date;
    if (!date) return;

    setActiveId(task.id);
    setActiveDate(date);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over || !active) return;

    const task = tasks.find(t => t.id === active.id);
    if (!task || !activeDate) return;

    // Only handle drops over days
    if (over.data.current?.type !== 'day') return;

    const newDate = over.data.current?.date as Date;
    if (!newDate) return;

    // Don't allow moving tasks to past dates
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (newDate < today) return;

    // Update the task's dates
    const updatedDates = task.dates.map(date => 
      date.toDateString() === activeDate.toDateString() ? newDate : date
    );

    updateTask(task.id, { dates: updatedDates });
  };

  const handleDragEnd = () => {
    setActiveId(null);
    setActiveDate(null);
  };

  const handleDateSelect = (date: Date) => {
    if (!onDateSelect) return;

    // Don't allow selecting past dates
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (date < today) return;

    onDateSelect(date);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Weekly Navigation */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-gray-200">
        <button
          onClick={() => navigateWeek('prev')}
          className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
          aria-label="Previous week"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <h3 className="text-base font-medium text-gray-900">
          {formatDateRange(weekDays[0], weekDays[6])}
        </h3>

        <button
          onClick={() => navigateWeek('next')}
          className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
          aria-label="Next week"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Weekly Grid */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-7 divide-x divide-gray-200">
          {weekDays.map((date) => (
            <WeeklyViewDay 
              key={date.toISOString()} 
              date={date}
              selectable={selectable}
              selected={selectedDates?.some(
                selectedDate => selectedDate.toDateString() === date.toDateString()
              )}
              onSelect={handleDateSelect}
              onTaskClick={onTaskClick}
              activeId={activeId}
              activeDate={activeDate}
            />
          ))}
        </div>
      </DndContext>
    </div>
  );
}