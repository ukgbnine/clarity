import React from 'react';
import { Calendar } from 'lucide-react';
import { TaskCard } from './TaskCard';
import { useTasks } from '../../../contexts/TasksContext';

interface MonthlyWeekdaySchedulerProps {
  selectedWeekdays: string[];
  onWeekdayToggle: (weekday: string) => void;
}

const weekPositions = ['First', 'Second', 'Third', 'Fourth', 'Last'] as const;
const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;

const weekdayToNumber: Record<string, number> = {
  'monday': 1,
  'tuesday': 2,
  'wednesday': 3,
  'thursday': 4,
  'friday': 5,
  'saturday': 6,
  'sunday': 0,
};

export function MonthlyWeekdayScheduler({ selectedWeekdays, onWeekdayToggle }: MonthlyWeekdaySchedulerProps) {
  const { tasks } = useTasks();

  // Get tasks that are scheduled for specific weekday positions
  const getTasksForWeekdayPosition = (position: string, weekday: string) => {
    const weekdayId = `${position.toLowerCase()}-${weekday.toLowerCase()}`;
    return tasks.filter(task => 
      task.type === 'habit' && 
      task.frequency === 'monthly' &&
      task.selectedMonthlyWeekdays?.includes(weekdayId)
    );
  };

  return (
    <div className="border border-gray-200 rounded-lg bg-white overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-gray-600" />
          <div>
            <div className="font-medium text-gray-900">Monthly Weekday Schedule</div>
            <div className="text-sm text-gray-500">
              Select specific weekdays of the month
            </div>
          </div>
        </div>
      </div>
      <div className="grid divide-y divide-gray-200">
        {weekPositions.map(position => (
          <div key={position} className="grid grid-cols-7 divide-x divide-gray-200">
            {weekdays.map(weekday => {
              const weekdayId = `${position.toLowerCase()}-${weekday.toLowerCase()}`;
              const isSelected = selectedWeekdays.includes(weekdayId);
              const weekdayTasks = getTasksForWeekdayPosition(position, weekday);

              return (
                <button
                  key={weekdayId}
                  type="button"
                  onClick={() => onWeekdayToggle(weekdayId)}
                  className={`text-left transition-colors ${
                    isSelected
                      ? 'bg-orange-50 hover:bg-orange-100'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className={`sticky top-0 z-10 px-4 py-3 text-center border-b border-gray-200 bg-inherit ${
                    isSelected ? 'text-orange-600' : ''
                  }`}>
                    <div className={`text-sm font-medium ${
                      isSelected ? 'text-orange-600' : 'text-gray-900'
                    }`}>
                      {position}
                    </div>
                    <div className="text-xs text-gray-500">
                      {weekday}
                    </div>
                  </div>
                  <div className="p-2 space-y-2 min-h-[80px]">
                    {weekdayTasks.map(task => (
                      <TaskCard
                        key={task.id}
                        name={task.name}
                        onClick={(e) => {
                          e.stopPropagation(); // Prevent weekday selection when clicking a task
                        }}
                        isInteractive={false}
                      />
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}