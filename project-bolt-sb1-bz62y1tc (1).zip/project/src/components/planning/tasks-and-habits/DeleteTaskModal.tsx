import React from 'react';
import { Trash2 } from 'lucide-react';
import { Modal } from '../../ui/Modal';
import { useTasks } from '../../../contexts/TasksContext';

interface DeleteTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskId: string;
}

export function DeleteTaskModal({ isOpen, onClose, taskId }: DeleteTaskModalProps) {
  const { tasks, deleteTask, updateTask } = useTasks();
  const task = tasks.find(t => t.id === taskId);

  if (!task) return null;

  const isRecurring = task.dates.length > 1;

  const handleDelete = (type: 'single' | 'future' | 'all') => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    switch (type) {
      case 'single': {
        const updatedDates = task.dates.filter(date => 
          date.toDateString() !== today.toDateString()
        );
        
        if (updatedDates.length === 0) {
          deleteTask(task.id);
        } else {
          updateTask(task.id, { dates: updatedDates });
        }
        break;
      }
      case 'future': {
        const updatedDates = task.dates.filter(date => 
          date.getTime() < today.getTime()
        );
        
        if (updatedDates.length === 0) {
          deleteTask(task.id);
        } else {
          updateTask(task.id, { dates: updatedDates });
        }
        break;
      }
      case 'all': {
        deleteTask(task.id);
        break;
      }
    }

    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Delete Task"
    >
      <div className="space-y-6">
        <div>
          <h3 className="font-medium text-gray-900">"{task.name}"</h3>
        </div>

        <div className="space-y-3">
          {isRecurring ? (
            <>
              <button
                onClick={() => handleDelete('single')}
                className="w-full px-4 py-3 text-left border border-gray-200 rounded-lg hover:border-gray-300 hover:bg-gray-50 transition-colors"
              >
                <div className="font-medium text-gray-900 flex items-center gap-2">
                  <Trash2 className="w-4 h-4" />
                  Just this day
                </div>
              </button>
              <button
                onClick={() => handleDelete('future')}
                className="w-full px-4 py-3 text-left border border-gray-200 rounded-lg hover:border-gray-300 hover:bg-gray-50 transition-colors"
              >
                <div className="font-medium text-gray-900 flex items-center gap-2">
                  <Trash2 className="w-4 h-4" />
                  This day and future days
                </div>
              </button>
              <button
                onClick={() => handleDelete('all')}
                className="w-full px-4 py-3 text-left border border-red-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors"
              >
                <div className="font-medium text-red-600 flex items-center gap-2">
                  <Trash2 className="w-4 h-4" />
                  All days
                </div>
              </button>
            </>
          ) : (
            <button
              onClick={() => handleDelete('all')}
              className="w-full px-4 py-3 text-left border border-red-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors"
            >
              <div className="font-medium text-red-600 flex items-center gap-2">
                <Trash2 className="w-4 h-4" />
                Delete task
              </div>
            </button>
          )}
        </div>

        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
}