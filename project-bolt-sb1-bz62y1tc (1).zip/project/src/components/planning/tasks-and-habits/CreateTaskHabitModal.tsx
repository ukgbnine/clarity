import React, { useState } from 'react';
import { Clock, Plus, ArrowRight, Calendar } from 'lucide-react';
import { Modal } from '../../ui/Modal';
import { WeeklyView } from './WeeklyView';
import { HabitScheduler } from './HabitScheduler';
import { MonthlyScheduler } from './MonthlyScheduler';
import { useTasks } from '../../../contexts/TasksContext';
import { useGoals } from '../../../contexts/GoalsContext';
import type { CreateGoalModalState } from '../../../pages/PlanningPage';

type ItemType = 'task' | 'habit';
type SchedulingType = 'fixed' | 'flexible';
type HabitFrequency = 'daily' | 'weekly' | 'monthly';

interface CreateTaskHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
  setCreateGoalModal: React.Dispatch<React.SetStateAction<CreateGoalModalState>>;
}

export function CreateTaskHabitModal({ isOpen, onClose, setCreateGoalModal }: CreateTaskHabitModalProps) {
  const { addTask } = useTasks();
  const { goals } = useGoals();
  const [itemType, setItemType] = useState<ItemType>('task');
  const [name, setName] = useState('');
  const [schedulingType, setSchedulingType] = useState<SchedulingType>('fixed');
  const [selectedDates, setSelectedDates] = useState<Date[]>([]);
  const [timeframe, setTimeframe] = useState('');
  const [selectedGoalId, setSelectedGoalId] = useState<string>('');
  const [isGoalDropdownOpen, setIsGoalDropdownOpen] = useState(false);
  const [habitFrequency, setHabitFrequency] = useState<HabitFrequency | null>(null);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [selectedMonthlyDates, setSelectedMonthlyDates] = useState<number[]>([]);
  const [selectedMonthlyWeekdays, setSelectedMonthlyWeekdays] = useState<string[]>([]);

  const resetForm = () => {
    setItemType('task');
    setName('');
    setSchedulingType('fixed');
    setSelectedDates([]);
    setTimeframe('');
    setSelectedGoalId('');
    setIsGoalDropdownOpen(false);
    setHabitFrequency(null);
    setSelectedDays([]);
    setSelectedMonthlyDates([]);
    setSelectedMonthlyWeekdays([]);
  };

  const handleClose = () => {
    onClose();
    resetForm();
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDates(prev => {
      const dateString = date.toDateString();
      const exists = prev.some(d => d.toDateString() === dateString);
      
      if (exists) {
        return prev.filter(d => d.toDateString() !== dateString);
      } else {
        return [...prev, date];
      }
    });
  };

  const handleDayToggle = (day: number) => {
    setSelectedDays(prev => {
      const newDays = prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day].sort((a, b) => a - b);

      // If all days are selected, switch to daily
      if (newDays.length === 7 && habitFrequency === 'weekly') {
        setHabitFrequency('daily');
      }
      // If removing a day while on daily, switch to weekly
      else if (habitFrequency === 'daily' && newDays.length < 7) {
        setHabitFrequency('weekly');
      }

      return newDays;
    });
  };

  const handleMonthlyDateToggle = (date: number) => {
    setSelectedMonthlyDates(prev => {
      return prev.includes(date)
        ? prev.filter(d => d !== date)
        : [...prev, date].sort((a, b) => a - b);
    });
  };

  const handleMonthlyWeekdayToggle = (weekday: string) => {
    setSelectedMonthlyWeekdays(prev => {
      return prev.includes(weekday)
        ? prev.filter(w => w !== weekday)
        : [...prev, weekday];
    });
  };

  const handleHabitFrequencyChange = (frequency: HabitFrequency) => {
    setHabitFrequency(frequency);
    if (frequency === 'daily') {
      setSelectedDays([0, 1, 2, 3, 4, 5, 6]);
    } else if (frequency === 'weekly') {
      setSelectedDays([]);
    } else if (frequency === 'monthly') {
      setSelectedMonthlyDates([]);
      setSelectedMonthlyWeekdays([]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (itemType === 'task') {
      if (schedulingType === 'fixed' && selectedDates.length === 0) return;

      addTask({
        name: name.trim(),
        type: schedulingType,
        dates: schedulingType === 'fixed' ? selectedDates : [],
        timeframe: schedulingType === 'flexible' ? timeframe.trim() || undefined : undefined,
        goalId: selectedGoalId || undefined,
      });
    } else {
      // Habit
      if (!habitFrequency) return;
      if (habitFrequency === 'weekly' && selectedDays.length === 0) return;
      if (habitFrequency === 'monthly' && selectedMonthlyDates.length === 0 && selectedMonthlyWeekdays.length === 0) return;

      let dates: Date[] = [];
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Calculate dates for the next 3 months to ensure proper visualization
      const endDate = new Date(today);
      endDate.setMonth(endDate.getMonth() + 3);

      if (habitFrequency === 'daily' || habitFrequency === 'weekly') {
        let currentDate = new Date(today);

        while (currentDate <= endDate) {
          if (habitFrequency === 'daily' || 
              selectedDays.includes(currentDate.getDay() === 0 ? 6 : currentDate.getDay() - 1)) {
            dates.push(new Date(currentDate));
          }
          currentDate.setDate(currentDate.getDate() + 1);
        }
      } else if (habitFrequency === 'monthly') {
        // Handle numeric dates
        if (selectedMonthlyDates.length > 0) {
          let currentDate = new Date(today);
          const targetMonth = currentDate.getMonth();
          const targetYear = currentDate.getFullYear();

          // Check next 3 months
          for (let monthOffset = 0; monthOffset < 3; monthOffset++) {
            const month = (targetMonth + monthOffset) % 12;
            const year = targetYear + Math.floor((targetMonth + monthOffset) / 12);

            if (selectedMonthlyDates.includes(32)) {
              // Last day of month
              const lastDay = new Date(year, month + 1, 0);
              if (lastDay >= today) {
                dates.push(new Date(lastDay));
              }
            } else {
              selectedMonthlyDates.forEach(day => {
                const date = new Date(year, month, day);
                if (date >= today && date <= endDate) {
                  dates.push(new Date(date));
                }
              });
            }
          }
        }

        // Handle weekday-based dates
        if (selectedMonthlyWeekdays.length > 0) {
          let currentDate = new Date(today);
          const targetMonth = currentDate.getMonth();
          const targetYear = currentDate.getFullYear();

          // Check next 3 months
          for (let monthOffset = 0; monthOffset < 3; monthOffset++) {
            const month = (targetMonth + monthOffset) % 12;
            const year = targetYear + Math.floor((targetMonth + monthOffset) / 12);

            selectedMonthlyWeekdays.forEach(weekdayStr => {
              const [position, weekday] = weekdayStr.split('-');
              const weekdayNum = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
                .indexOf(weekday);

              const date = new Date(year, month, 1);
              
              // Find first occurrence of weekday
              while (date.getDay() !== weekdayNum) {
                date.setDate(date.getDate() + 1);
              }

              // Find the requested occurrence
              if (position === 'last') {
                // Move to the last occurrence
                while (date.getMonth() === month) {
                  const nextDate = new Date(date);
                  nextDate.setDate(nextDate.getDate() + 7);
                  if (nextDate.getMonth() !== month) break;
                  date.setDate(date.getDate() + 7);
                }
              } else {
                const weekNum = ['first', 'second', 'third', 'fourth'].indexOf(position);
                if (weekNum >= 0) {
                  date.setDate(date.getDate() + (weekNum * 7));
                }
              }

              if (date >= today && date <= endDate && date.getMonth() === month) {
                dates.push(new Date(date));
              }
            });
          }
        }
      }

      addTask({
        name: name.trim(),
        type: 'habit',
        frequency: habitFrequency,
        dates: dates.sort((a, b) => a.getTime() - b.getTime()),
        goalId: selectedGoalId || undefined,
        selectedMonthlyWeekdays: selectedMonthlyWeekdays,
      });
    }

    handleClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title={`Create ${itemType === 'habit' ? 'Habit' : 'Task'}`}>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Item Type Selection */}
        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700">
            What would you like to create?
          </label>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => setItemType('task')}
              className={`p-4 text-left border rounded-lg transition-colors ${
                itemType === 'task'
                  ? 'border-orange-500 bg-orange-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="font-medium text-gray-900">Task</div>
              <div className="text-sm text-gray-500">For one or more days</div>
            </button>
            <button
              type="button"
              onClick={() => setItemType('habit')}
              className={`p-4 text-left border rounded-lg transition-colors ${
                itemType === 'habit'
                  ? 'border-orange-500 bg-orange-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="font-medium text-gray-900">Habit</div>
              <div className="text-sm text-gray-500">Repeatedly over time</div>
            </button>
          </div>
        </div>

        {/* Name Input */}
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
            placeholder={`Enter ${itemType} name`}
            required
          />
        </div>

        {/* Goal Selection */}
        <div className="space-y-3">
          <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
            Which goal is this helping achieve?
          </label>
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsGoalDropdownOpen(!isGoalDropdownOpen)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm text-left focus:ring-1 focus:ring-orange-500 focus:border-orange-500 bg-white"
            >
              {selectedGoalId ? (
                <span className="flex items-center gap-2 text-gray-900">
                  <ArrowRight className="w-4 h-4" />
                  {goals.find(g => g.id === selectedGoalId)?.name}
                </span>
              ) : (
                <span className="text-gray-500">Select a goal (optional)</span>
              )}
            </button>

            {isGoalDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
                <div className="py-1">
                  {goals.map((goal) => (
                    <button
                      key={goal.id}
                      type="button"
                      onClick={() => {
                        setSelectedGoalId(goal.id);
                        setIsGoalDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    >
                      <ArrowRight className="w-4 h-4" />
                      {goal.name}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      setCreateGoalModal({
                        isOpen: true,
                        onGoalCreated: (goalId: string) => {
                          setSelectedGoalId(goalId);
                        },
                      });
                      setIsGoalDropdownOpen(false);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-orange-600 hover:bg-orange-50 flex items-center gap-2 border-t border-gray-100"
                  >
                    <Plus className="w-4 h-4" />
                    Create new goal
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Scheduling Options */}
        {itemType === 'task' ? (
          <>
            {/* Task Scheduling Type */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700">
                How would you like to schedule this task?
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setSchedulingType('fixed')}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    schedulingType === 'fixed'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Fixed Scheduling</div>
                  <div className="text-sm text-gray-500">Specific dates</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSchedulingType('flexible')}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    schedulingType === 'flexible'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Flexible Scheduling</div>
                  <div className="text-sm text-gray-500">General or no timeframe</div>
                </button>
              </div>
            </div>

            {/* Weekly View for Fixed Scheduling */}
            {schedulingType === 'fixed' && (
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-700">
                  Select dates for this task
                </label>
                <WeeklyView 
                  selectable 
                  selectedDates={selectedDates}
                  onDateSelect={handleDateSelect}
                />
              </div>
            )}

            {/* Timeframe Input for Flexible Scheduling */}
            {schedulingType === 'flexible' && (
              <div>
                <label htmlFor="timeframe" className="block text-sm font-medium text-gray-700 mb-1">
                  General Timeframe
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="timeframe"
                    value={timeframe}
                    onChange={(e) => setTimeframe(e.target.value)}
                    placeholder="e.g., By Monday, March, after you finish X..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-orange-500 focus:border-orange-500"
                  />
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Habit Frequency Selection */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700">
                How would you like to schedule this habit?
              </label>
              <div className="grid grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => handleHabitFrequencyChange('daily')}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    habitFrequency === 'daily'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Daily</div>
                  <div className="text-sm text-gray-500">Every day</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleHabitFrequencyChange('weekly')}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    habitFrequency === 'weekly'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Weekly</div>
                  <div className="text-sm text-gray-500">Selected days</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleHabitFrequencyChange('monthly')}
                  className={`p-4 text-left border rounded-lg transition-colors ${
                    habitFrequency === 'monthly'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-medium text-gray-900">Monthly</div>
                  <div className="text-sm text-gray-500">Selected dates</div>
                </button>
              </div>
            </div>

            {/* Show Weekly View by Default or When Selected */}
            {(!habitFrequency || habitFrequency === 'daily' || habitFrequency === 'weekly') && (
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-700">
                  Select days for this habit
                </label>
                <HabitScheduler
                  selectedDays={selectedDays}
                  onDayToggle={handleDayToggle}
                />
              </div>
            )}

            {/* Show Monthly View When Selected */}
            {habitFrequency === 'monthly' && (
              <div className="space-y-3">
                <label className="block text-sm font-medium text-gray-700">
                  Select dates for this habit to recur monthly
                </label>
                <MonthlyScheduler
                  selectedDates={selectedMonthlyDates}
                  onDateToggle={handleMonthlyDateToggle}
                  selectedWeekdays={selectedMonthlyWeekdays}
                  onWeekdayToggle={handleMonthlyWeekdayToggle}
                />
              </div>
            )}
          </>
        )}

        {/* Form Actions */}
        <div className="flex justify-between pt-4 border-t">
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
          >
            <Clock className="w-4 h-4" />
            Add Reminder
          </button>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={
                !name.trim() || 
                (itemType === 'task' && schedulingType === 'fixed' && selectedDates.length === 0) ||
                (itemType === 'habit' && !habitFrequency) ||
                (itemType === 'habit' && habitFrequency === 'weekly' && selectedDays.length === 0) ||
                (itemType === 'habit' && habitFrequency === 'monthly' && 
                  selectedMonthlyDates.length === 0 && selectedMonthlyWeekdays.length === 0)
              }
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
}