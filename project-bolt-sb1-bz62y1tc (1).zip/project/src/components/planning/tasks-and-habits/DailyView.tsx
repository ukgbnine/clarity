import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { TaskCard } from './TaskCard';
import { useTasks } from '../../../contexts/TasksContext';
import { useGoals } from '../../../contexts/GoalsContext';
import { formatFullDate } from '../../../utils/dateUtils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { SortableTaskCard } from './SortableTaskCard';

interface DailyViewProps {
  onTaskClick: (taskId: string) => void;
}

export function DailyView({ onTaskClick }: DailyViewProps) {
  const [currentDate, setCurrentDate] = React.useState(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
  });
  
  const { tasks, reorderTasks } = useTasks();
  const { goals } = useGoals();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const navigateDay = (direction: 'prev' | 'next') => {
    setCurrentDate(prevDate => {
      const newDate = new Date(prevDate);
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));

      // Calculate the date limits (7 days in past and future from today)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const minDate = new Date(today);
      minDate.setDate(minDate.getDate() - 7);
      
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + 7);

      // Don't allow navigating beyond the limits
      if (newDate < minDate || newDate > maxDate) return prevDate;

      return newDate;
    });
  };

  // Calculate if we're at the navigation limits
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const minDate = new Date(today);
  minDate.setDate(minDate.getDate() - 7);
  
  const maxDate = new Date(today);
  maxDate.setDate(maxDate.getDate() + 7);

  const isAtMinDate = currentDate.getTime() <= minDate.getTime();
  const isAtMaxDate = currentDate.getTime() >= maxDate.getTime();
  const isToday = currentDate.toDateString() === today.toDateString();

  const dayTasks = tasks
    .filter(task => task.dates.some(date => date.toDateString() === currentDate.toDateString()))
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = dayTasks.findIndex(task => task.id === active.id);
      const newIndex = dayTasks.findIndex(task => task.id === over.id);

      const reorderedTasks = [...tasks];
      const movedTasks = arrayMove(dayTasks, oldIndex, newIndex);
      
      // Update order of all tasks
      movedTasks.forEach((task, index) => {
        const taskIndex = reorderedTasks.findIndex(t => t.id === task.id);
        if (taskIndex !== -1) {
          reorderedTasks[taskIndex] = { ...task, order: index };
        }
      });

      reorderTasks(reorderedTasks);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Daily Navigation */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-gray-200">
        <button
          onClick={() => navigateDay('prev')}
          className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:cursor-not-allowed"
          aria-label="Previous day"
          disabled={isAtMinDate}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <h3 className="text-base font-medium text-gray-900">
          {isToday ? 'Today' : formatFullDate(currentDate)}
        </h3>

        <button
          onClick={() => navigateDay('next')}
          className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:cursor-not-allowed"
          aria-label="Next day"
          disabled={isAtMaxDate}
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Tasks List */}
      <div className="p-4">
        {dayTasks.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No tasks or habits scheduled for this day
          </div>
        ) : (
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={dayTasks.map(task => task.id)}
              strategy={verticalListSortingStrategy}
            >
              <div className="space-y-3">
                {dayTasks.map(task => {
                  const isFutureDate = currentDate > today;
                  const goal = goals.find(g => g.id === task.goalId);

                  return (
                    <SortableTaskCard
                      key={task.id}
                      id={task.id}
                      taskId={task.id}
                      name={task.name}
                      goalName={goal?.name}
                      goalId={goal?.id}
                      reminder={task.reminder}
                      onClick={() => onTaskClick(task.id)}
                      showCheckbox={true}
                      isCheckboxDisabled={isFutureDate}
                      date={currentDate}
                    />
                  );
                })}
              </div>
            </SortableContext>
          </DndContext>
        )}
      </div>
    </div>
  );
}