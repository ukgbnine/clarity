import React from 'react';
import { Tag } from 'lucide-react';

interface CategoryCardProps {
  name: string;
  onEdit: () => void;
}

export function CategoryCard({ name, onEdit }: CategoryCardProps) {
  return (
    <button
      onClick={onEdit}
      className="w-full bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:border-gray-300 transition-colors relative group border-l-4 border-l-orange-500"
    >
      <div className="flex items-center gap-3">
        <Tag className="w-5 h-5 text-gray-900" />
        <span className="text-xl text-gray-900 font-medium group-hover:text-orange-600 transition-colors">
          {name}
        </span>
      </div>
    </button>
  );
}